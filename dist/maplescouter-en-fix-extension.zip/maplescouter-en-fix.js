// The namespace identifies existing installs; navigational and update URLs use the renamed repository.

/*
 * How it works (4 layers):
 * 1. i18n bundle patch  — intercepts the site's webpack chunk that carries en/common.json
 *    and merges in ~3,600 missing/corrected translations, so everything rendered through
 *    i18next comes out as proper GMS English.
 * 2. DOM dictionary     — a MutationObserver + ~55k-entry official KMS→GMS name dictionary
 *    (items/mobs/maps joined by ID from game data) catches Korean text that is hardcoded
 *    in the app or returned by the Nexon API (equipment names, etc.).
 * 3. Persistence        — remembers your last language (/en, /ko, …) and your server/region
 *    selection (GMS/KMS/JMS/TMS/MSEA) across visits and windows.
 * 4. Cloud characters   — on the Character page (formerly Manual Input), a character picker replaces
 *    the site's Load/Save Preset buttons: inputs auto-save into the selected character, characters
 *    linked to an IGN can be uploaded to or loaded from scouter.tomerh2001.com (uploads are explicit,
 *    never automatic), and the last 10 saves are kept as history you can restore.
 */

(function () {
  'use strict';

  var LOCALES = ['ko', 'en', 'ja', 'ch'];
  var LS_LOCALE = 'msfix:locale';
  var LS_REGION = 'msfix:region-backup';

  function data() { return (window.__MSFIX_DATA__ || { i18nPatch: {}, dict: {}, rules: [], css: '' }); }

  function pathLocale(path) {
    var m = (path || location.pathname).match(/^\/(ko|en|ja|ch)(?=\/|$|\?)/);
    return m ? m[1] : null;
  }

  /* ---------------- 1. Language persistence (must run before anything else) ------------- */

  function saveLocale() {
    var loc = pathLocale();
    if (loc) { try { localStorage.setItem(LS_LOCALE, loc); } catch (e) {} }
  }

  // Only the language menu changes the preference. Locale-free links and reloads
  // can otherwise silently turn /en/input -> /ko/result into a new preference.
  function navigationLocale(previousPath, nextPath, saved) {
    var next = pathLocale(nextPath);
    if (!saved || LOCALES.indexOf(saved) === -1) return next;
    return saved;
  }

  function rememberLanguageChoice(e) {
    var item = e.target && e.target.closest && e.target.closest('[role="menuitemcheckbox"], [role="menuitem"]');
    if (!item || !item.closest('[role="menu"]')) return;
    var loc = ({ Korean: 'ko', English: 'en', Japanese: 'ja', Chinese: 'ch' })[item.textContent.trim()];
    if (loc) { try { localStorage.setItem(LS_LOCALE, loc); } catch (e) {} }
  }

  // The site 307-redirects every fresh visit to /ko before any client script runs,
  // so we can never observe the unprefixed URL. Restore the saved choice before
  // boot. The language menu records deliberate changes before navigation starts.
  function restoreLocale() {
    var cur = pathLocale();
    if (!cur) return false; // pre-redirect page; the server will bounce us to /ko
    var saved = null;
    try { saved = localStorage.getItem(LS_LOCALE); } catch (e) {}
    if (saved && LOCALES.indexOf(saved) !== -1 && saved !== cur) {
      var rest = location.pathname.replace(/^\/(ko|en|ja|ch)(?=\/|$)/, '');
      location.replace('/' + saved + rest + location.search + location.hash);
      return true;
    }
    saveLocale();
    return false;
  }

  /* ---------------- 2. Region (GMS/KMS/…) persistence ----------------------------------- */
  // The site stores the selection in localStorage key "region" (zustand persist). If the
  // site ever wipes or resets it (version bumps, errors), restore it from our backup.

  // Any non-empty string region counts as valid. The site may add new region ids later,
  // and we must never revert a real selection to a stale backup because of an allowlist.
  function readSiteRegion() {
    try {
      var raw = localStorage.getItem('region');
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      var r = parsed && parsed.state && parsed.state.region;
      return (typeof r === 'string' && r) ? { region: r, raw: raw } : null;
    } catch (e) { return null; }
  }

  function backupRegion() {
    var cur = readSiteRegion();
    if (!cur) return;
    try {
      if (localStorage.getItem(LS_REGION) !== cur.raw) localStorage.setItem(LS_REGION, cur.raw);
    } catch (e) {}
  }

  function restoreRegion() {
    try {
      var backup = localStorage.getItem(LS_REGION);
      if (!backup) return;
      // Only restore when the site key is missing, unparsable, or has no region string.
      if (!readSiteRegion()) localStorage.setItem('region', backup);
    } catch (e) {}
  }

  /* ---------------- 3. i18n bundle patch ------------------------------------------------ */
  // en/common.json ships as a lazy webpack chunk. We wrap every module factory pushed to
  // webpackChunk_N_E; when a module's exports look like the EN translation table
  // (signature key check), we merge our patch into it before i18next consumes it.

  function isEnBundle(obj) {
    return obj && typeof obj === 'object' && obj['나이트로드'] === 'Night Lord';
  }

  function applyPatch(obj) {
    siteRefs.enBundle = obj; // the site's EN table (with our patch merged in) — used to name classes
    if (obj.__msfixPatched) return;
    try { Object.defineProperty(obj, '__msfixPatched', { value: true, enumerable: false }); } catch (e) { obj.__msfixPatched = true; }
    var patch = data().i18nPatch;
    for (var k in patch) obj[k] = patch[k];
  }

  /* -- site stores, captured passively as webpack executes each module (no forced requires) */
  var siteRefs = { manualStore: null, presetStore: null, regionStore: null, characterStore: null, toast: null, enBundle: null, defaultUserStat: null, react: null, createRoot: null, tooltip: null };
  // Test hook: with localStorage msfix:debug=1 the discovered refs are mirrored on window so an
  // end-to-end harness can drive the same stores we use, instead of force-requiring site modules.
  var DEBUG_REFS = false;
  try { DEBUG_REFS = localStorage.getItem('msfix:debug') === '1'; } catch (e) {}
  if (DEBUG_REFS) window.__msfixDebug = siteRefs;
  function looksLikeUserStat(v) {
    return !!(v && typeof v === 'object' && v.stat && v.hexa && v.huntSkill && v.seedRing &&
      typeof v.isGMS === 'boolean' && typeof v.stat.myClass === 'string');
  }
  // Discover the site's own tooltip components without importing or replacing its controls.
  function noteHelpRuntime(ex) {
    if (!ex || (typeof ex !== 'object' && typeof ex !== 'function')) return;
    if (!siteRefs.react && typeof ex.createElement === 'function' && typeof ex.useState === 'function') siteRefs.react = ex;
    if (!siteRefs.createRoot && typeof ex.createRoot === 'function' && typeof ex.hydrateRoot === 'function') siteRefs.createRoot = ex.createRoot;
    if (siteRefs.tooltip) return;
    var names = Object.keys(ex), found = {};
    if (names.length > 12) return;
    names.forEach(function (key) {
      var fn = ex[key]; if (typeof fn !== 'function') return;
      var code = Function.prototype.toString.call(fn);
      if (code.length > 5000) return;
      if (/"data-slot"\s*:\s*"tooltip"/.test(code)) found.Root = fn;
      if (/"data-slot"\s*:\s*"tooltip-trigger"/.test(code)) found.Trigger = fn;
      if (/"data-slot"\s*:\s*"tooltip-content"/.test(code)) found.Content = fn;
    });
    if (found.Root && found.Trigger && found.Content) siteRefs.tooltip = found;
  }
  function noteExports(ex) {
    if (!ex || (typeof ex !== 'object' && typeof ex !== 'function')) return;
    try { noteHelpRuntime(ex); if (ex.default) noteHelpRuntime(ex.default); } catch (_) {}
    var names; try { names = Object.keys(ex); } catch (e) { return; }
    for (var i = 0; i < names.length; i++) {
      var v; try { v = ex[names[i]]; } catch (e) { continue; }
      if (!v || (typeof v !== 'object' && typeof v !== 'function')) continue;
      try {
        if (!siteRefs.toast && typeof v.success === 'function' && typeof v.error === 'function' && typeof v.dismiss === 'function') siteRefs.toast = v;
        if (!siteRefs.defaultUserStat && looksLikeUserStat(v)) siteRefs.defaultUserStat = v;
        if (typeof v.getState === 'function' && typeof v.subscribe === 'function') {
          var st = v.getState();
          if (st && !siteRefs.characterStore && st.searchResult && typeof st.setSearchResult === 'function') siteRefs.characterStore = v;
          if (st && !siteRefs.regionStore && typeof st.region === 'string' && typeof st.setRegion === 'function') siteRefs.regionStore = v;
          if (st && !siteRefs.presetStore && st.preset && typeof st.setPreset === 'function' && typeof st.deletePreset === 'function') siteRefs.presetStore = v;
          if (st && !siteRefs.manualStore && ('draftStat' in st) && typeof st.loadDraft === 'function' && typeof st.setDraftStat === 'function') siteRefs.manualStore = v;
        }
      } catch (e) {}
    }
  }

  function wrapFactory(factory) {
    if (typeof factory !== 'function' || factory.__msfixWrapped) return factory;
    var wrapped = function (module, exports, req) {
      var r = factory.apply(this, arguments);
      try {
        var ex = module && module.exports;
        var payload = ex && ex.default && typeof ex.default === 'object' ? ex.default : ex;
        if (isEnBundle(payload)) applyPatch(payload);
        noteExports(ex);
        if (module) module.exports = patchBuffExports(ex);
      } catch (e) {}
      return r;
    };
    wrapped.__msfixWrapped = true;
    return wrapped;
  }

  function patchChunkEntry(entry) {
    var modules = entry && entry[1];
    if (!modules) return;
    for (var id in modules) modules[id] = wrapFactory(modules[id]);
  }

  function hookWebpack() {
    var stored = window.webpackChunk_N_E;
    function arm(arr) {
      if (!arr || arr.__msfixArmed) return arr;
      try {
        Object.defineProperty(arr, '__msfixArmed', { value: true, enumerable: false });
        // webpack replaces arr.push with its own callback that installs module
        // factories BEFORE delegating to the previous push — so a plain wrapper
        // would run too late. An accessor property keeps our patcher first in
        // line no matter what webpack assigns; the reentry flag breaks the
        // parent-chain cycle (webpack's callback calls the old push itself).
        var current = arr.push;
        var reentry = false;
        var wrapped = function (entry) {
          try { patchChunkEntry(entry); } catch (e) {}
          if (reentry) return Array.prototype.push.call(arr, entry);
          reentry = true;
          try { return current.apply(arr, arguments); }
          finally { reentry = false; }
        };
        Object.defineProperty(arr, 'push', {
          configurable: true,
          get: function () { return wrapped; },
          set: function (fn) { current = fn; }
        });
        for (var i = 0; i < arr.length; i++) { try { patchChunkEntry(arr[i]); } catch (e) {} }
      } catch (e) {}
      return arr;
    }
    try {
      Object.defineProperty(window, 'webpackChunk_N_E', {
        configurable: true,
        get: function () { return stored; },
        set: function (v) { stored = arm(v); }
      });
      if (stored) arm(stored);
    } catch (e) {
      // defineProperty failed (already non-configurable?) — arm whatever exists now.
      if (window.webpackChunk_N_E) arm(window.webpackChunk_N_E);
    }
  }

  /* ---------------- 4. DOM dictionary layer --------------------------------------------- */

  var HANGUL = /[가-힣]/;

  var KO_NUM_UNITS = { '경': 1e16, '조': 1e12, '억': 1e8, '천만': 1e7, '만': 1e4 };

  // "2086억 6801만 6589" → "208,668,016,589"
  function koreanNumberToEnglish(t) {
    if (!/^[\d,.\s경조억천만]+$/.test(t) || !/[경조억만]/.test(t)) return null;
    var total = 0, rest = t.replace(/,/g, '');
    var re = /(\d+(?:\.\d+)?)\s*(천만|경|조|억|만)/g, m, tail = rest, end = 0;
    while ((m = re.exec(rest))) {
      if (rest.slice(end, m.index).trim()) return null;
      total += Number(m[1]) * KO_NUM_UNITS[m[2]];
      end = m.index + m[0].length;
      tail = rest.slice(end);
    }
    if (!end || (tail.trim() && !/^\d+(?:\.\d+)?$/.test(tail.trim()))) return null;
    if (tail.trim()) total += Number(tail.trim());
    if (!Number.isFinite(total)) return null;
    return total.toLocaleString('en-US');
  }

  var KO_DAYS = { '월': 'Mon', '화': 'Tue', '수': 'Wed', '목': 'Thu', '금': 'Fri', '토': 'Sat', '일': 'Sun' };
  var MONTHS = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // Single-char measure/label nodes that follow numeric inputs.
  var UNIT_LABELS = { '성': '★', '회': 'time(s)', '개': 'pc(s)', '인': 'player(s)', '결과': 'Result', '없음': 'None', '만': '×10k', '억': '×100M', '배': '×' };

  // Inner Ability builds these labels outside i18next. Match complete, known
  // expressions before the older broad suffix rules, without changing game data.
  function abilityText(t, d) {
    var constraint = t.match(/^지금 (레어|에픽|유니크|레전드리) 줄이라 (레어|에픽|유니크|레전드리) 목표를 채울 수 없습니다$/);
    if (constraint) return 'This line is ' + d.dict[constraint[1]] + ', so it cannot reach a ' + d.dict[constraint[2]] + ' target.';
    constraint = t.match(/^이 줄은 최대 (\d+(?:\.\d+)?)까지만 나옵니다$/);
    if (constraint) return 'This line can roll ' + constraint[1] + ' at most.';
    var range = t.match(/^(레어|에픽|유니크|레전드리) (.+) : (\d+(?:\.\d+)?) ~ (\d+(?:\.\d+)?)$/);
    if (range && d.dict[range[2]]) return d.dict[range[1]] + ' ' + d.dict[range[2]] + ': ' + range[3] + ' to ' + range[4];
    var advancedIntro = '레전드리 전용. 명성치와 메소를 함께 쓰고 등급 상승은 없지만, 2·3번째 옵션도 레전드리가 나올 수 있습니다 (';
    if (t.indexOf(advancedIntro) === 0 && /^\d+(?:\.\d+)?%\)\.$/.test(t.slice(advancedIntro.length))) return d.dict[advancedIntro] + t.slice(advancedIntro.length);
    var honorIntro = '명성치로 등급과 옵션을 함께 재설정합니다. 옵션을 고정하지 않았을 때만 등급이 오릅니다';
    if (t.indexOf(honorIntro) === 0 && /^(?: \((?:레어|에픽|유니크) → (?:에픽|유니크|레전드리) \d+(?:\.\d+)?%\))?\.$/.test(t.slice(honorIntro.length))) return d.dict[honorIntro].replace(/\.$/, '') + hangulRunPass(t.slice(honorIntro.length), d);
    var m = t.match(/^(\d+)레벨마다 (공격력|마력) 1 증가$/);
    if (m) return (m[2] === '공격력' ? 'ATT' : 'Magic ATT') + ' +1 per ' + m[1] + ' levels';
    m = t.match(/^공격 속도 (\d+)단계 증가$/);
    if (m) return 'Attack Speed +' + m[1];
    m = t.match(/^버프 스킬의 지속 시간 (\d+(?:\.\d+)?)% 증가$/);
    if (m) return 'Buff Duration +' + m[1] + '%';
    m = t.match(/^AP를 직접 투자한 (STR|DEX|INT|LUK)의 (\d+(?:\.\d+)?)% 만큼 (STR|DEX|INT|LUK) 증가$/);
    if (m) return m[3] + ' increase: ' + m[2] + '% of ' + m[1] + ' from assigned AP';
    m = t.match(/^(STR|DEX|INT|LUK) (\d+), (STR|DEX|INT|LUK) (\d+) 증가$/);
    if (m) return m[1] + ' +' + m[2] + ', ' + m[3] + ' +' + m[4];
    m = t.match(/^(패시브 스킬 레벨|패시브 스킬의 스킬레벨|모든 능력치|다수 공격 스킬의 공격 대상) (\d+) 증가$/);
    if (m) return ({ '패시브 스킬 레벨': 'Passive Skill Level', '패시브 스킬의 스킬레벨': 'Passive Skill Level', '모든 능력치': 'All Stats', '다수 공격 스킬의 공격 대상': 'Targets Hit for Multi-target Skills' })[m[1]] + ' +' + m[2];
    m = t.match(/^(메소 획득량|아이템 드롭률|상태 이상에 걸린 대상 공격 시 데미지|일반 몬스터 공격 시 데미지) (\d+(?:\.\d+)?)% 증가$/);
    if (m) return d.dict[m[1] + ' % 증가'].replace(/ %$/, '') + ' +' + m[2] + '%';
    m = t.match(/^스킬 사용 시 (\d+(?:\.\d+)?)% 확률로 재사용 대기시간이 미적용$/);
    if (m) return 'Chance to Skip Cooldown: ' + m[1] + '%';
    m = t.match(/^방어력의 (\d+(?:\.\d+)?)% 만큼 데미지 고정값 증가$/);
    if (m) return 'Flat Damage increase: ' + m[1] + '% of Defense';
    m = t.match(/^((?:카오스|블랙|레전드리|심연의) 서큘레이터)(는 .+)$/);
    if (m && d.dict[m[1]]) {
      var rank = m[2].match(/^는 어빌리티 등급이 (레전드리|유니크) 이상이어야 씁니다$/);
      if (rank) return d.dict[m[1]] + ' requires ' + d.dict[rank[1]] + ' Inner Ability or higher.';
      if (d.dict[m[2]]) return d.dict[m[1]] + d.dict[m[2]];
    }
    m = t.match(/^고정해 둔 옵션\((.+)\)은 다른 줄에 다시 나오지 않아 목록에서 빠집니다\.$/);
    if (m) {
      var options = m[1].split(', ');
      if (options.every(function (s) { return d.dict[s]; })) return 'Locked lines (' + options.map(function (s) { return d.dict[s]; }).join(', ') + ') cannot appear on another line, so they are excluded from the list.';
    }
    // Currency values can contain Korean large-number units. Convert each whole
    // amount, not individual digits or unrelated numbers elsewhere in the label.
    var prefix = t.indexOf('1회 비용 ') === 0 ? 'Cost per reroll: ' : '';
    var costs = (prefix ? t.slice('1회 비용 '.length) : t).split(/\s*·\s*/).map(function (s) {
      return s.replace(/^(명성치|메소) ([\d,.\s경조억천만]+)$/, '$2 $1');
    });
    if (costs.every(function (s) { return /^[\d,.\s경조억천만]+ (명성치|메소)$/.test(s) || /^(카오스|블랙|레전드리|심연의) 서큘레이터 [\d,]+개$/.test(s); })) {
      var valid = true;
      var values = costs.map(function (s) {
        var circulator = s.match(/^((?:카오스|블랙|레전드리|심연의) 서큘레이터) ([\d,]+)개$/);
        if (circulator) return d.dict[circulator[1]] + ' ×' + circulator[2];
        var parts = s.match(/^([\d,.\s경조억천만]+) (명성치|메소)$/);
        var amount = parts[1].trim(), formatted = koreanNumberToEnglish(amount);
        if (formatted == null && /^\d+(?:,\d{3})*(?:\.\d+)?$/.test(amount)) formatted = amount;
        if (formatted == null) valid = false;
        return formatted + (parts[2] === '명성치' ? ' Honor EXP' : ' mesos');
      });
      if (valid) return prefix + values.join(' · ');
    }
    return null;
  }

  // The Soul simulator assembles these labels at runtime. Keep stage, count,
  // rank and cost values intact instead of translating isolated Korean runs.
  function soulText(t, d) {
    var badge = t.match(/^무기 소울 잠재 증폭 ([1-4])단계$/);
    if (badge) return 'Weapon Soul Potential amplification: Stage ' + badge[1];
    var m = t.match(/^소울 증폭 \(([1-4])단계 도전\)$/);
    if (m) return 'Amplify Soul (Stage ' + m[1] + ')';
    m = t.match(/^소울 증폭 ([1-4])단계(?: · (레어|에픽|유니크|레전드리))?$/);
    if (m) return 'Soul Amplification stage ' + m[1] + (m[2] ? ' · ' + d.dict[m[2]] : '');
    m = t.match(/^천장까지 ([\d,]+)회$/);
    if (m) return m[1] + ' attempts until guaranteed';
    m = t.match(/^([1-4])단계 소울 에테르$/);
    if (m) return 'Stage ' + m[1] + ' Soul Ether';
    m = t.match(/^(.+) — 증폭 ([1-4])단계 · (레어|에픽|유니크|레전드리) 잠재를 불러왔습니다$/);
    if (m) return (d.dict[m[1]] || m[1]) + ': Amplification stage ' + m[2] + ', ' + d.dict[m[3]] + ' Potential loaded.';
    m = t.match(/^(.+) — 소울 증폭 전 상태로 시작합니다$/);
    if (m) return (d.dict[m[1]] || m[1]) + ': starting without Soul Amplification.';
    m = t.match(/^(.+) — 소울 잠재 옵션을 확률표에서 찾지 못해 (레어|에픽|유니크|레전드리) 등급으로 새로 굴렸습니다$/);
    if (m) return (d.dict[m[1]] || m[1]) + ': Soul Potential did not match the probability table. Rerolled at ' + d.dict[m[2]] + ' rank.';
    m = t.match(/^등급 상승 보장 진행도 · 상승 확률 ([\d.]+)%$/);
    if (m) return 'Rank-up progress. Chance: ' + m[1] + '%';
    return null;
  }

  function rankingSeason(t, pathname) {
    if (!/^\/en\/battle-ranking\/?$/.test(pathname)) return null;
    var season = t.match(/^(\d+)기$/);
    return season ? 'Season ' + season[1] : null;
  }

  // Built-in dynamic rules — run after dict/JSON rules miss.
  function builtinRules(t, d) {
    var quantity = t.match(/^([\d,.]+)\s*개$/);
    if (quantity) return quantity[1] + ' items';
    var duration = t.match(/^([\d,]+)\s*(?:시간|Hours?)\s*(\d+)\s*분$/);
    if (duration) return duration[1] + 'h ' + duration[2] + 'm';
    var minutes = t.match(/^(\d+(?:\.\d+)?)\s*분$/);
    if (minutes) return minutes[1] + ' min';
    var expShare = t.match(/^\(현재 레벨의 ([\d.]+)%\)$/);
    if (expShare) return '(' + expShare[1] + '% of the current level)';
    var votes = t.match(/^([\d,]+)표$/);
    if (votes) return votes[1] + ' entries';
    var dojo = t.match(/^(\d+)층 \((.+)\)$/);
    if (dojo) return 'Floor ' + dojo[1] + ' (' + (d.dict[dojo[2]] || dojo[2]) + ')';
    var resistance = t.match(/^([\d,.]+[TMB]?)\(반감\)$/);
    if (resistance) return resistance[1] + ' (elemental resistance)';
    var dataDate = t.match(/^데이터 기준\s*:\s*(\d{4}-\d{2}-\d{2})$/);
    if (dataDate) return 'Data as of: ' + dataDate[1];
    var refund = t.match(/^X 없는 데까지 — (?:기운|Energy) ([\d,]+) \/ ([\d,]+) · (?:조각|Fragment|Fragments) ([\d,]+) \/ ([\d,]+)$/);
    if (refund) return 'Before the first X: Energy ' + refund[1] + ' / ' + refund[2] + ' · Fragments ' + refund[3] + ' / ' + refund[4];
    var schedule = t.match(/^마이페이지는 (.+?)인데 인게임 스케줄러엔 (.+?)로 등록돼 있어요 — 확인하세요$/);
    if (schedule) return 'Difficulty mismatch: My Page ' + schedule[1] + '; in-game schedule ' + schedule[2] + '.';
    var borderChanges = t.match(/^테두리 변경은 하루 (\d+)번 가능합니다 \(오늘 (\d+)번 남음\)$/);
    if (borderChanges) return 'Border changes: ' + borderChanges[1] + ' per day (' + borderChanges[2] + ' remaining today)';
    var joined = t.match(/^· (\d{4}[./-]\d{1,2}[./-]\d{1,2}) 가입$/);
    if (joined) return '· Joined ' + joined[1];
    // The ranking page replaces the literal " N기" after calling i18next.
    // Preserve that token in the bundle, then translate its populated value.
    var seasonNote = t.match(/^Based on (\d+)기 data from MapleStory's official Training Grounds\.$/);
    if (seasonNote) return "Based on Season " + seasonNote[1] + " data from MapleStory's official Training Grounds.";
    var num = koreanNumberToEnglish(t);
    if (num != null) return num;
    // Result icons prepend "hexa-" to a complete skill/group name. Resolve the
    // group before the partial Korean-run pass splits off its Roman numerals.
    var hexaLabel = t.match(/^hexa-(.+)$/i);
    if (hexaLabel && d.dict[hexaLabel[1]]) return 'HEXA: ' + d.dict[hexaLabel[1]];
    var dm = t.match(/^(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일\s*([월화수목금토일])요일$/);
    if (dm) return KO_DAYS[dm[4]] + ', ' + MONTHS[+dm[2]] + ' ' + dm[3] + ', ' + dm[1];
    var snapshotDate = t.match(/^(\d{1,2})\/(\d{1,2})\(([월화수목금토일])\) (\d{1,2})시 (\d{1,2})분 (\d{1,2})초$/);
    if (snapshotDate) return MONTHS[+snapshotDate[1]] + ' ' + snapshotDate[2] + ' (' + KO_DAYS[snapshotDate[3]] + ') ' + snapshotDate[4].padStart(2, '0') + ':' + snapshotDate[5].padStart(2, '0') + ':' + snapshotDate[6].padStart(2, '0');
    var mainShare = t.match(/^\(본캐 비율 ([\d,.]+%|-)\)$/);
    if (mainShare) return '(Main character share: ' + mainShare[1] + ')';
    if (UNIT_LABELS[t] != null) return UNIT_LABELS[t];
    var lv = t.match(/^(\d+)\s*~\s*(\d+)제$/);
    if (lv) return 'Lv ' + lv[1] + '~' + lv[2];
    var lv1 = t.match(/^(\d+)제$/);
    if (lv1) return 'Lv ' + lv1[1];
    var itemLevel = t.match(/^(\d+)제\s+(.+)$/);
    if (itemLevel && d.dict[itemLevel[2]]) return 'Lv. ' + itemLevel[1] + ' ' + d.dict[itemLevel[2]];
    var flatStat = t.match(/^(힘|민첩성|지력|운)\s+(\d+)\s+증가$/);
    if (flatStat) return ({ '힘': 'STR', '민첩성': 'DEX', '지력': 'INT', '운': 'LUK' })[flatStat[1]] + ' +' + flatStat[2];
    var arrow = t.match(/^(\d+)\s*→\s*(\d+)\s*레벨$/);
    if (arrow) return 'Lv ' + arrow[1] + ' → ' + arrow[2];
    // The boss popup splits complete plans into phase/subphase rows before
    // rendering. Translate those rows too; detailed timing notes use overrides.
    var burst = t.match(/^(?:(\d+-\d+)\s*[:：]?\s+)?(\d+)극\s*(\d+)준(?:\s*\((\d+)어센\)|\s+(\d+)어센)?$/);
    if (burst) {
      var ascent = burst[4] || burst[5];
      return (burst[1] ? burst[1] + ': ' : '') + burst[2] + ' full burst' + (burst[2] === '1' ? '' : 's') +
        ' / ' + burst[3] + ' mini-burst' + (burst[3] === '1' ? '' : 's') +
        (ascent ? ' (' + ascent + ' Ascent cast' + (ascent === '1' ? '' : 's') + ')' : '');
    }
    var bm = t.match(/^(.+?)\s*\(보약\)$/);
    if (bm) { var base = d.dict[bm[1].trim()]; if (base) return base + ' (Buffs)'; }
    var um = t.match(/^유저 정보\s*:\s*(.*)$/);
    if (um) return 'User Info: ' + hangulRunPass(um[1], d);
    return null;
  }

  // Replace maximal Korean runs inside composite strings when the WHOLE run
  // is a known dict term (class names, boss names inside "nick / class Lv.X").
  function hangulRunPass(t, d) {
    return t.replace(/[가-힣][가-힣 ]*[가-힣]|[가-힣]/g, function (run) {
      var hit = d.dict[run];
      return hit != null ? hit : run;
    });
  }

  // Phrase-level fallback for recurring composite families (boss measurement
  // notes etc.) whose exact variants are too numerous to enumerate.
  var PHRASES = [
    [/캐릭터 \(환산주스탯 구간별\)/g, ' characters by Equivalent Stat range'],
    [/([A-Z]{1,3})직업/g, 'Class $1'],
    [/([A-Z]{1,3})보스/g, 'Boss $1'],
    [/체력 및 패턴 보정/g, 'HP & patterns adjusted'],
    [/체력 보정/g, 'HP adjusted'],
    [/하드 측정/g, 'Hard-mode measured'],
    [/노말 측정/g, 'Normal-mode measured'],
    [/측정 완료/g, 'measurement complete'],
    [/실측 배율/g, 'measured multiplier'],
    [/헥사보정/g, 'HEXA-adjusted'],
    [/타보스 참고/g, 'based on other bosses'],
    [/\(([\d.]+)\s*%\s*상향\)/g, '(+$1%)'],
    [/([\d.]+)\s*%\s*상향/g, '+$1%'],
    [/(\d+)분\s/g, '$1-min ']
  ];

  function phrasePass(t) {
    var out = t;
    for (var i = 0; i < PHRASES.length; i++) out = out.replace(PHRASES[i][0], PHRASES[i][1]);
    return out;
  }

  function translateString(s) {
    // The account endpoint requires this exact confirmation word. Keep it intact
    // when the observer revisits the translated instruction or placeholder.
    if (/^Type "탈퇴" to confirm(?: account deletion\.)?$/.test(s.trim())) return null;
    var d = data();
    // Exact text can include meaningful spaces or complete multi-line probability tables.
    // Try it before trimming so these reviewed translations are reachable in the DOM.
    if (Object.prototype.hasOwnProperty.call(d.dict, s)) return d.dict[s];
    var trimmed = s.trim();
    if (!trimmed) return null;
    var out = d.dict[trimmed];
    // Exact dict hits work for any language (also fixes Konglish English strings);
    // fuzzy handling below only applies to Korean text.
    if (out == null && !HANGUL.test(trimmed)) return null;
    if (out == null && trimmed.charAt(trimmed.length - 1) === ')') {
      // extraction captured many strings without their closing paren — retry
      var noParen = d.dict[trimmed.slice(0, -1)];
      if (noParen != null) out = noParen + (noParen.charAt(noParen.length - 1) === '(' ? ')' : /\([^)]*$/.test(noParen) ? ')' : '');
    }
    if (out == null) {
      // "이름 ×3" / "이름 x3" quantity suffixes
      var m = trimmed.match(/^(.+?)\s*([×x]\s*[\d,]+)$/);
      if (m) {
        var base = d.dict[m[1].trim()];
        if (base != null) out = base + ' ' + m[2].replace(/\s+/g, '');
      }
    }
    if (out == null) out = abilityText(trimmed, d);
    if (out == null) out = soulText(trimmed, d);
    if (out == null && d.rules) {
      for (var i = 0; i < d.rules.length; i++) {
        var rule = d.rules[i]; // [regexSource, flags, template] — template uses $1..$9
        var re = rule.__re || (rule.__re = new RegExp(rule[0], rule[1]));
        var mm = trimmed.match(re);
        if (mm) { out = rule[2].replace(/\$(\d)/g, function (_, n) { return mm[+n] != null ? mm[+n] : ''; }); break; }
      }
    }
    if (out == null) out = builtinRules(trimmed, d);
    // Last resort for composite nodes: phrase families first, then embedded
    // known terms. Never touch strings with @handles (author credits).
    if (out == null && trimmed.indexOf('@') === -1) {
      var passed = hangulRunPass(phrasePass(trimmed), d);
      if (passed !== trimmed) out = passed;
    }
    if (out == null) return null;
    return s.replace(trimmed, out);
  }

  function translateTitle() {
    if (pathLocale() !== 'en') return;
    var d = data();
    var t = document.title;
    if (!t) return;
    var out = t.split(' - ').map(function (seg) {
      var s = seg.replace(/^\s*\|\s*/, '').trim(); // some titles start with a stray "| "
      var hit = d.dict[s];
      if (hit != null) return hit;
      if (/환산주스탯/.test(s)) return 'Maple Scouter';
      return HANGUL.test(s) ? hangulRunPass(s, d) : s;
    }).join(' - ');
    out = out
      .replace(/환산주스탯/g, 'Maple Scouter')
      .replace(/Boss Cut\b/g, 'Boss Clear Spec')       // stale site title uses the old wording
      .replace(/^\s*[|\-·∙]\s*/, '')                    // drop any leading separator
      .replace(/\s{2,}/g, ' ')
      .trim();
    if (out && out !== t) document.title = out;
  }

  // The header logo is two spans reading 환산/주스탯 (the site's Korean brand).
  // Rebrand to the site's own English name instead of a literal translation.
  function fixLogo() {
    if (pathLocale() !== 'en') return;
    // every header link that wraps the logo image (desktop + mobile variants)
    var links = document.querySelectorAll('header a');
    for (var i = 0; i < links.length; i++) {
      var link = links[i];
      if (!link.querySelector('img[alt="logo"], img[src*="logo"]')) continue;
      var spans = link.querySelectorAll('span');
      if (spans.length >= 2) {
        if (spans[0].textContent !== 'Maple ') spans[0].textContent = 'Maple ';
        if (spans[1].textContent !== 'Scouter') spans[1].textContent = 'Scouter';
      } else if (spans.length === 1 && spans[0].textContent !== 'Maple Scouter') {
        spans[0].textContent = 'Maple Scouter';
      }
      addCredit(link);
    }
  }

  // "Patched by Tomerh2001" tucked under the logo wordmark. It is positioned
  // ABSOLUTELY, anchored to the logo link itself (which we make position:relative),
  // so it is taken out of flow — the header's flex/justify-between layout, and its
  // responsive variants, can never move it, center it, or resize the row. left is
  // the wordmark's own offset (aligns under the text, past the icon); top:100% sits
  // it just below the logo. It is a <span> (a nested <a> is invalid) with a click
  // handler opening the repo, and every size/weight is forced with !important so the
  // site's CSS cannot inflate it. Re-applied after React re-renders by fixLogo().
  var CREDIT_URL = 'https://github.com/tomerh2001/maplescouter-enhancements';
  function addCredit(link) {
    if (link.querySelector('.msfix-credit')) return;
    if (!link.offsetHeight || !link.offsetWidth) return; // not laid out yet; retry next tick
    link.style.removeProperty('flex-wrap'); // undo any earlier-version wrapping
    if (getComputedStyle(link).position === 'static') link.style.position = 'relative';
    var wordmark = link.querySelector('span');
    var indent = wordmark ? wordmark.offsetLeft : 28;
    var s = document.createElement('span');
    s.className = 'msfix-credit';
    s.textContent = 'Patched by Tomerh2001';
    s.title = 'MapleScouter Enhancements by tomerh2001. Click for the source.';
    var force = function (k, v) { s.style.setProperty(k, v, 'important'); };
    force('position', 'absolute');
    force('left', indent + 'px');
    force('top', '100%');
    force('margin-top', '2px');
    force('font-size', '9px');
    force('line-height', '1');
    force('font-weight', '600');
    force('letter-spacing', '0.4px');
    force('opacity', '0.45');
    force('color', 'currentColor');
    force('white-space', 'nowrap');
    force('cursor', 'pointer');
    force('pointer-events', 'auto');
    force('z-index', '2');
    force('text-decoration', 'none');
    s.addEventListener('mouseenter', function () { force('opacity', '0.85'); force('text-decoration', 'underline'); });
    s.addEventListener('mouseleave', function () { force('opacity', '0.45'); force('text-decoration', 'none'); });
    s.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); window.open(CREDIT_URL, '_blank', 'noopener'); });
    link.appendChild(s);
  }

  // Remove the (empty) Favorites bar under the search box — it reserves a large
  // block of vertical space. Set to false to keep the favorites feature.
  var REMOVE_FAVORITES = true;

  function hideFavoritesBar() {
    if (!REMOVE_FAVORITES) return;
    var spans = document.querySelectorAll('span.font-semibold');
    for (var i = 0; i < spans.length; i++) {
      var t = spans[i].textContent.trim();
      if (t !== 'Favorite' && t !== '즐겨찾기') continue;
      var block = spans[i].closest('div[class*="min-w-0"][class*="gap-3"]') ||
                  spans[i].closest('div[class*="py-3"]');
      if (block && !block.__msfixHidden) { block.__msfixHidden = true; block.style.display = 'none'; }
    }
  }

  /* ---------------- 4c. Preset JSON: legacy files, character picker, overwrite ---------- */
  // The site ships its own JSON preset export/import (Aug 2026), so we no longer add
  // Export/Import buttons of our own. Two gaps are left, and this section fills both.
  //
  //  1. A file exported by our OLD button holds EVERY preset that was saved at the time
  //       {app:'maplescouter-en-fix', type:'preset-export', v:1, data:{'character-store','preset'}}
  //     whereas the site imports one preset per file and rejects our shape outright. We
  //     translate such a file into the site's native format as it is read and let the site's
  //     OWN importer take it from there (it validates, adds a slot, toasts, no reload). When
  //     the file holds more than one character we first ask which one to import.
  //
  //  2. The site's import can only ever ADD a preset. To refresh one that already exists we
  //     add an Import button to the Save window — file, character, target preset, name, then
  //     an explicit confirm — writing through the site's own preset store so the UI updates
  //     live. (Note the manual-input form renders from 'manual-store'/draftStat, NOT from
  //     'character-store', which is why restoring localStorage wholesale never showed up.)
  function isLegacyExport(obj) {
    return obj && typeof obj === 'object' &&
      (obj.app === 'maplescouter-en-fix' || obj.type === 'preset-export') &&
      obj.data && typeof obj.data === 'object';
  }

  // The site validates an imported preset's data against its CURRENT schema and throws on any
  // missing key. Old files were exported against an older schema, so deep-conform their data
  // to the shape of a current, live userStat (fills any keys added since) before handing it over.
  // Values are kept whenever they can be read as the template's type (a number stored as
  // "2", a "true" flag, ...), and an array keeps its entries one by one. Only a value that
  // cannot be read at all falls back to the template. Every such fallback is listed in the
  // optional `report` array ({path, from, to}) so the caller can tell the user.
  function conformTo(template, data, report, path) {
    path = path || '';
    if (Array.isArray(template)) {
      if (!Array.isArray(data)) { if (data !== null && data !== undefined) conformNote(report, path, data, template); return template.slice(); }
      if (data.length > template.length) conformNote(report, path, data.slice(template.length), []);
      return template.map(function (t, i) { return i < data.length ? conformTo(t, data[i], report, path + '[' + i + ']') : t; });
    }
    if (template && typeof template === 'object') {
      var out = {};
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        for (var k in template) {
          out[k] = Object.prototype.hasOwnProperty.call(data, k)
            ? conformTo(template[k], data[k], report, path ? path + '.' + k : k) : template[k];
        }
      } else {
        if (data !== null && data !== undefined) conformNote(report, path, data, template);
        for (var k2 in template) out[k2] = template[k2];
      }
      return out;
    }
    if (data === null || data === undefined) return template;
    var v = coerceLike(template, data);
    if (v === undefined) { conformNote(report, path, data, template); return template; }
    return v;
  }
  function conformNote(report, path, from, to) { if (report) report.push({ path: path, from: from, to: to }); }
  // Read `data` as the same JS type as `template`. Returns undefined when that is impossible.
  function coerceLike(template, data) {
    if (typeof data === typeof template) return data;
    if (typeof template === 'string') {
      if (typeof data === 'number' && isFinite(data)) return String(data);
      if (typeof data === 'boolean') return String(data);
      return undefined;
    }
    if (typeof template === 'number') {
      if (typeof data === 'string' && data.trim() !== '' && isFinite(Number(data))) return Number(data);
      if (typeof data === 'boolean') return data ? 1 : 0;
      return undefined;
    }
    if (typeof template === 'boolean') {
      if (data === 'true' || data === 1 || data === '1') return true;
      if (data === 'false' || data === 0 || data === '0') return false;
      return undefined;
    }
    return undefined;
  }
  // One toast for everything conformTo had to reset, e.g. "2 fields in this file were reset".
  function conformToast(report, where) {
    if (!report || !report.length) return;
    var n = report.length;
    try { if (DEBUG_REFS) console.warn('[msfix] conform: reset ' + n + ' field(s) in ' + where, report); } catch (e) {}
    toastErr(n + (n === 1 ? ' field' : ' fields') + ' in ' + where + ' could not be read and ' + (n === 1 ? 'was' : 'were') + ' reset');
  }

  // A current, schema-current userStat to use as the conform template. The site's own default
  // userStat comes first, so a missing field is filled with the site default and never with
  // another character's value (site default > preset slot > live build).
  function currentUserStatTemplate() {
    if (siteRefs.defaultUserStat) return siteRefs.defaultUserStat;
    try {
      var pr = JSON.parse(localStorage.getItem('preset'));
      var slots = pr && pr.state && pr.state.preset;
      for (var k in slots) { var d = slots[k] && slots[k].data; if (d && d.stat && ('myClass' in d.stat)) return d; }
    } catch (e) {}
    try {
      var cs = JSON.parse(localStorage.getItem('character-store'));
      var us = cs && cs.state && cs.state.searchResult && cs.state.searchResult.userStat;
      if (us && us.stat) return us;
    } catch (e) {}
    try {
      var ms = JSON.parse(localStorage.getItem('manual-store'));
      var ds = ms && ms.state && ms.state.draftStat;
      if (ds && ds.stat) return ds;
    } catch (e) {}
    return null;
  }

  // Pull every usable preset out of an old export, as native-format {data,label,savedAt} entries.
  function legacyPresets(oldObj) {
    var tmpl = currentUserStatTemplate();
    var list = [];
    var src = oldObj.data || {};
    function add(rawData, label, savedAt) {
      if (!rawData || typeof rawData !== 'object' || !rawData.stat || !rawData.stat.myClass) return;
      list.push({
        data: tmpl ? conformTo(tmpl, rawData) : rawData,
        label: typeof label === 'string' ? label : '',
        savedAt: typeof savedAt === 'string' ? savedAt : null
      });
    }
    try {
      var pr = src.preset ? JSON.parse(src.preset) : null;
      var slots = pr && pr.state && pr.state.preset;
      if (slots) Object.keys(slots).sort(function (a, b) { return (+a) - (+b); })
        .forEach(function (k) { add(slots[k] && slots[k].data, slots[k] && slots[k].label, slots[k] && slots[k].savedAt); });
    } catch (e) {}
    if (!list.length) { // no saved slots → fall back to the backed-up live build
      try {
        var cs = src['character-store'] ? JSON.parse(src['character-store']) : null;
        var us = cs && cs.state && cs.state.searchResult && cs.state.searchResult.userStat;
        add(us, 'Imported backup', null);
      } catch (e) {}
    }
    return list;
  }

  function nativePresetJson(p) {
    // Give it a caption of its own: an unlabelled preset is otherwise captioned from whichever
    // character happens to be loaded, which would misname what we just imported.
    return JSON.stringify({
      type: 'maplescouter-manual-preset', v: 1,
      savedAt: p.savedAt, label: p.label || autoPresetLabel(p.data), data: p.data
    });
  }

  // Read any preset file we understand: ours (which may hold many characters) or the site's own.
  function parsePresetFile(txt) {
    var obj = null;
    try { obj = JSON.parse(txt); } catch (e) { return null; }
    if (isLegacyExport(obj)) return { kind: 'legacy', presets: legacyPresets(obj) };
    if (obj && obj.type === 'maplescouter-manual-preset' && obj.data) {
      return { kind: 'native', presets: [{
        data: obj.data,
        label: typeof obj.label === 'string' ? obj.label : '',
        savedAt: typeof obj.savedAt === 'string' ? obj.savedAt : null,
        ign: typeof obj.ign === 'string' && IGN_RE.test(obj.ign) ? obj.ign : null,  // our export enrichment (4d)
        meta: obj.meta && typeof obj.meta === 'object' ? obj.meta : null              // hexaConverted, as in the cloud document
      }] };
    }
    return null;
  }

  // The site names an unlabelled preset "Lv <level> <class>"; mirror that, but store the class
  // already translated so the saved label reads as English everywhere it is shown or exported.
  function autoPresetLabel(d) {
    try {
      var cls = d.stat.myClass;
      var dict = data().dict || {};
      return 'Lv ' + d.stat.level + ' ' + (dict[cls] || cls);
    } catch (e) { return ''; }
  }
  // An untouched preset slot still holds the site's default data (level 0), and offering that
  // as something to import is just noise — the site itself treats level > 0 as "really saved".
  function presetDataOk(d) {
    if (!d || !d.stat || !d.stat.myClass) return false;
    var lv = Number(d.stat.level);
    return isFinite(lv) && lv > 0 && lv <= 300;
  }
  // The site accepts any number, so a stray digit (Main Stat % 4831 instead of 832) would be saved
  // and synced as is. These limits sit far above any real character, so only a typo trips them,
  // and it is caught before it spreads to the cloud and to every other device.
  function statWarnings(d) {
    var st = (d && d.stat) || {}, out = [];
    var n = function (k) { var v = Number(st[k]); return isFinite(v) ? v : 0; };
    if (n('mainStatPer') > 3000) out.push('Main Stat % is ' + st.mainStatPer + '. The site cannot calculate above about 3000.');
    else if (n('mainStatBase') * (1 + n('mainStatPer') / 100) + n('mainStatAbs') > 300000) out.push('Total main stat comes to about ' + fmtNum(n('mainStatBase') * (1 + n('mainStatPer') / 100) + n('mainStatAbs')) + '. No character has that much.');
    if (n('subStatPer') > 3000) out.push('Sub Stat % is ' + st.subStatPer + '. The site cannot calculate above about 3000.');
    if (n('bossDmg') > 2000) out.push('Boss Damage is ' + st.bossDmg + '%. That is far above any real character.');
    if (n('ignoreDef') > 100) out.push('Ignore Defense is ' + st.ignoreDef + '%. It cannot go above 100.');
    return out;
  }
  function shortDate(s) {
    if (!s) return '';
    var t = new Date(s);
    return isNaN(t.getTime()) ? '' : t.toLocaleDateString() + ' ' + t.toLocaleTimeString();
  }

  /* -- the site's own preset store + toast, found by SHAPE so module ids may change ------- */
  var _wpReq = null;
  function wpRequire() {
    if (_wpReq) return _wpReq;
    try {
      var arr = self.webpackChunk_N_E;
      if (arr && typeof arr.push === 'function') arr.push([[Symbol('msfix')], {}, function (r) { _wpReq = r; }]);
    } catch (e) {}
    return _wpReq;
  }
  // Normally both were captured passively while the site loaded; the scan (scanSiteModules,
  // section 4d) is only a fallback for anything missed, and only runs once the page is loaded.
  function siteApi() {
    if (!siteRefs.presetStore) scanSiteModules();
    return siteRefs.presetStore ? { presetStore: siteRefs.presetStore, toast: siteRefs.toast } : null;
  }
  function siteToast() { if (siteRefs.toast) return siteRefs.toast; var a = siteApi(); return a ? a.toast : null; }
  function toastOk(m) { var t = siteToast(); if (t) try { t.success(m); } catch (e) {} }
  function toastErr(m) { var t = siteToast(); if (t) try { t.error(m); } catch (e) {} }

  /* -- dialogs assembled from the site's own utility classes so they look native --------- */
  var CLS = {
    box: 'bg-surface-gray-surface-0 fixed top-[50%] left-[50%] z-[2147483647] grid max-h-[calc(100dvh-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 overflow-y-auto rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg w-[440px] max-w-[95vw]',
    body: 'flex w-full flex-col gap-4',
    list: 'flex w-full flex-col gap-2',
    head: 'text-center text-sm font-semibold',
    hint: 'text-text-gray-low text-center text-xs',
    hintLeft: 'text-text-gray-low text-xs',
    row: "inline-flex cursor-pointer justify-center whitespace-nowrap rounded-lg text-sm font-medium transition-all [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline outline-outline-gray-med text-text-gray-high hover:bg-surface-gray-surface-1 active:bg-surface-gray-surface-1 px-4 has-[>svg]:px-3 h-auto w-full flex-col items-center gap-0.5 py-2",
    rowMain: 'w-full truncate text-center',
    rowSub: 'text-text-gray-low text-xs',
    soft: "inline-flex items-center cursor-pointer justify-center whitespace-nowrap text-sm font-medium transition-all [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 bg-surface-gray-surface-2 text-text-gray-high hover:bg-surface-gray-surface-3 h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
    primary: "inline-flex items-center cursor-pointer justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 [&_svg]:shrink-0 bg-primary text-text-gray-white hover:bg-surface-primary-primary-hover h-9 px-4 py-2 has-[>svg]:px-3 flex-1",
    ghost: 'inline-flex items-center cursor-pointer justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all outline outline-outline-gray-med text-text-gray-high hover:bg-surface-gray-surface-1 h-9 px-4 py-2 flex-1',
    input: 'outline-outline-gray-med bg-surface-gray-surface-0 flex w-full min-w-0 rounded-[4px] text-sm outline transition-[color,box-shadow] md:text-sm h-8 px-2 py-[5.5px] focus:outline-outline-gray-high',
    footer: 'border-outline-gray-med flex flex-col gap-2 border-t pt-3',
    close: 'absolute top-4 right-4 cursor-pointer rounded-xs opacity-70 transition-opacity hover:opacity-100',
    iconGroup: 'absolute top-1/2 right-2 flex -translate-y-1/2 gap-1',
    iconBtn: "inline-flex items-center cursor-pointer justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline outline-outline-gray-med text-text-gray-high active:bg-surface-gray-surface-1 border-outline-gray-med bg-surface-gray-surface-0 hover:bg-surface-gray-surface-1 size-7 shadow-sm"
  };
  var ICON_FILE_UP = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-up size-4"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M12 12v6"/><path d="m15 15-3-3-3 3"/></svg>';
  var ICON_X = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x size-4"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';

  // Dialogs stack (character -> name -> confirm), so only the front-most one may be dismissed:
  // a click or Escape must never reach through and close the ones waiting behind it.
  var dlgStack = [];

  function msDialog(opts) {
    // The site's dialog is modal, and Radix parks `pointer-events:none` on <body> while it is
    // open — which our dialog would inherit — so both layers opt back in explicitly. Both also
    // sit at the same z-index as the site's dialog, letting DOM order do the stacking.
    var overlay = document.createElement('div');
    overlay.className = 'msfix-dialog-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:2147483647;pointer-events:auto';
    var box = document.createElement('div');
    box.className = CLS.box + ' msfix-dialog';
    box.style.setProperty('pointer-events', 'auto', 'important');
    box.setAttribute('role', 'dialog');
    box.setAttribute('data-msfix-ui', ''); overlay.setAttribute('data-msfix-ui', ''); // never translated (IGNs/labels inside)
    var body = document.createElement('div');
    body.className = CLS.body;
    box.appendChild(body);

    var handle = {};
    dlgStack.push(handle);
    // Keyboard users: focus moves into the window when it opens, Tab stays inside it, and the
    // element that had focus gets it back when the window closes. The picker input is restored
    // quietly (its focus handler would otherwise reopen the dropdown).
    var prevFocus = document.activeElement;
    box.tabIndex = -1;
    function focusables() {
      var all = box.querySelectorAll('input,button,select,textarea,a[href],[tabindex]:not([tabindex="-1"])'), out = [];
      for (var i = 0; i < all.length; i++) if (!all[i].disabled && !all[i].hidden && all[i].offsetParent !== null) out.push(all[i]);
      return out;
    }
    function isTop() { return dlgStack[dlgStack.length - 1] === handle; }
    function close() {
      var i = dlgStack.indexOf(handle);
      if (i !== -1) dlgStack.splice(i, 1);
      window.removeEventListener('keydown', onKey, true);
      var hadFocus = box.contains(document.activeElement);
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
      if (box.parentNode) box.parentNode.removeChild(box);
      if (!hadFocus || !prevFocus || !prevFocus.focus || !document.contains(prevFocus)) return;
      if (prevFocus === picker.input) picker.quietFocus = true;
      try { prevFocus.focus(); } catch (e) {}
      picker.quietFocus = false;
    }
    function cancel() { if (!isTop()) return; close(); if (opts.onCancel) opts.onCancel(); }
    // Escape must dismiss ONLY the front-most window. The site's dialog listens on document,
    // so we take the key on `window` — which captures first — and stop it dead there.
    // Tab wraps inside the front-most window instead of walking the page behind it.
    function onKey(e) {
      if (!isTop()) return;
      if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); cancel(); return; }
      if (e.key !== 'Tab') return;
      var f = focusables(), cur = document.activeElement;
      if (!f.length) { e.preventDefault(); box.focus(); return; }
      if (!box.contains(cur)) { e.preventDefault(); (e.shiftKey ? f[f.length - 1] : f[0]).focus(); return; }
      if (e.shiftKey && cur === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && cur === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
    window.addEventListener('keydown', onKey, true);
    overlay.addEventListener('click', cancel);

    // The site's dialog dismisses itself on any pointer event outside its own box — which is
    // every click in ours. Keep those from reaching it so the window we opened on top of never
    // takes the one behind it down with it.
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click', 'touchstart', 'focusin'].forEach(function (t) {
      var swallow = function (e) { e.stopPropagation(); };
      overlay.addEventListener(t, swallow);
      box.addEventListener(t, swallow);
    });

    var x = document.createElement('button');
    x.type = 'button'; x.className = CLS.close; x.innerHTML = ICON_X;
    x.addEventListener('click', cancel);
    box.appendChild(x);

    var head = document.createElement('span');
    head.className = CLS.head; head.textContent = opts.title;
    body.appendChild(head);
    if (opts.subtitle) {
      var sub = document.createElement('span');
      sub.className = CLS.hint; sub.textContent = opts.subtitle;
      body.appendChild(sub);
    }
    if (opts.build) opts.build(body, close);

    document.body.appendChild(overlay);
    document.body.appendChild(box);
    // Move focus in: the first input, else the first real button (not the corner X), else the box.
    setTimeout(function () {
      if (!box.parentNode || box.contains(document.activeElement)) return;
      var f = box.querySelector('input'), bs = focusables();
      for (var i = 0; !f && i < bs.length; i++) if (bs[i] !== x) f = bs[i];
      try { (f || box).focus(); } catch (e) {}
    }, 0);
    return { close: close };
  }

  function msRow(main, sub, onClick) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = CLS.row;
    var m = document.createElement('span'); m.className = CLS.rowMain; m.textContent = main;
    b.appendChild(m);
    if (sub) { var s = document.createElement('span'); s.className = CLS.rowSub; s.textContent = sub; b.appendChild(s); }
    b.addEventListener('click', onClick);
    return b;
  }
  function msActions(body, cancelLabel, onCancel, goLabel, onGo) {
    var row = document.createElement('div');
    row.className = 'flex w-full gap-2';
    var no = document.createElement('button');
    no.type = 'button'; no.className = CLS.ghost; no.textContent = cancelLabel;
    no.addEventListener('click', onCancel);
    var yes = document.createElement('button');
    yes.type = 'button'; yes.className = CLS.primary; yes.textContent = goLabel;
    yes.addEventListener('click', onGo);
    row.appendChild(no); row.appendChild(yes);
    body.appendChild(row);
  }

  // Step 1 — an old file can hold every preset we ever saved, so ask which character to use.
  // Skipped entirely when the file only holds one.
  function pickPreset(presets, cb, onCancel) {
    if (presets.length === 1) { cb(presets[0]); return; }
    msDialog({
      title: 'Select the character to import',
      subtitle: 'This file holds ' + presets.length + ' saved characters.',
      onCancel: onCancel,
      build: function (body, close) {
        var list = document.createElement('div'); list.className = CLS.list;
        presets.forEach(function (p, i) {
          list.appendChild(msRow(
            p.label || autoPresetLabel(p.data) || ('Character ' + (i + 1)),
            shortDate(p.savedAt),
            function () { close(); cb(p); }
          ));
        });
        body.appendChild(list);
      }
    });
  }

  // Step 2 — the name: keep what the slot has, take the file's, auto, or type one.
  function pickName(p, slotKey, isNew, current) {
    var fromFile = p.label || '';
    var auto = autoPresetLabel(p.data);
    var currentName = current ? (current.label || '') : '';
    msDialog({
      title: 'Name for slot ' + slotKey,
      subtitle: 'Pick a name, or type your own.',
      build: function (body, close) {
        var input = document.createElement('input');
        input.className = CLS.input;
        input.setAttribute('maxlength', '40');
        input.placeholder = 'Character name (auto if left blank)';
        input.value = fromFile || currentName || '';
        body.appendChild(input);

        var list = document.createElement('div'); list.className = CLS.list;
        if (fromFile) list.appendChild(msRow('Use the name from the file', fromFile,
          function () { input.value = fromFile; input.focus(); }));
        if (!isNew && currentName) list.appendChild(msRow('Keep the current name', currentName,
          function () { input.value = currentName; input.focus(); }));
        if (auto) list.appendChild(msRow('Use the automatic name', auto,
          function () { input.value = auto; input.focus(); }));
        body.appendChild(list);

        msActions(body, 'Cancel', function () { close(); },
          'Continue', function () { close(); confirmWrite(p, slotKey, isNew, current, input.value.trim()); });
        setTimeout(function () { input.focus(); }, 30);
      }
    });
  }

  // Step 4 — overwriting throws away a saved preset, so confirm it explicitly.
  function confirmWrite(p, slotKey, isNew, current, label) {
    var shown = label || autoPresetLabel(p.data);
    var currentName = current ? (current.label || (presetDataOk(current.data) ? autoPresetLabel(current.data) : '')) : '';
    msDialog({
      title: isNew ? ('Add to slot ' + slotKey + '?') : ('Overwrite slot ' + slotKey + '?'),
      subtitle: isNew
        ? (shown + ' will be saved to slot ' + slotKey + '.')
        : ('Slot ' + slotKey + (currentName ? ' (' + currentName + ')' : '') + ' will be replaced by ' + shown + '. This cannot be undone.'),
      build: function (body, close) {
        msActions(body, 'Cancel', function () { close(); },
          isNew ? 'Add preset' : 'Overwrite', function () { close(); applyPreset(p, slotKey, label); });
      }
    });
  }

  function applyPreset(p, slotKey, label) {
    var api = siteApi();
    if (!api) { toastErr('Preset storage is unavailable'); return; }
    var st = api.presetStore.getState();
    var map = {}, cur = st.preset || {};
    for (var k in cur) map[k] = cur[k];
    var tmpl = currentUserStatTemplate(), report = [];
    // An unlabelled preset is captioned from whatever character is loaded right now, not from
    // the preset itself — which would show the wrong name here — so always store one.
    map[slotKey] = {
      data: tmpl ? conformTo(tmpl, p.data, report) : p.data,
      label: label || autoPresetLabel(p.data),
      savedAt: new Date().toISOString()
    };
    try { st.setPreset(map); } catch (e) { toastErr('Could not save the preset'); return; }
    conformToast(report, 'this file');
    if (p.ign && !bindingByIgn(p.ign)) bindSlot(slotKey, p.ign, null); // file carried an IGN: link the slot
    toastOk('Slot ' + slotKey + ' updated' + (label ? ' (' + label + ')' : ''));
    var closeBtn = document.querySelector('[data-slot=dialog-close]');
    if (closeBtn) closeBtn.click();
  }

  function pickJsonFile(cb) {
    var inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = '.json,application/json';
    inp.style.display = 'none';
    inp.__msfixOwn = true; // so the interception below ignores our own picker
    inp.addEventListener('change', function () {
      var f = inp.files && inp.files[0];
      if (inp.parentNode) inp.parentNode.removeChild(inp);
      if (!f) return;
      if (f.size > 5e6) { toastErr('File is abnormally large'); return; }
      f.text().then(cb, function () { toastErr("Couldn't read the file"); });
    });
    document.body.appendChild(inp);
    inp.click();
  }

  // The Save window is the dialog with the name field; the Load window has none.
  function saveDialogEl() {
    var dlgs = document.querySelectorAll('[data-slot=dialog-content]');
    for (var i = 0; i < dlgs.length; i++) if (dlgs[i].querySelector('input[data-slot=input]')) return dlgs[i];
    return null;
  }

  // The site's own import can only ever ADD a preset. Give every row in the Save window an
  // Import icon next to its Save-as-JSON / Delete pair, so a file can refresh THAT preset:
  // file -> character (when the file holds several) -> name -> confirm.
  function ensureSaveImportIcons() {
    var dlg = saveDialogEl();
    if (!dlg) return;
    var list = dlg.querySelector('div.flex.w-full.flex-col.gap-2');
    if (!list) return;
    var rows = list.querySelectorAll(':scope > div.group.relative');
    for (var i = 0; i < rows.length; i++) addRowImportIcon(rows[i], String(i + 1));
  }

  function addRowImportIcon(row, slotKey) {
    if (row.querySelector('.msfix-row-import')) return;
    // Saved presets already carry an icon group; empty slots have none, so make one.
    var group = row.querySelector('div.absolute.top-1\\/2.right-2');
    if (!group) {
      group = document.createElement('div');
      group.className = CLS.iconGroup;
      row.appendChild(group);
    }
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = CLS.iconBtn + ' msfix-row-import';
    btn.title = 'Import from JSON file (replace this slot)';
    btn.innerHTML = ICON_FILE_UP;
    btn.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      var api = siteApi();
      var cur = api ? (api.presetStore.getState().preset || {})[slotKey] : null;
      var isNew = !(cur && presetDataOk(cur.data));
      pickJsonFile(function (txt) {
        var parsed = parsePresetFile(txt);
        var usable = parsed ? parsed.presets.filter(function (p) { return presetDataOk(p.data); }) : [];
        if (!usable.length) { toastErr("This isn't MapleScouter manual-preset data"); return; }
        pickPreset(usable, function (p) { pickName(p, slotKey, isNew, cur); });
      });
    });
    group.insertBefore(btn, group.firstChild);

    // The row's caption is centred across the full width, so an extra icon would have it run
    // underneath the icons. Reserve the icon strip's width on BOTH sides: the caption stays
    // centred and `truncate` clips it before it reaches them.
    var main = row.querySelector(':scope > button');
    if (!main) return;
    var pad = function () {
      var w = group.offsetWidth;
      if (!w) return;
      var v = (w + 12) + 'px';
      main.style.paddingLeft = v;
      main.style.paddingRight = v;
    };
    pad();
    setTimeout(pad, 50);
  }

  // The Load window's own Import reads one preset per file. Hold its handler until we know
  // what the file is: ours with several characters gets a picker first, then goes through as a
  // single native preset; anything else is handed straight back so the site imports it as usual.
  function installPresetImportBridge() {
    if (window.__msfixPresetBridge) return;
    window.__msfixPresetBridge = true;
    document.addEventListener('change', function (e) {
      var input = e.target;
      if (!input || input.tagName !== 'INPUT' || input.type !== 'file') return;
      if (input.__msfixOwn) return;
      if (!/json/i.test(input.accept || '')) return;
      if (input.__msfixPass) { input.__msfixPass = false; return; } // our own replay
      var f = input.files && input.files[0];
      if (!f || typeof DataTransfer === 'undefined') return;

      e.stopImmediatePropagation();
      e.preventDefault();

      function deliver(text, name) {
        try {
          var dt = new DataTransfer();
          dt.items.add(new File([text], name || f.name, { type: 'application/json' }));
          input.__msfixPass = true;
          input.files = dt.files;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (err) { input.__msfixPass = false; }
      }

      f.text().then(function (txt) {
        var parsed = (typeof txt === 'string' && txt.length < 5e6) ? parsePresetFile(txt) : null;
        if (parsed && parsed.kind === 'native' && parsed.presets[0].ign) {   // link the slot the site is about to add
          cloud.pendingImport = { ign: parsed.presets[0].ign, label: parsed.presets[0].label, at: Date.now() };
        }
        if (!parsed || parsed.kind !== 'legacy') { deliver(txt); return; } // site handles its own files
        var usable = parsed.presets.filter(function (p) { return presetDataOk(p.data); });
        if (!usable.length) { deliver(txt); return; }                      // let the site explain why
        pickPreset(usable,
          function (p) { deliver(nativePresetJson(p), 'scouter-preset-import.json'); },
          function () { try { input.value = ''; } catch (err) {} });       // cancelled — allow a re-pick
      }, function () { deliver(''); });
    }, true);
  }

  // Our longer English labels ("Genesis Liberated" etc.) can make the weapon-state
  // checkbox row wrap — compact that row so all options stay on one line.
  function compactCheckboxRows() {
    var labels = document.querySelectorAll('label');
    for (var i = 0; i < labels.length; i++) {
      var t = labels[i].textContent.trim();
      if (t !== 'Genesis Liberated' && t !== 'Mu Gong Soul') continue;
      var row = labels[i].parentElement;
      if (!row || row.__msfixCompact) continue;
      row.__msfixCompact = true;
      row.style.flexWrap = 'nowrap';
      row.style.columnGap = '10px';
      var ls = row.querySelectorAll('label');
      for (var j = 0; j < ls.length; j++) {
        ls[j].style.fontSize = '13px';
        ls[j].style.whiteSpace = 'nowrap';
        ls[j].style.gap = '6px';
      }
    }
  }

  // The homepage update-history table is Korean-only API content that cannot be
  // statically translated — hide it in English mode rather than show raw Korean.
  function hideKoreanChangelog() {
    if (pathLocale() !== 'en') return;
    var tables = document.querySelectorAll('table');
    for (var i = 0; i < tables.length; i++) {
      var t = tables[i];
      var head = t.rows && t.rows[0] ? t.rows[0].textContent.replace(/\s+/g, '') : '';
      if (!/^(Date(Highlights|Updates?)|날짜)/i.test(head)) continue;
      var kr = 0, n = t.rows.length - 1;
      for (var j = 1; j < t.rows.length; j++) if (HANGUL.test(t.rows[j].textContent)) kr++;
      if (n > 0 && kr / n > 0.5) {
        // hide the whole card (heading + shell), not just the table
        var wrap = t.closest('div[class*="bg-surface-gray-surface-0"]') || t.closest('div') || t;
        if (!wrap.__msfixHidden) { wrap.__msfixHidden = true; wrap.style.display = 'none'; }
      }
    }
  }

  // Character/player names must never be translated. Names appear inside links to
  // /info?name=X and in the live-search ticker rows — skip those contexts entirely.
  function isPlayerNameContext(node) {
    var p = node.parentElement;
    for (var i = 0; i < 5 && p; i++, p = p.parentElement) {
      if (p.tagName === 'A' && /[?&]name=/.test(p.getAttribute('href') || '')) return true;
      var cls = (p.className || '').toString();
      if (cls.indexOf('text-mini') !== -1 && cls.indexOf('h-6') !== -1) return true;
    }
    return false;
  }

  // Compact boss-viability badges carry their full meaning in a hover tooltip.
  var BADGE_TITLES = {
    '6 Players': 'Minimum spec to clear with 6 players',
    '4 Players': 'Minimum spec to clear with 4 players',
    '3 Players': 'Minimum spec to clear with 3 players',
    '2 Players': 'Minimum spec to clear with 2 players',
    '3 DPS': 'Minimum spec for a party of 3 DPS players',
    '2 Players + B': 'Minimum spec for 2 DPS plus a Bishop',
    'Soloable-': 'Bare minimum spec to solo this boss',
    'Soloable+': 'You can comfortably solo this boss',
    'Partyable': 'You can clear this boss in a party (as DPS)',
    'Partyable-': 'Minimum spec to clear in a party',
    'Soloable': 'You can solo this boss',
    'N/A': "Below this boss's entry requirements"
  };

  // Nodes we render ourselves (character picker, dialogs) hold raw IGNs and labels — several
  // ASCII dictionary keys ARE player names — so the whole translation layer skips them.
  function inOwnUi(n) {
    var e = n && (n.nodeType === 1 ? n : n.parentElement);
    return !!(e && e.closest && e.closest('[data-msfix-ui]'));
  }

  function clarifiedControlLabel(text, forId, pathname) {
    pathname = featurePath(pathname);
    if (/^\/en\/result\/?$/.test(pathname)) {
      if (forId === '최초의 유산' && /^(데티2차|최초의 유산|Destiny 2nd Lib\.|First Legacy(?: Buff)?|Destiny 2 Buff)$/.test(text.trim())) return 'Destiny 2 Buff';
      if (forId === '파이렛플래그' && /^(파이렛|Ghost Pirate|Pirate's Banner)$/.test(text.trim())) return "Pirate's Banner";
    }
    if (!/^\/en\/input\/?$/.test(pathname) || forId !== 'destiny2ndSkill') return null;
    return /^(최초의 유산|First Legacy(?: Buff)?|Destiny Liberated|Destiny 2nd Transcendence|Destiny 2 Liberated)$/.test(text.trim()) ? 'Destiny 2 Liberated' : null;
  }
  function translateTextNode(node) {
    var v = node.nodeValue;
    if (!v || inOwnUi(node)) return;
    if (/^\/en\/game\/draw\/?$/.test(location.pathname) && v === '표' && node.parentElement && /draw pool|추첨 풀/.test(node.parentElement.textContent)) {
      node.nodeValue = ' entries'; return;
    }
    var label = node.parentElement && node.parentElement.closest('label[for]');
    var clarified = clarifiedControlLabel(v, label && label.htmlFor, location.pathname);
    if (clarified) { if (v !== clarified) node.nodeValue = clarified; return; }
    if (isPlayerNameContext(node)) return;
    if (translateDurationFragment(node)) return;
    if (translateRankingSeason(node)) return;
    var season = rankingSeason(v, location.pathname);
    if (season) { node.nodeValue = season; return; }
    if (translateSoulMeasure(node)) return;
    if (translateRewardFragment(node)) return;
    var r = translateString(v);
    if (r != null && r !== v) node.nodeValue = r;
    var shown = (r != null ? r : v).trim();
    if (BADGE_TITLES[shown] && node.parentElement && !node.parentElement.title) {
      node.parentElement.title = BADGE_TITLES[shown];
    }
  }

  // The farming slider emits its live number and unit as separate React nodes.
  function translateDurationFragment(node) {
    var value = node.previousSibling;
    if (!/^\/en\/exp\/monster\/?$/.test(location.pathname) || node.nodeValue !== '분' ||
        !value || value.nodeType !== 3 || !/^\d+(?:\.\d+)?$/.test(value.nodeValue)) return false;
    node.nodeValue = ' min';
    return true;
  }

  // The reward card splits one sentence around live amounts and item icons.
  // Translate its particles only in that card; never replace Korean particles globally.
  function translateRewardFragment(node) {
    if (!/^\/en\/(info|mypage)\/?$/.test(location.pathname)) return false;
    var fragments = {'에':' + ', '을':'', '을 벌 수 있습니다.':'', '을 추가로 얻을 수도 있습니다.':'', '추가로 얻을 수도 있습니다.':''};
    if (!Object.prototype.hasOwnProperty.call(fragments, node.nodeValue)) return false;
    var p = node.parentElement;
    for (var i = 0; p && i < 5; i++, p = p.parentElement) {
      if (p.tagName === 'MAIN' || p.tagName === 'BODY') break;
      if (/진짜 안 도실 건가요\?|Possible additional rewards:/.test(p.textContent) && p.textContent.length < 800) {
        node.nodeValue = fragments[node.nodeValue];
        return true;
      }
    }
    return false;
  }

  // React emits a number and its unit as separate Text nodes. Retain both nodes
  // so later stage/count updates still work. Remember an emptied stage suffix
  // so a subsequent numeric-only React update gets its English prefix again.
  var rankingMeasures = new WeakSet();
  function translateRankingSeason(node) {
    if (!/^\/en\/battle-ranking\/?$/.test(location.pathname)) return false;
    var p = node.parentElement;
    if (!p || p.getAttribute('role') !== 'tab' || p.childNodes.length !== 2) return false;
    var value = p.childNodes[0], suffix = p.childNodes[1];
    if (value.nodeType !== 3 || suffix.nodeType !== 3 || !(suffix.nodeValue === '기' || rankingMeasures.has(value))) return false;
    var m = value.nodeValue.match(/^(?:Season )?(\d+)$/);
    if (!m) return false;
    rankingMeasures.add(value);
    value.nodeValue = 'Season ' + m[1];
    suffix.nodeValue = '';
    return true;
  }

  var soulMeasures = new WeakMap();
  function translateSoulMeasure(node) {
    if (!/^\/en\/simulator\/soul\/?$/.test(location.pathname)) return false;
    var parent = node.parentElement;
    if (!parent || !parent.closest('main')) return false;
    var parts = parent.childNodes;
    if (parts.length >= 3 && parts[0].nodeType === 3 && parts[1].nodeType === 3 && parts[2].nodeType === 3 && /^\d+$/.test(parts[1].nodeValue)) {
      if (/^(소울 증폭 |Soul Amplification stage )$/.test(parts[0].nodeValue) && /^(단계|Stage|)$/.test(parts[2].nodeValue)) {
        parts[0].nodeValue = 'Soul Amplification stage ';
        parts[2].nodeValue = '';
        return true;
      }
      if (/^(재설정 |Reroll |Reroll ×)$/.test(parts[0].nodeValue) && /^(회|time\(s\)|)$/.test(parts[2].nodeValue)) {
        parts[0].nodeValue = 'Reroll ×';
        parts[2].nodeValue = '';
        return true;
      }
    }
    var whole = node.nodeValue.match(/^(\d+(?:,\d{3})*(?:\.\d+)?)(단계|회|개)$/);
    if (whole) {
      node.nodeValue = whole[2] === '단계' ? 'Stage ' + whole[1] : whole[1] + (whole[2] === '회' ? (whole[1] === '1' ? ' attempt' : ' attempts') : (whole[1] === '1' ? ' item' : ' items'));
      return true;
    }
    if (parent.childNodes.length !== 2) return false;
    var value = parent.childNodes[0], suffix = parent.childNodes[1];
    if (value.nodeType !== 3 || suffix.nodeType !== 3) return false;
    var unit = soulMeasures.get(value) || suffix.nodeValue;
    var m = value.nodeValue.match(/^(?:Stage )?(\d+(?:,\d{3})*(?:\.\d+)?)$/);
    if (!m || !/^(단계|회|개)$/.test(unit)) return false;
    soulMeasures.set(value, unit);
    var left = unit === '단계' ? 'Stage ' + m[1] : m[1];
    var right = unit === '단계' ? '' : unit === '회' ? (m[1] === '1' ? ' attempt' : ' attempts') : (m[1] === '1' ? ' item' : ' items');
    if (value.nodeValue !== left) value.nodeValue = left;
    if (suffix.nodeValue !== right) suffix.nodeValue = right;
    return true;
  }

  // Second-chance matching for paragraphs whose text is split across several
  // nodes (styled spans, <br>) or differs from the extracted literal only by
  // whitespace: match the element's combined, normalized text against the dict.
  function normKey(s) { return s.replace(/\s+/g, ' ').trim(); }

  function normIndex(d) {
    if (!d.__norm) {
      var m = {};
      for (var k in d.dict) {
        if (k.length >= 8 && HANGUL.test(k)) m[normKey(k)] = d.dict[k];
      }
      d.__norm = m;
    }
    return d.__norm;
  }

  var INLINE_TAGS = { BR: 1, SPAN: 1, B: 1, STRONG: 1, I: 1, EM: 1 };

  // Per-element replacement counter. Replacing textContent nukes React's child
  // spans; on a live-updating page React restores the Korean and we would replace
  // again — an infinite loop that freezes the tab. Capping attempts breaks it.
  var elAttempts = new WeakMap();

  function tryElementTranslate(el, d) {
    if (inOwnUi(el)) return;
    // This simulator replaces its unamplified card with a Potential card on
    // success. Preserve React's child nodes; its messages are translated by
    // the text-node layer and the stage/count handler above.
    if (/^\/en\/simulator\/soul\/?$/.test(location.pathname)) return;
    var kids = el.children;
    if (kids.length > 8) return;
    for (var i = 0; i < kids.length; i++) if (!INLINE_TAGS[kids[i].tagName]) return;
    var txt = el.textContent;
    // A single child already contains the whole phrase. Translate that child
    // without detaching it: React reuses the boss-plan span when A/B changes.
    if (kids.length === 1 && kids[0].textContent === txt) return;
    if (!txt || txt.length < 8 || txt.length > 500 || !HANGUL.test(txt)) return;
    var tries = elAttempts.get(el) || 0;
    if (tries >= 2) return; // stop fighting a React re-render
    var idx = normIndex(d);
    var key = normKey(txt);
    var hit = idx[key];
    if (hit == null && key.charAt(key.length - 1) === ')') {
      // many extracted literals are missing their closing paren
      var h0 = idx[key.slice(0, -1)];
      if (h0 != null) hit = h0 + (/\([^)]*$/.test(h0) ? ')' : '');
    }
    if (hit && hit !== txt) { el.textContent = hit; elAttempts.set(el, tries + 1); }
  }

  var ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];

  // Presentation-only fallback for slots explicitly marked unreleased by the site.
  // Do not change the shared catalog: empty URLs are also used to filter calculations.
  var UNRELEASED_ICON = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><rect x="3" y="3" width="42" height="42" rx="8" fill="none" stroke="#888" stroke-width="2" stroke-dasharray="4 3"/><path d="M16 24h16" stroke="#aaa" stroke-width="3" stroke-linecap="round"/></svg>');
  var unreleasedImages = new WeakMap();
  function repairUnreleasedImage(img) {
    if (img.tagName !== 'IMG') return;
    var src = img.getAttribute('src') || '', alt = img.getAttribute('alt') || '';
    var old = unreleasedImages.get(img);
    if (old && src !== UNRELEASED_ICON) {
      if (alt === old.shown) img.setAttribute('alt', old.alt);
      unreleasedImages.delete(img);
      alt = img.getAttribute('alt') || '';
    }
    var card = img.closest('[data-msfix-card-help]');
    var title = card ? card.getAttribute('data-msfix-buff-title') : alt;
    var marked = /^(?:(?:HEXA: |hexa-)?(?:미출시|XXX|Unreleased(?: Mastery Skill)?))$/i.test(title || '');
    if (!marked || (src && src !== '/icon/icon_guide.png' && src !== UNRELEASED_ICON && !/^\/hexaskill\/[\w/.-]+\.png$/.test(src))) return;
    var shown = /Mastery|XXX/.test(title) ? 'Unreleased Mastery Skill' : 'Unreleased Skill';
    if (src !== UNRELEASED_ICON) {
      unreleasedImages.set(img, {alt:img.getAttribute('alt') || '', shown:shown});
      img.setAttribute('src', UNRELEASED_ICON);
    }
    if (img.getAttribute('alt') !== shown) img.setAttribute('alt', shown);
  }

  function translateAttrs(el) {
    if (inOwnUi(el)) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i];
      var v = el.getAttribute && el.getAttribute(a);
      if (v) {
        var r = translateString(v);
        if (r != null && r !== v) el.setAttribute(a, r);
      }
    }
    repairUnreleasedImage(el);
  }

  function markBossPlanPopovers(root) {
    if (!root.querySelectorAll) return;
    var selector = '[data-slot="popover-content"]';
    var popovers = Array.from(root.querySelectorAll(selector));
    if (root.matches && root.matches(selector)) popovers.push(root);
    popovers.forEach(function (el) {
      if (!el.hasAttribute('data-msfix-burst-plan') && /페이즈별 극딜 횟수|Burst windows per phase/.test(el.textContent)) {
        el.setAttribute('data-msfix-burst-plan', '');
      }
    });
  }

  function processTree(root) {
    if (pathLocale() !== 'en') return; // dormant on the Korean/Japanese/Chinese site
    if (inOwnUi(root)) return;
    if (root.nodeType === 3) { translateTextNode(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 11) return;
    var tag = root.nodeName;
    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'TEXTAREA') return;
    markBossPlanPopovers(root);
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        var p = n.parentNode;
        if (!p) return NodeFilter.FILTER_REJECT;
        var t = p.nodeName;
        if (t === 'SCRIPT' || t === 'STYLE' || t === 'NOSCRIPT' || t === 'TEXTAREA') return NodeFilter.FILTER_REJECT;
        return n.nodeValue && n.nodeValue.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    // element-level pass FIRST — split paragraphs must match before the
    // per-node pass translates fragments inside them
    var d = data();
    var ew = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, {
      acceptNode: function (el) {
        var t = el.nodeName;
        if (t === 'SCRIPT' || t === 'STYLE' || t === 'NOSCRIPT' || t === 'TEXTAREA') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    // Bound the work of a single (possibly huge) subtree so one processTree call
    // can never pin the CPU — a giant modal gets partial translation, not a freeze.
    var MAX = 2500, budget = MAX;
    if (root.nodeType === 1) tryElementTranslate(root, d);
    while (budget-- > 0 && ew.nextNode()) tryElementTranslate(ew.currentNode, d);
    var nodes = [], tbudget = MAX;
    while (tbudget-- > 0 && walker.nextNode()) nodes.push(walker.currentNode);
    for (var i = 0; i < nodes.length; i++) translateTextNode(nodes[i]);
    if (root.querySelectorAll) {
      if (root.nodeType === 1) translateAttrs(root);
      var els = root.querySelectorAll('[placeholder],[title],[aria-label],[alt]');
      for (var j = 0; j < els.length; j++) translateAttrs(els[j]);
    }
  }

  var observer = null;
  // Mutations are queued and drained during idle time with a time budget, rather
  // than processed synchronously inside the observer callback. On data-heavy pages
  // (e.g. the boss result page) React fires a torrent of mutations; processing them
  // inline froze the tab. Idle-time draining keeps the page responsive.
  var qAdded = new Set(), qChar = new Set(), qAttr = new Set(), qRemoved = [];
  var flushScheduled = false;
  var scheduleImpl = window.requestIdleCallback
    ? function (f) { window.requestIdleCallback(f, { timeout: 400 }); }
    : function (f) { setTimeout(function () { f({ timeRemaining: function () { return 8; } }); }, 50); };

  function scheduleFlush() { if (!flushScheduled) { flushScheduled = true; scheduleImpl(flush); } }

  function flush(deadline) {
    flushScheduled = false;
    // tooltip pinning must react to removals regardless of locale
    for (var r = 0; r < qRemoved.length; r++) onFloatingRemoved(qRemoved[r]);
    qRemoved.length = 0;
    var en = pathLocale() === 'en';
    if (!en) { qAdded.clear(); qChar.clear(); qAttr.clear(); return; }
    var start = Date.now();
    var hasTime = function () { return deadline && deadline.timeRemaining ? deadline.timeRemaining() > 3 : Date.now() - start < 25; };
    observer.disconnect(); // don't let our own writes re-trigger us
    try {
      var added = []; qAdded.forEach(function (n) { added.push(n); }); qAdded.clear();
      var ai = 0;
      for (; ai < added.length; ai++) { trackFloating(added[ai]); processTree(added[ai]); if (!hasTime()) { ai++; break; } }
      for (; ai < added.length; ai++) qAdded.add(added[ai]);
      if (hasTime()) {
        var chars = []; qChar.forEach(function (n) { chars.push(n); }); qChar.clear();
        var ci = 0;
        for (; ci < chars.length; ci++) { translateTextNode(chars[ci]); if (!hasTime()) { ci++; break; } }
        for (; ci < chars.length; ci++) qChar.add(chars[ci]);
      }
      if (hasTime()) {
        var attrs = []; qAttr.forEach(function (n) { attrs.push(n); }); qAttr.clear();
        var xi = 0;
        for (; xi < attrs.length; xi++) { if (attrs[xi].nodeType === 1) translateAttrs(attrs[xi]); if (!hasTime()) { xi++; break; } }
        for (; xi < attrs.length; xi++) qAttr.add(attrs[xi]);
      }
      fixLogo();
    } catch (e) {} finally {
      observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(['src']) });
    }
    if (qAdded.size || qChar.size || qAttr.size) scheduleFlush();
  }

  // Full-tree sweep that hides its own writes from the observer. A sweep that
  // runs while the observer is attached re-queues every text node it rewrote and
  // translates it a second time, so a dictionary entry whose value is itself a
  // key ("6p Min Cut" -> "6-Player Min Spec" -> "6 Players") would show a
  // different text after a navigation than on the first load.
  function sweepTree(root) {
    if (!observer) { processTree(root); return; }
    observer.disconnect();
    try { processTree(root); } finally {
      observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS.concat(['src']) });
    }
  }

  function startDomLayer() {
    if (observer) return;
    // The observer is ALWAYS attached (even on /ko) so that switching language via
    // the SPA selector — no page reload — still translates dynamically-mounted
    // content. All translate entry points no-op unless the path is /en.
    processTree(document.body);
    observer = new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (m.type === 'childList') {
          for (var k = 0; k < m.removedNodes.length; k++) qRemoved.push(m.removedNodes[k]);
          for (var j = 0; j < m.addedNodes.length; j++) qAdded.add(m.addedNodes[j]);
        } else if (m.type === 'characterData') qChar.add(m.target);
        else if (m.type === 'attributes') qAttr.add(m.target);
      }
      scheduleFlush();
    });
    observer.observe(document.body, {
      childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ATTRS.concat(['src'])
    });
  }

  /* ---------------- GMS Link Skill suggestions ---------------------------------------- */
  // The native efficiency list is KMS-only even though the optimizer has GMS candidates.
  // Read the native rows and merge our estimates into a separate, non-interactive list.
  // Never mutate React's children, the calculation response, or the character's saved stats.
  var gmsLinkView = null;
  var gmsLinkTimer = null;
  var gmsLinkMaxLevel = false;
  var GMS_LINKS = [
    { id: 'shine', name: 'Guiding Stars', ko: 'Guiding Stars', owners: ['시아', '에렐'], icon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAKuSURBVFhHvZdhsaRADISx8CyshbWABSxgAQtYGAtYwAIWsICFufrCNBtmM/y77apUSNJJegbe1l3X3ZF/ZCHyuu0/sUiEFX6FedluIq7lwzjnbllydxyXB4pfy5o7BuSc18DIU++2PfdTyv04f80krkVcAqKlNrD4qSyyWsOow4OP4Hc6Z159y/IgoBDB1RAsfsKXkGAmiAWUG6iX14sVR1ZzvAjLPd3A7X3pnQZDydffgXKRkCvvXnFTgL2zxnIt+nPmY/+B1r31vFAAX+4rrYWs5k+jPe+HmZaTkwjVfK+8iXK5poCL7Jq/BBUB4uH/JK5eWs8pu0IB0elbw2teHcOvc5oFQgEUTXX5UcTbEF2t2afWfj65LwlTrcQgFHAj7zmnnPO7nAaPkRMHEAu+h+WY5+M5IAgFbNxCIeMTS/fTeFZdHEBNUA2eeuuZxKAp4FXIeOK+LCdWDSzHWeu2D0cQV6LrmaAtoDDwEoCxUHVxADVBNcoSGM0ETQHvwsAzZOBat9Nj5MQBxELU4/n4RwE12YZxqvVjvt56FpfeaCYIBYwo5OpKA35lAIvX7/xTDL/OMZsdIBTQp82ahvK3gt+PnCeu0+UYTo6a55Cve31sgpZzVyhgmJbbYDX6574YPIm1wa7m+fLM5PTDdP5yxALGdA2sh7AQ84skwue9MOFz+uNZwFia8DT4GOMU5OctNmp20sKvZw1pt0M2BfDvgcmImw3koyEWeMbIYyzDFKvu+crbd8L3U367mwL6dBLHtOXkRNSD55LzVtfpxbMc4IlBKIDlasAjQjehnAZEUF23wgF8Ds8O40YCIrX8ZYzzet7GfhdSm1+sw3hh5B7/X6Dr1/tSA18uhhC7kSLEmxYj2Phjuubhr1mBgJuIX6Befomg8AuLlgsq/m+78A9TzBDu4ec1tQAAAABJRU5ErkJggg==", crit: [4, 6], baseLevel: 4, maxLevel: 6, note: 'Sia Astelle + Erel Light. +4% Critical Damage, +13% Buff Duration. Score excludes buff duration.', upgradeNote: 'Sia Astelle + Erel Light: +2% Critical Damage, +6% Buff Duration. Score excludes buff duration.' },
    { id: 'hayato', name: 'Moonlit Blade Learnings', ko: '창인전수', aliases: ['Moonlight Blade Learnings'], owners: ['하야토'], icon: 'https://open.api.nexon.com/static/maplestorysea/skill/icon/KFHCLHOBMD', crit: [5, 7], note: 'Requires at least 100% critical rate and 50% critical damage.' },
    { id: 'kanna', name: 'Elementalism', ko: '자선전수', owners: ['칸나'], icon: 'https://open.api.nexon.com/static/maplestorysea/skill/icon/KFHCLHOBME', damage: [15, 20], note: 'Active for 12 seconds after 40 attack-skill uses.' },
    { id: 'lynn', name: 'Focus Spirit', ko: '수호신의 가호', aliases: ['Spirit Guide Blessing'], owners: ['린'], icon: '/linkskill/lynn.png', boss: [7, 11], rate: [7, 10], hp: [4, 5], note: 'Boss damage and Max HP/MP. Extra critical rate contributes through Vicious Shot.' },
    { id: 'mukhyun', name: 'Qi Cultivation', ko: '기백', aliases: ['Vigor', 'Grounded Body'], owners: ['묵현'], icon: '/linkskill/mukhyun.png', boss: [4, 6], stacks: [2, 3], note: 'Gains a stack every 2 seconds of boss attacks, up to six. Stacks last 5 seconds.' }
  ];
  function gmsLinkName(s) { return String(s || '').replace(/[’‘]/g, "'").replace(/\([^)]*\)|\d+/g, '').trim().toLowerCase(); }
  function gmsLinkEstimates(us, info, eff, upgrade, classData) {
    if (!us || !us.isGMS || us.isTMS || us.isJMS || us.isMSEA || !us.stat || !eff) return [];
    var cls = us.stat.myClass;
    var archers = ['보우마스터', '신궁', '패스파인더', '윈드브레이커', '메르세데스', '와일드헌터', '카인'];
    // The native table uses criInP, falling back to 0.235 for Vicious Shot classes.
    var vicious = archers.indexOf(cls) >= 0 ? Number(classData && classData.criInP) || 0.235 : 0;
    var equipped = info && info.settings && info.settings.now_link || [];
    return GMS_LINKS.filter(function (s) { return s.owners.indexOf(cls) < 0; }).map(function (s) {
      var aliases = [s.name, s.ko].concat(s.aliases || []).map(gmsLinkName);
      var eq = equipped.find(function (e) { return aliases.indexOf(gmsLinkName(e.skill_name)) >= 0; });
      var level = eq ? Number(eq.skill_level) : 0;
      var baseLevel = s.baseLevel || 2, maxLevel = s.maxLevel || 3;
      if (!Number.isInteger(level) || level < 0 || level > maxLevel || (upgrade && level >= maxLevel)) return null;
      var from = upgrade ? 0 : -1, to = upgrade ? 1 : 0;
      var diff = function (a) { return a ? a[to] - (from < 0 ? 0 : a[from]) : 0; };
      var blocked = s.id === 'hayato' && !(Number(us.stat.critical) >= 100 && Number(us.stat.criticalDmg) >= 50);
      var dmg = diff(s.damage) + diff(s.boss) + 6 * diff(s.stacks);
      var crit = diff(s.crit) + (vicious ? diff(s.rate) * vicious : 0);
      var hp = cls === '데몬어벤져' ? diff(s.hp) : 0;
      var terms = [[dmg, eff.dmgeff1], [crit, eff.cridmgeff1], [hp, eff.mainStatPereff1]];
      var gain = 0;
      for (var i = 0; i < terms.length; i++) {
        if (!terms[i][0]) continue;
        if (!Number.isFinite(terms[i][1]) || terms[i][1] < 0) return null;
        gain += terms[i][0] * terms[i][1];
      }
      // Equipped links use the same removal-and-restore convention as the native table.
      // Do not apply that correction to a Lv.2 -> Lv.3 increment.
      if (!upgrade && (level === baseLevel || s.id === 'shine')) {
        var removed = s.id === 'shine' ? level * eff.cridmgeff1 : gain;
        if (removed >= 1) return null;
        gain /= 1 - removed;
      }
      var note = upgrade && s.upgradeNote || s.note;
      if (s.id === 'lynn' && !vicious) note += ' Critical rate is not scored for this character.';
      if (blocked) note = 'Requirements not met in these inputs: 100% critical rate and 50% critical damage.';
      return { id: s.id, name: s.name, icon: s.icon, value: blocked ? 0 : Math.round(gain * 100000) / 1000,
        note: note, label: 'GMS Lv. ' + baseLevel + (upgrade ? ' → ' + maxLevel : '') };
    }).filter(function (s) { return s && Number.isFinite(s.value) && s.value >= 0; });
  }
  function gmsLinkContext() {
    var manual = /^\/(ko|en|ja|ch)\/manual\/result\/?$/.test(location.pathname) || new URLSearchParams(location.search).get('manual') === 'true';
    var store = manual ? siteRefs.manualStore : siteRefs.characterStore;
    if (!store) return null;
    var st = store.getState();
    var res = manual ? st.result : st.searchResult;
    if (!res || !res.userStat || !res.simulatorData || !res.simulatorData.specEfficiency) return null;
    return { us: res.userStat, info: manual ? null : res.userApiData, eff: res.simulatorData.specEfficiency, classData: res.simulatorData.myClassData };
  }
  function maxLevelLinkEstimates(us, info, eff, boss380, classData) {
    if (!us || !us.isGMS || us.isTMS || us.isJMS || us.isMSEA || !us.stat || !eff) return [];
    var cls = us.stat.myClass, equipped = info && info.settings && info.settings.now_link || [];
    var archers = ['보우마스터', '신궁', '패스파인더', '윈드브레이커', '메르세데스', '와일드헌터', '카인'];
    var vicious = archers.indexOf(cls) >= 0 ? Number(classData && classData.criInP) || 0.235 : 0;
    return (data().linkMaxLevels || []).filter(function (s) { return s.owners.indexOf(cls) < 0; }).map(function (s) {
      var name = s.name || translateString(s.ko) || s.ko;
      var names = [name, s.ko].concat(s.aliases || []).map(gmsLinkName);
      var eq = equipped.find(function (e) { return names.indexOf(gmsLinkName(e.skill_name)) >= 0; });
      var current = eq ? Number(eq.skill_level) : 0;
      if (!Number.isInteger(current) || current < 0 || current > s.maxLevel) return null;
      var effect = function (key, level) { return s.effects[key] ? s.effects[key][level] : 0; };
      var currentIed = effect('ied', current), iedBase = 1 - currentIed / 100;
      // Remove an equipped link from the comparison baseline. IED stacks
      // multiplicatively, so its removal is not the negative of adding it.
      function contribution(level) {
        var terms = [
          [(effect('damage', level) * (s.damageWeight || 1)) + effect('boss', level), eff.dmgeff1],
          [effect('crit', level) + vicious * effect('rate', level), eff.cridmgeff1],
          [effect('allStat', level), eff.allStatEff],
          [effect('attack', level), eff.atkeff1],
          [effect('ied', level) / iedBase, boss380 ? eff.igreff1_380 : eff.igreff1]
        ];
        if (cls === '데몬어벤져') {
          terms.push([effect('hp', level), eff.mainStatPereff1], [effect('flatHp', level), eff.mainStateff1]);
        } else {
          ['mainStateff1', 'subStateff1', 'ssubStateff1'].forEach(function (key) { terms.push([effect('flatStat', level), eff[key]]); });
        }
        var total = 0;
        for (var term of terms) {
          if (!term[0]) continue;
          if (!Number.isFinite(term[0]) || !Number.isFinite(term[1]) || term[1] < 0) return NaN;
          total += term[0] * term[1];
        }
        return total;
      }
      var removed = contribution(current), gain = contribution(s.maxLevel);
      if (!Number.isFinite(removed) || !Number.isFinite(gain) || removed >= 1 || iedBase <= 0) return null;
      gain /= 1 - removed;
      var blocked = s.requiresCritical && !(Number(us.stat.critical) >= 100 && Number(us.stat.criticalDmg) >= 50);
      if (blocked) gain = 0;
      if (!gain && !blocked) return null; // Utility-only effects have no damage rank.
      return { name:name, icon:s.icon, value:Math.round(gain * 100000) / 1000,
        note:blocked ? 'Requires 100% critical rate and 50% critical damage.' : s.note,
        label:'Lv. ' + s.maxLevel, ko:s.ko };
    }).filter(function (row) { return row && Number.isFinite(row.value); });
  }
  function readNativeLinkRows(list) {
    var rows = [], children = Array.from(list.children);
    if (!children.length) return null;
    for (var row of children) {
      if (row.querySelector('button, input, a, [role="button"]')) return null;
      var last = row.lastElementChild, value = last && last.textContent.trim();
      if (!/^\d+(?:\.\d+)?%$/.test(value || '')) return null;
      var skills = Array.from(row.querySelectorAll('img[alt]'));
      if (!skills.length) return null;
      for (var img of skills) {
        var tip = img.closest('[title]');
        rows.push({ name: img.alt, icon: img.getAttribute('src'), value: Number(value.slice(0, -1)), note: tip ? tip.title : img.alt });
      }
    }
    return rows;
  }
  function clearGmsLinkView() {
    if (!gmsLinkView) return;
    gmsLinkView.observer.disconnect();
    gmsLinkView.native.style.display = gmsLinkView.display;
    gmsLinkView.upgrade.removeEventListener('click', gmsLinkView.onUpgrade);
    if (gmsLinkView.heading) gmsLinkView.heading.removeAttribute('data-msfix-link-heading');
    gmsLinkView.maxControl.remove();
    gmsLinkView.root.remove();
    gmsLinkView = null;
  }
  function scheduleGmsLinks() {
    if (gmsLinkTimer) return;
    gmsLinkTimer = setTimeout(function () { gmsLinkTimer = null; ensureGmsLinks(); }, 80);
  }
  function ensureGmsLinks() {
    var ctx = gmsLinkContext();
    if (!/\/result$/.test(location.pathname) || pathLocale() !== 'en' || !ctx || !ctx.us.isGMS || ctx.us.isTMS || ctx.us.isJMS || ctx.us.isMSEA) { clearGmsLinkView(); return; }
    var checkbox = document.getElementById('380-boss-checkbox');
    var header = checkbox && checkbox.parentElement && checkbox.parentElement.parentElement;
    var panel = header && header.parentElement;
    var native = panel && Array.from(panel.children).find(function (el) { return el !== header && el.classList.contains('grid') && !el.hasAttribute('data-msfix-ui'); });
    var upgrade = panel && panel.querySelector('#Lv-23-checkbox');
    if (!native || !upgrade) { clearGmsLinkView(); return; }
    var original = readNativeLinkRows(native);
    if (!original) { clearGmsLinkView(); return; }
    if (gmsLinkView && gmsLinkView.native !== native) clearGmsLinkView();
    if (!gmsLinkView) {
      var root = document.createElement('div');
      root.setAttribute('data-msfix-ui', 'gms-links'); root.className = 'msfix-gms-links';
      var list = document.createElement('ol'); list.className = 'msfix-gms-link-list'; list.setAttribute('aria-label', 'Link Skill efficiency including GMS');
      root.appendChild(list);
      native.after(root);
      var maxControl = document.createElement('div');
      maxControl.className = 'msfix-link-max-control'; maxControl.setAttribute('data-msfix-ui', '');
      var maxToggle = document.createElement('button'); maxToggle.type = 'button';
      maxToggle.id = 'msfix-link-max-level'; maxToggle.className = upgrade.className;
      maxToggle.setAttribute('role', 'checkbox'); maxToggle.setAttribute('data-slot', 'checkbox');
      var mark = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      mark.setAttribute('viewBox', '0 0 24 24'); mark.setAttribute('fill', 'none'); mark.setAttribute('stroke', 'currentColor');
      mark.setAttribute('stroke-width', '3'); mark.setAttribute('aria-hidden', 'true');
      var tick = document.createElementNS('http://www.w3.org/2000/svg', 'path'); tick.setAttribute('d', 'M5 12l4 4L19 6'); mark.appendChild(tick);
      maxToggle.appendChild(mark);
      var maxLabel = document.createElement('label'); maxLabel.htmlFor = maxToggle.id; maxLabel.textContent = 'Max level';
      maxControl.append(maxToggle, maxLabel); upgrade.parentElement.before(maxControl);
      var heading = Array.from(header.children).find(function (el) { return el.textContent.trim() === 'Link Skill Eff' && !el.querySelector('button, input'); });
      if (heading) heading.setAttribute('data-msfix-link-heading', '');
      var onUpgrade = function () { gmsLinkMaxLevel = false; scheduleGmsLinks(); };
      upgrade.addEventListener('click', onUpgrade);
      maxToggle.addEventListener('click', function () {
        var next = !gmsLinkMaxLevel;
        if (next && upgrade.getAttribute('aria-checked') === 'true') upgrade.click();
        gmsLinkMaxLevel = next; ensureGmsLinks();
      });
      var obs = new MutationObserver(scheduleGmsLinks);
      obs.observe(panel, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['aria-checked', 'title', 'alt', 'src'] });
      gmsLinkView = { native: native, root: root, list: list, observer: obs, display: native.style.display, fingerprint: '',
        maxControl:maxControl, maxToggle:maxToggle, upgrade:upgrade, onUpgrade:onUpgrade, heading:heading };
    }
    var view = gmsLinkView;
    var maxState = gmsLinkMaxLevel ? 'true' : 'false';
    if (view.maxToggle.getAttribute('aria-checked') !== maxState) {
      view.maxToggle.setAttribute('aria-checked', maxState);
      view.maxToggle.setAttribute('data-state', gmsLinkMaxLevel ? 'checked' : 'unchecked');
      view.maxToggle.firstElementChild.style.visibility = gmsLinkMaxLevel ? 'visible' : 'hidden';
    }
    var isUpgrade = upgrade.getAttribute('aria-checked') === 'true';
    var added = gmsLinkEstimates(ctx.us, ctx.info, ctx.eff, isUpgrade, ctx.classData);
    if (!added.length) { clearGmsLinkView(); return; }
    var known = new Set(original.map(function (r) { return gmsLinkName(r.name); }));
    added = added.filter(function (s) {
      var def = GMS_LINKS.find(function (d) { return d.id === s.id; });
      return ![def.name, def.ko].concat(def.aliases || []).some(function (name) { return known.has(gmsLinkName(name)); });
    });
    // The native optimizer excludes Lethe outside KMS; its efficiency table forgot to.
    original = original.filter(function (r) { return ['covenant', '커버넌트'].indexOf(gmsLinkName(r.name)) < 0; });
    var rows = gmsLinkMaxLevel ? maxLevelLinkEstimates(ctx.us, ctx.info, ctx.eff, checkbox.getAttribute('aria-checked') === 'true', ctx.classData) : original.concat(added);
    rows.sort(function (a, b) { return b.value - a.value; });
    var fp = JSON.stringify(rows);
    if (view.fingerprint === fp) return;
    view.fingerprint = fp;
    // Disconnect while writing our own sibling to avoid MutationObserver feedback loops.
    view.observer.disconnect();
    view.list.replaceChildren();
    rows.forEach(function (s) {
      var li = document.createElement('li');
      var img = document.createElement('img'); img.src = s.icon; img.alt = ''; img.width = 24; img.height = 24;
      img.addEventListener('error', function () { img.hidden = true; }, { once: true });
      var name = document.createElement('span'); name.className = 'msfix-gms-link-name'; name.textContent = s.name;
      var value = document.createElement('span'); value.className = 'msfix-gms-link-value'; value.textContent = s.value + '%';
      li.title = s.note; li.tabIndex = 0; li.setAttribute('aria-label', s.name + ': ' + s.value + '%. ' + (s.label || '') + ' ' + s.note);
      li.append(img, name);
      if (s.label) { var badge = document.createElement('small'); badge.textContent = s.label; li.append(badge); }
      li.append(value); view.list.append(li);
    });
    native.style.display = 'none';
    view.observer.observe(panel, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['aria-checked', 'title', 'alt', 'src'] });
  }

  /* ---------------- 4b. Selective input help ----------------------------------------- */
  function cardHelp(props) {
    var catalog = data().checkboxHelp || {}, image = props.imageUrl || '';
    var handler = props.inputProps && props.inputProps.onChange;
    var code = typeof handler === 'function' ? Function.prototype.toString.call(handler) : '';
    var rule = (catalog.cards || []).concat(catalog.rules || []).find(function (r) {
      return r.image && image.indexOf(r.image) !== -1 && (!r.key || code.indexOf(r.key) !== -1);
    });
    var title = rule && rule.title || translateString(props.tooltip) || props.tooltip;
    if (props.tooltip === 'XXX' && image === '/icon/icon_guide.png') title = 'Unreleased Mastery Skill';
    var detail = rule && rule.text || '';
    if (rule && typeof rule.factor === 'number') {
      var raw = props.inputProps && props.inputProps.value, level = Number(raw);
      if (raw === '' || raw == null || !Number.isFinite(level) || level < 0 || level > rule.max) {
        detail = 'Range: 0–' + rule.max + '.';
      } else {
        detail = (rule.level ? 'Lv. ' + level + ': ' : '') + '+' + (level * rule.factor) + rule.unit;
        if (rule.hpFactor) detail += ', +' + (level * rule.hpFactor).toLocaleString('en-US') + ' Max HP/MP';
        detail += '.';
        if (rule.toggle && props.active === false) detail = 'Inactive. ' + detail;
      }
    }
    return {title:title, detail:detail};
  }
  // Combine a buff's native name and our detail before React renders the card.
  // Keep the original image, controls, props and event handlers. Unknown layouts stay native.
  function combinedBuffTree(tree, props) {
    var R = siteRefs.react;
    if (pathLocale() !== 'en' || !/\/(input|result)\/?$/.test(location.pathname) || !R || !R.cloneElement || !siteRefs.tooltip || !siteRefs.createRoot) return tree;
    if (!props || typeof props.tooltip !== 'string' || !props.tooltip.trim()) return tree;
    if (!tree || tree.type !== 'div' || !tree.props || !Array.isArray(tree.props.children)) return tree;
    var kids = tree.props.children, pair = kids[0] && kids[0].props && kids[0].props.children;
    if (!Array.isArray(pair) || pair.length !== 2 || !pair[0].props || !pair[1].props || pair[1].props.children !== props.tooltip || !pair[0].props.children) return tree;
    var help = cardHelp(props);
    return R.cloneElement(tree, {'data-msfix-card-help':'', 'data-msfix-buff-title':help.title, 'data-msfix-buff-detail':help.detail}, [pair[0].props.children].concat(kids.slice(1)));
  }
  function patchBuffExports(ex) {
    if (!ex || typeof ex !== 'object') return ex;
    var keys = Object.keys(ex); if (keys.length > 4) return ex;
    var replacements = {};
    keys.forEach(function (key) {
      var fn = ex[key]; if (typeof fn !== 'function' || fn.__msfixBuff) return;
      var code = Function.prototype.toString.call(fn);
      if (code.length > 5000 || !['imageUrl:', 'checkboxProps:', 'radioProps:', 'tooltip:', 'inputProps:'].every(function (part) { return code.indexOf(part) !== -1; })) return;
      var wrapped = function (props) { return combinedBuffTree(fn.apply(this, arguments), props); };
      wrapped.__msfixBuff = true;
      replacements[key] = wrapped;
    });
    if (!Object.keys(replacements).length) return ex;
    var result = {};
    Reflect.ownKeys(ex).forEach(function (key) {
      Object.defineProperty(result, key, Object.prototype.hasOwnProperty.call(replacements, key) ? {enumerable:true, value:replacements[key]} : Object.getOwnPropertyDescriptor(ex, key));
    });
    return result;
  }
  var CHECK_HELP_SELECTOR = '[role="checkbox"], [role="switch"], input[type="checkbox"]';
  var checkHelpRecords = new Map(), checkHelpTargets = new WeakMap(), checkHelpCounter = 0;
  var checkHelpActive = null, checkHelpHover = null, checkHelpFocus = null, checkHelpTimer = 0;
  var checkHelpRoot = null, checkHelpRenderKey = '', checkHelpLast = null, checkHelpPointerFocus = false;
  var checkHelpWasOpen = false, checkHelpSkipEnter = false;
  var FIELD_HELP_SELECTOR = 'span, label';
  function helpNormalize(s) { return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }
  function helpVariants(s) {
    var d = data(), bundle = siteRefs.enBundle || {};
    return [s, d.i18nPatch[s], d.dict[s], bundle[s]].filter(function (x) { return typeof x === 'string'; }).map(helpNormalize);
  }
  // Pure resolver: route and role disambiguate reused IDs (notably destiny-checkbox).
  function resolveCheckboxHelp(info, catalog, variants) {
    variants = variants || function (s) { return [helpNormalize(s)]; };
    var label = helpNormalize(info.label), context = helpNormalize(info.context);
    function matchesText(keys, haystack, contains) {
      return keys.some(function (k) { return variants(k).some(function (v) { return v && (contains ? haystack.indexOf(v) !== -1 : haystack === v); }); });
    }
    for (var i = 0; i < catalog.length; i++) {
      var r = catalog[i];
      if (r.routes && r.routes.indexOf(info.route) === -1) continue;
      if (r.role && r.role !== info.role) continue;
      if (r.ids && r.ids.indexOf(info.id) === -1) continue;
      if (r.idPrefix && !info.id.startsWith(r.idPrefix)) continue;
      if (r.idSuffix && !info.id.endsWith(r.idSuffix)) continue;
      if (r.image && info.image.indexOf(r.image) === -1) continue;
      if (r.labels && !matchesText(r.labels, label, false)) continue;
      if (r.context && !matchesText(r.context, context, true)) continue;
      return { text: r.text, title: r.title, detail: r.detail, name: r.name || info.label };
    }
    return null; // Never invent a calculation effect for an unrecognized control.
  }
  function checkboxInfo(control) {
    var scope = control.closest('label') || control.parentElement, labelNode = null;
    if (!scope) return null;
    // Prefer the adjacent label. The site reuses IDs, so document.querySelector is unsafe here.
    if (control.id) labelNode = Array.from(scope.querySelectorAll('label')).find(function (l) { return l.htmlFor === control.id; }) || null;
    if (!labelNode && scope.tagName === 'LABEL') labelNode = scope;
    var label = labelNode ? labelNode.textContent : control.getAttribute('aria-label') || control.textContent;
    if (!label || !label.trim()) {
      for (var n = scope, depth = 0; n && depth < 3; n = n.parentElement, depth++) {
        if (n.querySelectorAll(CHECK_HELP_SELECTOR).length > 1) break;
        if (n.textContent.trim() && n.textContent.trim().length < 150) { scope = n; label = n.textContent; break; }
      }
    }
    var image = scope.querySelector('img'), imageUrl = image ? image.getAttribute('src') || '' : '';
    try { imageUrl = decodeURIComponent(imageUrl); } catch (_) {}
    return { route: featurePath(location.pathname).replace(/^\/(en|ko|ja|ch)(?=\/|$)/, '') || '/', id: control.id || '', role: control.getAttribute('role') || 'checkbox', label: (label || '').trim(), context: scope.textContent.trim(), image: imageUrl, labelNode: labelNode, scope: scope };
  }
  function checkHelpDescription(control, info) {
    var result = resolveCheckboxHelp(info, (data().checkboxHelp || {}).rules || [], helpVariants);
    return result;
  }
  function hasNativeHelp(element) {
    return !!element.closest('[data-slot="tooltip-trigger"], [data-slot="hover-card-trigger"], [title]:not([title=""])');
  }
  function ensureCardHelp(card) {
    var title = card.getAttribute('data-msfix-buff-title'), detail = card.getAttribute('data-msfix-buff-detail') || '';
    if (!title || !card.isConnected) return null;
    var rec = checkHelpRecords.get(card);
    if (!rec) {
      var node = document.createElement('div'); node.id = 'msfix-check-help-' + (++checkHelpCounter);
      node.className = 'msfix-check-help'; node.setAttribute('data-msfix-ui', ''); node.hidden = true; document.body.appendChild(node);
      rec = {control:card, anchor:card, node:node, targets:[card], described:[], card:true};
      checkHelpRecords.set(card, rec); checkHelpTargets.set(card, rec);
    }
    rec.title = title; rec.detail = detail;
    var copy = title + (detail ? '. ' + detail : '');
    if (rec.node.textContent !== copy) rec.node.textContent = copy;
    Array.from(card.querySelectorAll('input, [role="checkbox"], [role="radio"]')).forEach(function (control) {
      var ids = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
      if (ids.indexOf(rec.node.id) === -1) { ids.push(rec.node.id); control.setAttribute('aria-describedby', ids.join(' ')); }
      if (rec.described.indexOf(control) === -1) rec.described.push(control);
    });
    return rec;
  }
  function ensureCheckboxHelp(control) {
    if (pathLocale() !== 'en' || !control.isConnected || control.getAttribute('aria-hidden') === 'true' || control.type === 'hidden') return null;
    if (control.closest('[data-msfix-ui]') && !control.closest('.msfix-gms-links')) return null;
    var card = control.closest('[data-msfix-card-help]');
    if (card) return ensureCardHelp(card);
    if (hasNativeHelp(control)) {
      var old = checkHelpRecords.get(control); if (old) removeCheckboxHelp(control, old);
      return null;
    }
    var info = checkboxInfo(control); if (!info) return null;
    var help = checkHelpDescription(control, info), rec = checkHelpRecords.get(control);
    // If a buff could not be combined safely, leave its original tooltip alone.
    var buffTitle = info.scope.getAttribute('data-msfix-buff-title');
    if (!buffTitle && info.scope.querySelector('[data-slot="tooltip-trigger"], [data-slot="hover-card-trigger"]')) help = null;
    if (!help) { if (rec) removeCheckboxHelp(control, rec); return null; }
    if (!rec) {
      var node = document.createElement('div'); node.id = 'msfix-check-help-' + (++checkHelpCounter);
      node.className = 'msfix-check-help'; node.setAttribute('data-msfix-ui', ''); node.hidden = true;
      document.body.appendChild(node);
      rec = {control: control, node: node, targets: [], addedLabel: null, described: [control]}; checkHelpRecords.set(control, rec);
    }
    rec.info = info; rec.title = buffTitle || help.title || ''; rec.detail = help.detail || help.text;
    rec.anchor = info.scope.querySelectorAll(CHECK_HELP_SELECTOR).length === 1 ? info.scope : control;
    var copy = help.detail ? help.text + ' ' + help.detail : help.text;
    if (rec.node.textContent !== copy) rec.node.textContent = copy;
    var desc = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
    if (desc.indexOf(rec.node.id) === -1) { desc.push(rec.node.id); control.setAttribute('aria-describedby', desc.join(' ')); }
    // Icon-only native buff checkboxes have no accessible name at all.
    if (!info.labelNode && !control.getAttribute('aria-labelledby') && (!control.getAttribute('aria-label') || control.getAttribute('aria-label') === rec.addedLabel) && help.name) {
      if (control.getAttribute('aria-label') !== help.name) control.setAttribute('aria-label', help.name);
      rec.addedLabel = help.name;
    }
    rec.targets.forEach(function (target) { if (checkHelpTargets.get(target) === rec) checkHelpTargets.delete(target); });
    // Bind the entire control block, including padding and the gap beside its label.
    rec.targets = [rec.anchor];
    rec.targets.forEach(function (target) { checkHelpTargets.set(target, rec); });
    return rec;
  }
  function ensureFieldHelp(label, metricHelp) {
    if (metricHelp && (typeof metricHelp !== 'object' || typeof metricHelp.text !== 'string')) metricHelp = null;
    if (!label.isConnected || label.children.length || label.closest('[data-msfix-ui], [data-slot="tooltip-content"]')) return null;
    if (hasNativeHelp(label)) return null;
    var route = featurePath(location.pathname).replace(/^\/(en|ko|ja|ch)(?=\/|$)/, '') || '/';
    var help = metricHelp || resolveCheckboxHelp({route:route, label:label.textContent, context:'', id:'', image:''}, (data().checkboxHelp || {}).fields || [], helpVariants);
    var rec = checkHelpRecords.get(label);
    if (rec && rec.metric && !metricHelp) return rec;
    if (!help) { if (rec) removeCheckboxHelp(label, rec); return null; }
    if (!rec) {
      var node = document.createElement('div'); node.id = 'msfix-check-help-' + (++checkHelpCounter);
      node.className = 'msfix-check-help'; node.setAttribute('data-msfix-ui', ''); node.hidden = true;
      document.body.appendChild(node);
      rec = {control:label, anchor:label.closest('th, td') || label.parentElement || label, node:node, targets:[], described:[], field:true, metric:!!metricHelp}; checkHelpRecords.set(label, rec);
      // Only associate inputs in a small, unambiguous row. No wrapping, reparenting, or value writes.
      for (var row = metricHelp ? null : label.parentElement, depth = 0; row && depth < 4; row = row.parentElement, depth++) {
        var inputs = Array.from(row.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]), select'));
        if (inputs.length > 2) break;
        if (inputs.length) { rec.described = inputs; rec.anchor = row; break; }
      }
      if (!rec.described.length) {
        rec.described = [label];
      }
      var icon = document.createElement('button'); icon.type = 'button'; icon.className = 'msfix-help-icon';
      icon.setAttribute('data-msfix-ui', ''); icon.setAttribute('aria-label', 'About ' + label.textContent.trim());
      var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      var attrs = {width:24, height:24, viewBox:'0 0 24 24', fill:'none', stroke:'var(--text-gray-disabled)', 'stroke-width':2, 'stroke-linecap':'round', 'stroke-linejoin':'round', 'class':'lucide lucide-circle-help size-4', 'aria-hidden':'true'};
      Object.keys(attrs).forEach(function (key) { svg.setAttribute(key, attrs[key]); });
      [['circle', {cx:12,cy:12,r:10}], ['path', {d:'M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3'}], ['path', {d:'M12 17h.01'}]].forEach(function (part) {
        var element = document.createElementNS('http://www.w3.org/2000/svg', part[0]);
        Object.keys(part[1]).forEach(function (key) { element.setAttribute(key, part[1][key]); }); svg.appendChild(element);
      });
      icon.appendChild(svg);
      icon.addEventListener('click', function (e) { e.stopPropagation(); showCheckboxHelp(rec); });
      label.after(icon); rec.icon = icon; rec.anchor = icon; rec.described.push(icon);
      rec.targets = [icon];
      rec.targets.forEach(function (target) { checkHelpTargets.set(target, rec); });
      label.setAttribute('data-msfix-help-label', '');
    }
    if (rec.node.textContent !== help.text) rec.node.textContent = help.text;
    rec.described.forEach(function (target) {
      var ids = (target.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
      if (ids.indexOf(rec.node.id) === -1) { ids.push(rec.node.id); target.setAttribute('aria-describedby', ids.join(' ')); }
    });
    return rec;
  }
  function ensureMetricRowHelp(row, text) {
    var rec = checkHelpRecords.get(row);
    if (!rec) {
      var node = document.createElement('div'); node.id = 'msfix-check-help-' + (++checkHelpCounter);
      node.className = 'msfix-check-help'; node.setAttribute('data-msfix-ui', ''); node.hidden = true;
      document.body.appendChild(node);
      rec = {control:row, anchor:row, node:node, targets:[row], described:[row], metric:true};
      checkHelpRecords.set(row, rec); checkHelpTargets.set(row, rec);
      if (!row.hasAttribute('tabindex')) { row.setAttribute('tabindex', '0'); rec.addedTabIndex = true; }
    }
    if (rec.node.textContent !== text) rec.node.textContent = text;
    var ids = (row.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
    if (ids.indexOf(rec.node.id) === -1) { ids.push(rec.node.id); row.setAttribute('aria-describedby', ids.join(' ')); }
    return rec;
  }
  function ensureMetricHelp(label) {
    if (!label.isConnected || label.children.length || label.closest('[data-msfix-ui], [data-slot="tooltip-content"]') || hasNativeHelp(label)) return;
    var rules = (data().checkboxHelp || {}).metrics || [];
    var candidates = rules.filter(function (r) { return r.labels.indexOf(label.textContent.trim()) !== -1; });
    if (!candidates.length) return;
    var row = label.parentElement, value = row && row.lastElementChild;
    if (!value || value === label || value.tagName !== 'SPAN') return;
    for (var group = row.parentElement, depth = 0; group && depth < 3; group = group.parentElement, depth++) {
      var heading = group.firstElementChild;
      if (!heading || heading.contains(label)) continue;
      var found = candidates.find(function (r) { return r.groups.indexOf(heading.textContent.trim()) !== -1; });
      if (found) return ensureMetricRowHelp(row, found.text);
    }
  }
  function removeCheckboxHelp(control, rec) {
    if (checkHelpActive === rec) hideCheckboxHelp();
    if (checkHelpHover === rec) checkHelpHover = null;
    if (checkHelpFocus === rec) checkHelpFocus = null;
    (rec.described || [control]).forEach(function (target) {
      var ids = (target.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) { return id && id !== rec.node.id; });
      if (ids.length) target.setAttribute('aria-describedby', ids.join(' ')); else target.removeAttribute('aria-describedby');
    });
    if (rec.addedTabIndex && control.getAttribute('tabindex') === '0') control.removeAttribute('tabindex');
    if (rec.field) control.removeAttribute('data-msfix-help-label');
    if (rec.icon) rec.icon.remove();
    if (rec.addedLabel && control.getAttribute('aria-label') === rec.addedLabel) control.removeAttribute('aria-label');
    rec.targets.forEach(function (target) { if (checkHelpTargets.get(target) === rec) checkHelpTargets.delete(target); });
    rec.node.remove(); checkHelpRecords.delete(control);
  }
  function refreshCheckboxHelp() {
    checkHelpRecords.forEach(function (rec, control) { if (!control.isConnected || pathLocale() !== 'en') removeCheckboxHelp(control, rec); });
    if (pathLocale() !== 'en') return;
    document.querySelectorAll('[data-msfix-card-help]').forEach(ensureCardHelp);
    document.querySelectorAll(CHECK_HELP_SELECTOR).forEach(ensureCheckboxHelp);
    if (/\/input\/?$/.test(location.pathname)) document.querySelectorAll(FIELD_HELP_SELECTOR).forEach(function (label) { ensureFieldHelp(label); });
    if (/\/(input|result)\/?$/.test(location.pathname)) document.querySelectorAll('span').forEach(ensureMetricHelp);
    if (checkHelpActive) placeCheckboxHelp();
  }
  function renderNativeHelp(rec, rect) {
    var R = siteRefs.react, T = siteRefs.tooltip;
    if (!R || !T || !siteRefs.createRoot) return; // Fail closed if the site changes its component contract.
    try {
      var open = !!rec;
      if (open && !checkHelpWasOpen) {
        // Re-entering during the native exit animation must not replay the entrance.
        var visible = document.querySelector('[data-msfix-input-help]');
        checkHelpSkipEnter = !!(visible && visible.getClientRects().length && Number(getComputedStyle(visible).opacity) > 0);
      }
      checkHelpWasOpen = open;
      if (rec) checkHelpLast = {rec:rec, rect:rect};
      else if (checkHelpLast) { rec = checkHelpLast.rec; rect = checkHelpLast.rect; }
      else return;
      if (!checkHelpRoot) {
        var host = document.createElement('div'); host.setAttribute('data-msfix-ui', '');
        host.className = 'msfix-help-root'; document.body.appendChild(host);
        checkHelpRoot = siteRefs.createRoot(host);
      }
      var key = [open, checkHelpSkipEnter, rec.node.id, rec.title, rec.node.textContent, rect.x, rect.y, rect.width, rect.height].join('|');
      if (key === checkHelpRenderKey) return;
      checkHelpRenderKey = key;
      var h = R.createElement;
      checkHelpRoot.render(h(T.Root, {open:open, disableHoverableContent:true},
        h(T.Trigger, {asChild:true}, h('span', {'aria-hidden':true, tabIndex:-1, style:{position:'fixed', pointerEvents:'none', left:rect.x, top:rect.y, width:rect.width, height:rect.height}})),
        h(T.Content, {'data-msfix-ui':'', 'data-msfix-input-help':'', collisionPadding:8,
          style:open && checkHelpSkipEnter ? {animationName:'none'} : undefined,
          onFocusOutside:function (e) { if (checkHelpFocus === rec) e.preventDefault(); }
        }, rec.title ? h('div', {className:'msfix-help-copy'},
          h('div', {className:'msfix-help-title'}, rec.title),
          rec.detail ? h('div', {className:'msfix-help-detail'}, rec.detail) : null
        ) : rec.node.textContent)
      ));
    } catch (_) { checkHelpRenderKey = ''; }
  }
  function hideCheckboxHelp() {
    clearTimeout(checkHelpTimer); checkHelpActive = null; renderNativeHelp(null);
  }
  function placeCheckboxHelp() {
    var rec = checkHelpActive; if (!rec) return;
    if (!rec.control.isConnected || pathLocale() !== 'en' || !rec.control.getClientRects().length) { hideCheckboxHelp(); return; }
    var r = (rec.anchor || rec.control).getBoundingClientRect();
    if (r.bottom < 0 || r.top > window.innerHeight) { hideCheckboxHelp(); return; }
    renderNativeHelp(rec, r);
  }
  function showCheckboxHelp(rec) {
    if (!rec) return;
    clearTimeout(checkHelpTimer); checkHelpActive = rec; placeCheckboxHelp();
  }
  function checkboxHelpTarget(target) {
    // Native skill icons inside a control block keep their existing tooltip.
    if (target && target.nodeType === 1 && hasNativeHelp(target)) return null;
    for (var e = target; e && e.nodeType === 1; e = e.parentElement) {
      if (e.hasAttribute('data-msfix-input-help')) return null;
      var rec = checkHelpTargets.get(e); if (rec) return rec.card ? ensureCardHelp(e) : rec;
      if (e.hasAttribute('data-msfix-card-help')) return ensureCardHelp(e);
      if (e.matches(CHECK_HELP_SELECTOR)) return ensureCheckboxHelp(e);
      if (e.tagName === 'LABEL') {
        var c = e.querySelector(CHECK_HELP_SELECTOR);
        if (!c && e.htmlFor && e.parentElement) c = Array.from(e.parentElement.querySelectorAll(CHECK_HELP_SELECTOR)).find(function (x) { return x.id === e.htmlFor; });
        if (c) return ensureCheckboxHelp(c);
      }
    }
    return null;
  }
  function deferHideCheckboxHelp() {
    clearTimeout(checkHelpTimer);
    checkHelpTimer = setTimeout(function () { if (!checkHelpHover && !checkHelpFocus) hideCheckboxHelp(); }, 0);
  }
  function startCheckboxHelp() {
    document.addEventListener('pointerover', function (e) {
      if (e.pointerType === 'touch') return;
      checkHelpHover = checkboxHelpTarget(e.target);
      if (checkHelpHover) showCheckboxHelp(checkHelpHover);
    });
    document.addEventListener('pointerout', function (e) {
      if (e.pointerType === 'touch') return;
      checkHelpHover = checkboxHelpTarget(e.relatedTarget);
      if (!checkHelpHover) deferHideCheckboxHelp();
    });
    document.addEventListener('focusin', function (e) { checkHelpFocus = checkHelpPointerFocus ? null : checkboxHelpTarget(e.target); if (checkHelpFocus) showCheckboxHelp(checkHelpFocus); });
    document.addEventListener('focusout', function (e) { checkHelpFocus = checkboxHelpTarget(e.relatedTarget); if (!checkHelpFocus) deferHideCheckboxHelp(); });
    document.addEventListener('pointerdown', function (e) {
      checkHelpPointerFocus = true; checkHelpFocus = null;
      var rec = checkboxHelpTarget(e.target);
      if (!rec) { checkHelpFocus = checkHelpHover = null; hideCheckboxHelp(); }
      else if (e.pointerType === 'touch') showCheckboxHelp(rec); // Does not intercept the normal toggle.
    }, true);
    document.addEventListener('keydown', function (e) {
      checkHelpPointerFocus = false;
      if (e.key === 'Escape') { checkHelpHover = checkHelpFocus = null; hideCheckboxHelp(); }
    }, true);
    window.addEventListener('scroll', placeCheckboxHelp, true);
    window.addEventListener('resize', placeCheckboxHelp);
    document.addEventListener('click', function () { setTimeout(refreshCheckboxHelp, 100); }, true);
    document.addEventListener('input', function (e) {
      var card = e.target.closest('[data-msfix-card-help]'); if (!card) return;
      requestAnimationFrame(function () { ensureCardHelp(card); if (checkHelpActive && checkHelpActive.control === card) placeCheckboxHelp(); });
    }, true);
    setTimeout(refreshCheckboxHelp, 500);
  }

  /* ---------------- 4a. Tooltip keep-alive ---------------------------------------------- */
  // Some site tooltips (boss hover cards etc.) close the moment the pointer enters
  // them. If a floating layer is removed while the cursor is inside its box, we pin
  // a static clone in place until the mouse genuinely leaves it.
  var mouse = { x: -1, y: -1 };
  document.addEventListener('mousemove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; }, true);

  var FLOAT_SELECTOR = '[data-radix-popper-content-wrapper], [role="tooltip"], [data-side][data-state]';
  var INFO_FLOAT_SELECTOR = '[role="tooltip"], [data-slot="tooltip-content"], [data-slot="hover-card-content"]';
  var INTERACTIVE_FLOAT_SELECTOR = '[role="dialog"], [role="menu"], [role="listbox"], input, select, textarea, button, a[href], [contenteditable="true"]';
  var floatRects = new Map(); // element -> DOMRect (last known)
  var pinned = null;
  // A clone has no React handlers. Never preserve a menu, form, or other
  // interactive layer after the site closes it, and never clone our own clone.
  function canPinFloating(el) {
    if (el.closest('#msfix-pinned-tooltip, [data-msfix-ui]') || el.querySelector('[data-msfix-input-help]')) return false;
    if (el.matches(INTERACTIVE_FLOAT_SELECTOR) || el.querySelector(INTERACTIVE_FLOAT_SELECTOR)) return false;
    return el.matches(INFO_FLOAT_SELECTOR) || !!el.querySelector(INFO_FLOAT_SELECTOR);
  }
  // keep tracked rects accurate while scrolling (tooltips scroll with content until removed)
  window.addEventListener('scroll', function () { refreshFloatRects(); }, { passive: true, capture: true });

  function trackFloating(root) {
    if (!root || root.nodeType !== 1) return;
    var els = [];
    if (root.matches && root.matches(FLOAT_SELECTOR)) els.push(root);
    if (root.querySelectorAll) els.push.apply(els, root.querySelectorAll(FLOAT_SELECTOR));
    for (var i = 0; i < els.length; i++) {
      if (!canPinFloating(els[i])) continue;
      var r = els[i].getBoundingClientRect();
      if (r.height > 60 && r.width > 100) floatRects.set(els[i], r);
    }
  }

  function refreshFloatRects() {
    floatRects.forEach(function (_, el) {
      if (!document.contains(el)) { floatRects.delete(el); return; }
      var r = el.getBoundingClientRect();
      if (r.height > 0) floatRects.set(el, r);
    });
  }

  function insideRect(r, pad) {
    return mouse.x >= r.left - pad && mouse.x <= r.right + pad && mouse.y >= r.top - pad && mouse.y <= r.bottom + pad;
  }

  function unpin() {
    if (pinned) { pinned.el.remove(); document.removeEventListener('mousemove', pinned.watch, true); pinned = null; }
  }

  function pinTooltip(node, r) {
    unpin();
    var clone = node.cloneNode(true);
    clone.id = 'msfix-pinned-tooltip';
    clone.style.position = 'fixed';
    clone.style.left = r.left + 'px';
    clone.style.top = r.top + 'px';
    clone.style.zIndex = '2147483000';
    clone.style.pointerEvents = 'auto';
    clone.style.margin = '0';
    clone.style.transform = 'none';
    document.body.appendChild(clone);
    var watch = function () {
      if (!insideRect(r, 14)) unpin();
    };
    pinned = { el: clone, watch: watch };
    document.addEventListener('mousemove', watch, true);
    // NOTE: no scroll-based unpin — the clone is viewport-fixed, so it stays put
    // while scrolling and only closes when the mouse leaves its box.
  }

  function onFloatingRemoved(node) {
    if (node.nodeType !== 1) return;
    var candidates = [node];
    floatRects.forEach(function (_, el) { if (node === el || node.contains(el)) candidates.push(el); });
    for (var i = 0; i < candidates.length; i++) {
      var r = floatRects.get(candidates[i]);
      if (r) {
        floatRects.delete(candidates[i]);
        if (canPinFloating(candidates[i]) && insideRect(r, 6)) { pinTooltip(candidates[i], r); return; }
      }
    }
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') unpin(); }, true);

  /* ---------------- 4b. Ad removal ------------------------------------------------------ */
  // Static slots/banners are hidden by the injected CSS; popup ad modals are built
  // dynamically, so we hide any fixed-position overlay that carries an ad creative.
  // Hidden, not removed: the popup is rendered inline by React (no portal), and React
  // throws on unmount if the node was already detached from its parent.
  var REMOVE_ADS = true;

  function killAdPopups() {
    if (!REMOVE_ADS) return;
    var imgs = document.querySelectorAll('img[src*="/next/ads/"], img[src*="files.maplescouter.com/next/ads"], img[src*="next%2Fads"], img#popup-image');
    for (var i = 0; i < imgs.length; i++) {
      var el = imgs[i], overlay = null, p = el.parentElement;
      while (p && p !== document.body) {
        var pos = getComputedStyle(p).position;
        if (pos === 'fixed') overlay = p;
        p = p.parentElement;
      }
      if (overlay && !overlay.__msfixHidden) {
        overlay.__msfixHidden = true;
        overlay.style.setProperty('display', 'none', 'important');
      }
    }
  }

  /* ---------------- 4d. Cloud characters ------------------------------------------------ */
  // The Manual Input page gets a Character picker in place of the site's Load Preset /
  // Save Preset buttons (hidden, not removed — React owns them, and the picker's footer still
  // opens both windows). Every preset slot is a character: whatever you type into the form is
  // saved into the selected slot as you go, and a slot linked to an IGN can be uploaded to /
  // pulled from scouter.tomerh2001.com so the same character is available from any browser.
  // Uploads are always explicit (the sync icon, or the add flow); nothing is uploaded on
  // its own. Everything runs through the site's own zustand stores — `manual-store`
  // (the draft the form renders from) and `preset` (the slots) — captured passively while
  // webpack executes them (noteExports), so switching characters never needs a reload.
  //
  // Gotchas this code is shaped around (all observed on the live site):
  //  - loadDraft/seedDraft/resetDraft bump draftVersion, which REMOUNTS the whole panel and
  //    destroys our wrapper → ensureCharPicker() is idempotent and re-run after such changes.
  //  - preset slot keys are positional (deletePreset renumbers) → bindings are re-resolved by
  //    label (= the IGN) / savedAt on every store change, never trusted by key alone.
  //  - the DOM translation layer rewrites ASCII strings that collide with dictionary keys
  //    (several are IGNs) → every node we own carries data-msfix-ui and is skipped.
  //  - the cloud is public and unauthenticated (by design): anyone can read or overwrite an
  //    IGN, so the footer says so and nothing here is treated as private.

  var CLOUD_URL = 'https://scouter.tomerh2001.com';
  var LS_CLOUD_URL = 'msfix:cloud:url', LS_CLOUD_SLOTS = 'msfix:cloud:slots', LS_CLOUD_SELECTED = 'msfix:cloud:selected';
  var LS_CLOUD_ENABLED = 'msfix:cloud:enabled', LS_CLOUD_AUTO = 'msfix:cloud:auto';
  var IGN_RE = /^[A-Za-z0-9]{1,16}$/;
  var AUTOSAVE_MS = 500, AUTOUPLOAD_MS = 3000, POLL_MS = 300000, POLL_MAX_MS = 900000, FOCUS_CHECK_GAP_MS = 60000, FETCH_TIMEOUT_MS = 10000;

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { if (v === null || v === undefined) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function lsJson(k, fb) { var v = lsGet(k); if (v == null) return fb; try { var o = JSON.parse(v); return o == null ? fb : o; } catch (e) { return fb; } }
  function cloudUrl() { var u = lsGet(LS_CLOUD_URL); return (u && /^https?:\/\//.test(u) ? u : CLOUD_URL).replace(/\/+$/, ''); }
  // v1.5.1: cloud sync is always on and auto-upload always off (no toggles). The storage keys
  // stay reserved so values written by older builds are ignored rather than misread.
  function cloudEnabled() { return true; }
  function autoUploadOn() { return false; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function eqi(a, b) { return String(a == null ? '' : a).toLowerCase() === String(b == null ? '' : b).toLowerCase(); }
  function nowIso() { return new Date().toISOString(); }

  /* -- support both the original pages and the site's separate manual workspace ------ */
  function featurePath(pathname) {
    return pathname.replace(/^\/(ko|en|ja|ch)\/manual\/(input|result|hexa|optimizer)(\/?$)/, '/$1/$2$3');
  }
  function isInputRoute() { return /^\/(ko|en|ja|ch)\/input\/?$/.test(featurePath(location.pathname)); }
  var manualNavLayout = new WeakMap();
  function revealManualTab() {
    // The new workspace scrolls horizontally on phones. Reveal the active page once
    // after navigation or a size change, without undoing the user's own scrolling.
    document.querySelectorAll('main a[aria-current="page"][href*="/manual/"]').forEach(function (link) {
      var strip = link.parentElement;
      if (!strip || !strip.classList.contains('overflow-x-auto') || !strip.clientWidth) return;
      var layout = link.getAttribute('href') + ':' + strip.clientWidth + ':' + strip.scrollWidth;
      if (manualNavLayout.get(strip) === layout) return;
      manualNavLayout.set(strip, layout);
      var item = link.getBoundingClientRect(), bounds = strip.getBoundingClientRect();
      if (item.right > bounds.right) strip.scrollLeft += item.right - bounds.right;
      else if (item.left < bounds.left) strip.scrollLeft -= bounds.left - item.left;
    });
  }
  var ROW_SEL = 'div.flex.w-full.items-center.justify-between > div.flex.gap-2:has(> button[data-slot=dialog-trigger] > svg.lucide-file-down)';
  var IGN_SEL = 'div.flex.items-center.gap-2:has(> div.relative > input[data-slot=input] + button[data-slot=popover-trigger])';
  // React owns <html>/<body> (attributes we set there get reconciled away), so the hide rules
  // live in their own <style> that is simply enabled/disabled with the route.
  var ROUTE_CSS = ROW_SEL + '{display:none!important}\n' + IGN_SEL + '{display:none!important}';
  var CLOUD_CSS = [
    '.msfix-charpicker [hidden]{display:none!important}',
    '.msfix-charpicker .msfix-dd{top:100%;max-width:calc(100vw - 16px)}',
    '.msfix-charpicker input::placeholder,.msfix-dialog input::placeholder{color:var(--text-gray-low)}',
    '.msfix-charpicker .msfix-opt[aria-selected="true"]{box-shadow:inset 3px 0 0 var(--color-primary,#e5772f)}',
    '.msfix-charpicker .msfix-row-menu{opacity:.55}.msfix-charpicker .msfix-opt:hover .msfix-row-menu,.msfix-charpicker .msfix-opt.msfix-active .msfix-row-menu,.msfix-charpicker .msfix-row-menu:focus{opacity:1}',
    '@media (prefers-reduced-motion: reduce){.msfix-charpicker .animate-spin{animation:none}}',
    /* character look: a fixed box that holds the 96x96 render scaled down, or a faint silhouette */
    '.msfix-avatar{display:inline-flex;align-items:center;justify-content:center;flex:none;width:28px;height:28px;border-radius:6px;overflow:hidden;background:transparent;color:var(--text-gray-low,#8a8f98)}',
    '.msfix-avatar img{display:block;width:100%;height:100%;object-fit:contain;background:transparent}',
    '.msfix-avatar svg{width:70%;height:70%;opacity:.35}',
    '.msfix-avatar-sm{width:20px;height:20px;border-radius:4px}',
    '.msfix-avatar-lg{width:48px;height:48px;border-radius:8px}',
    '.msfix-charpicker .msfix-avatar-trigger{position:absolute;left:6px;top:50%;transform:translateY(-50%);pointer-events:none}',
    '.msfix-charpicker input.msfix-has-avatar{padding-left:30px}'
  ].join('\n');
  var _hasSupport = null;
  function hasSelectorSupport() {
    if (_hasSupport === null) { try { _hasSupport = !!(window.CSS && CSS.supports && CSS.supports('selector(div:has(> a))')); } catch (e) { _hasSupport = false; } }
    return _hasSupport;
  }
  function routeStyle() {
    var st = document.getElementById('msfix-cloud-route');
    if (st) return st;
    if (!document.head) return null;
    st = document.createElement('style');
    st.id = 'msfix-cloud-route';
    st.textContent = ROUTE_CSS;
    document.head.appendChild(st);
    return st;
  }
  function applyRouteGate() {
    var on = isInputRoute();
    var routeName = on ? 'input' : (/^\/(ko|en|ja|ch)\/game\/spec-quiz(?:\/|$)/.test(location.pathname) ? 'spec-quiz' : location.pathname.split('/').filter(Boolean).pop() || 'home');
    if (/^\/en\/(?:simulator\/)?ability\/?$/.test(location.pathname)) routeName = 'ability';
    if (/^\/en\/simulator\/soul\/?$/.test(location.pathname)) routeName = 'soul';
    var st = routeStyle();
    if (st && st.disabled !== !on) st.disabled = !on;
    try { if (document.documentElement.getAttribute('data-msfix-route') !== routeName) document.documentElement.setAttribute('data-msfix-route', routeName); } catch (e) {}
    if (hasSelectorSupport() || !document.body) return;
    // Browsers without :has() — hide/unhide by hand (the header search persists across SPA
    // navigations, so it must be shown again when leaving the page).
    var row = nativePresetRow();
    if (row) row.style.display = on ? 'none' : '';
    var btns = document.querySelectorAll('input[data-slot=input] + button[data-slot=popover-trigger]');
    for (var i = 0; i < btns.length; i++) {
      var block = btns[i].parentElement && btns[i].parentElement.parentElement;
      if (block) block.style.display = on ? 'none' : '';
    }
  }
  function injectCloudCss() {
    if (document.getElementById('msfix-cloud-style')) return;
    var st = document.createElement('style');
    st.id = 'msfix-cloud-style';
    st.textContent = CLOUD_CSS;
    (document.head || document.documentElement).appendChild(st);
    applyRouteGate();
  }
  // The native row: [Load Preset][Save Preset] — the Load button carries the file-down icon.
  function nativePresetRow() {
    var svg = document.querySelector('div.flex.w-full.items-center.justify-between > div.flex.gap-2 > button[data-slot=dialog-trigger] > svg.lucide-file-down');
    return svg ? svg.parentElement.parentElement : null;
  }
  function nativeTrigger(kind) {
    var row = nativePresetRow(); if (!row) return null;
    var svg = row.querySelector(kind === 'load' ? 'svg.lucide-file-down' : 'svg.lucide-download');
    return svg ? svg.parentElement : null;
  }

  /* -- site stores (passively captured in wrapFactory; lazy scan only after load) -------- */
  var _scanAt = 0;
  function scanSiteModules() {
    var req = wpRequire(); if (!req || !req.m) return;
    _scanAt = Date.now();
    for (var id in req.m) {
      if (siteRefs.presetStore && siteRefs.toast && siteRefs.manualStore) break;
      var ex; try { ex = req(id); } catch (e) { continue; }
      noteExports(ex);
    }
  }
  function cloudStores() {
    if (!siteRefs.manualStore || !siteRefs.presetStore) {
      // Force-requiring modules while chunks are still arriving has produced page errors;
      // only fall back to a scan once the page is fully loaded, and not more than every 5 s.
      if (document.readyState === 'complete' && Date.now() - _scanAt > 5000) scanSiteModules();
    }
    return (siteRefs.manualStore && siteRefs.presetStore) ? { ms: siteRefs.manualStore, ps: siteRefs.presetStore } : null;
  }
  function presetMap() { var s = cloudStores(); if (!s) return {}; try { return s.ps.getState().preset || {}; } catch (e) { return {}; } }
  function setPresetMap(map) { var s = cloudStores(); if (!s) return false; try { s.ps.getState().setPreset(map); return true; } catch (e) { toastErr('Could not save the character'); return false; } }
  function currentDraft() { var s = cloudStores(); if (!s) return null; try { return s.ms.getState().draftStat; } catch (e) { return null; } }
  function slotKeys(map) { return Object.keys(map).sort(function (a, b) { return (+a) - (+b); }); }

  /* -- bindings: slotKey -> { ign, label, savedAt, cloudUpdatedAt, remoteUpdatedAt, syncedHash, syncedAt } */
  var cloud = {
    bindings: {}, selected: null,       // selected = { key, ign, label, savedAt }
    offline: false, busy: 0, subscribed: false, lastLoaded: null,
    saveTimer: null, uploadTimer: null, pollTimer: null, pollDelay: POLL_MS, pendingImport: null, conflictToastKey: null, warnToastKey: null
  };
  function loadBindings() {
    var previous = cloud.bindings;
    var b = lsJson(LS_CLOUD_SLOTS, {}); cloud.bindings = (b && typeof b === 'object' && !Array.isArray(b)) ? b : {};
    Object.keys(cloud.bindings).forEach(function (k) {
      var next = cloud.bindings[k];
      Object.keys(previous).some(function (oldKey) {
        var old = previous[oldKey], check = remoteCheck(old);
        if (next && old && eqi(next.ign, old.ign) && next.cloudUpdatedAt === old.cloudUpdatedAt && next.remoteUpdatedAt === old.remoteUpdatedAt && check && !check.pending) {
          remoteChecks.set(next, check); return true;
        }
        return false;
      });
    });
    var s = lsJson(LS_CLOUD_SELECTED, null); cloud.selected = (s && typeof s === 'object' && s.key) ? s : null;
  }
  function saveBindings() {
    lsSet(LS_CLOUD_SLOTS, JSON.stringify(cloud.bindings));
    lsSet(LS_CLOUD_SELECTED, cloud.selected ? JSON.stringify(cloud.selected) : null);
  }
  function slotMatchesBinding(s, b) {
    if (!s) return false;
    if (eqi(s.label, b.ign)) return true;
    if (b.label && eqi(s.label, b.label)) return true;
    return !!(b.savedAt && s.savedAt === b.savedAt);
  }
  function slotMatchesSel(s, sel) {
    if (!s) return false;
    if (sel.label) return eqi(s.label, sel.label) || (sel.ign && eqi(s.label, sel.ign));
    if (sel.savedAt) return s.savedAt === sel.savedAt;
    // A slot the site itself created has neither a label nor a savedAt until the first autosave
    // writes one. Until then its inputs are the only thing that tells it apart (sel.hash).
    return !s.label && !s.savedAt && !!sel.hash && hashData(s.data) === sel.hash;
  }
  // Slot keys are positional and the site renumbers them on delete, so bindings are matched
  // by content (label = IGN, or the savedAt we wrote) against the live map on every change.
  // noSave skips the write back. The cross-tab storage listener uses it because this tab's
  // in-memory preset map may be older than the tab that wrote the bindings.
  function reconcileBindings(noSave) {
    var map = presetMap(), keys = slotKeys(map), out = {}, used = {}, old = cloud.bindings;
    Object.keys(old).forEach(function (k) {
      var b = old[k]; if (!b || !b.ign) return;
      var hit = null;
      if (map[k] && !used[k] && slotMatchesBinding(map[k], b)) hit = k;
      for (var i = 0; i < keys.length && !hit; i++) if (!used[keys[i]] && slotMatchesBinding(map[keys[i]], b)) hit = keys[i];
      if (!hit) return;
      used[hit] = true; b.label = map[hit].label || ''; if (map[hit].savedAt) b.savedAt = map[hit].savedAt; out[hit] = b;
    });
    cloud.bindings = out;
    if (cloud.selected) {
      var sel = cloud.selected, key = null;
      if (map[sel.key] && slotMatchesSel(map[sel.key], sel)) key = sel.key;
      for (var j = 0; j < keys.length && !key; j++) if (slotMatchesSel(map[keys[j]], sel)) key = keys[j];
      if (!key) cloud.selected = null;
      else { sel.key = key; sel.label = map[key].label || ''; if (map[key].savedAt) sel.savedAt = map[key].savedAt; sel.ign = out[key] ? out[key].ign : null; }
    }
    if (!noSave) saveBindings();
  }
  function selectedKey() { return cloud.selected ? cloud.selected.key : null; }
  function bindingByIgn(ign) { for (var k in cloud.bindings) if (cloud.bindings[k] && eqi(cloud.bindings[k].ign, ign)) return { key: k, binding: cloud.bindings[k] }; return null; }
  function ignForSlot(slotKey) { var b = cloud.bindings[slotKey]; return b && b.ign ? b.ign : null; }

  /* -- hashing (canonical JSON, sorted keys) to tell "edited since last upload" ---------- */
  function canon(v) {
    if (Array.isArray(v)) { var a = []; for (var i = 0; i < v.length; i++) a.push(canon(v[i])); return '[' + a.join(',') + ']'; }
    if (v && typeof v === 'object') { var ks = Object.keys(v).sort(), o = []; for (var j = 0; j < ks.length; j++) o.push(JSON.stringify(ks[j]) + ':' + canon(v[ks[j]])); return '{' + o.join(',') + '}'; }
    return JSON.stringify(v === undefined ? null : v);
  }
  function hashData(d) {
    var s = canon(d || null), h = 0x811c9dc5;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
    return ('0000000' + h.toString(16)).slice(-8) + ':' + s.length;
  }

  /* -- display helpers ------------------------------------------------------------------- */
  function classEn(ko) { var d = data(); return (siteRefs.enBundle && siteRefs.enBundle[ko]) || d.i18nPatch[ko] || d.dict[ko] || ko || ''; }
  var LS_CLOUD_HEXA = 'msfix:cloud:hexa';
  // "HEXA" = the site's HEXA-converted main stat under Boss 300 (calculatedData.boss300_hexaStat,
  // the figure the result page labels HEXA). The site only computes it when Result is pressed, so
  // remember it per input-hash and show it for any preset — local or cloud — whose inputs match.
  var hexaCache = null;
  function hexaMap() { if (!hexaCache) hexaCache = lsJson(LS_CLOUD_HEXA, {}); return hexaCache; }
  // The site's result.userStat is the submitted inputs plus derived fields (hexa.hexaSkill*,
  // hexa.character_class, hexa.hexaStat_opened) with `power` zeroed, so hash a projection that
  // drops exactly those and the same inputs — draft, slot or cloud copy — map to the same key.
  var HEXA_CORE_RE = /^(?:skillCore|masteryCore|reinCore|generalCore)\d+$|^hexaStat$/;
  function hexaKey(d) {
    var c = {};
    for (var k in d) { if (k === 'power') continue; if (k === 'hexa') { var hx = {}; for (var j in d.hexa || {}) if (HEXA_CORE_RE.test(j)) hx[j] = d.hexa[j]; c.hexa = hx; } else c[k] = d[k]; }
    return hashData(c);
  }
  // The site can swap result.userStat without a recompute (the result page's setResultUserStat
  // rewrites seed ring fields and keeps calculatedData). Cache each calculatedData object once,
  // under the inputs it was computed for, so a stale HEXA never lands under a new input hash.
  var lastNotedCd = null;
  function noteResult(res) {
    var cd = res && res.calculatedData, us = res && res.userStat;
    if (!cd || !us) return;
    if (cd === lastNotedCd) return;
    lastNotedCd = cd;
    var v = Number(cd.boss300_hexaStat), plain = false;
    if (!isFinite(v)) return;
    // -3 with a normal boss300_stat means the character has no HEXA combat analysis on file. The
    // site then falls back to the plain converted stat, so keep that one and mark it as plain.
    if (v === -3) { var pv = Number(cd.boss300_stat); if (isFinite(pv) && pv > 0) { v = pv; plain = true; } }
    // The site answers 201 even when it refuses the inputs: every result field then holds a
    // negative code (-1..-7, the ones its own result page turns into an error label). Keep the
    // code too, so the row can say why instead of "HEXA: press Result".
    var err = v < 0 && v >= -7 && v === Math.round(v) ? v : 0;
    if (!err && v <= 0) return;
    var h = hexaKey(us), m = hexaMap();
    if (m[h] && m[h].v === (err ? 0 : Math.round(v)) && (m[h].err || 0) === err && !!m[h].plain === plain) return;
    m[h] = err ? { v: 0, err: err, at: nowIso() } : plain ? { v: Math.round(v), plain: true, at: nowIso() } : { v: Math.round(v), at: nowIso() };
    var ks = Object.keys(m);
    if (ks.length > 80) { ks.sort(function (a, b) { return m[a].at < m[b].at ? -1 : 1; }); while (ks.length > 80) delete m[ks.shift()]; }
    lsSet(LS_CLOUD_HEXA, JSON.stringify(m));
    if (picker.open) renderDropdown();
  }
  // Seed the cache from a meta block (a downloaded file carries hexaConverted like the cloud
  // document does), so an import shows its HEXA figure before Result is pressed here.
  function seedHexa(d, meta) {
    var hc = meta ? Number(meta.hexaConverted) : NaN;
    if (!d || !isFinite(hc) || hc <= 0) return;
    var h = hexaKey(d), m = hexaMap();
    if (m[h] && m[h].v > 0) return;
    m[h] = { v: Math.round(hc), at: nowIso() };
    var ks = Object.keys(m);
    if (ks.length > 80) { ks.sort(function (a, b) { return m[a].at < m[b].at ? -1 : 1; }); while (ks.length > 80) delete m[ks.shift()]; }
    lsSet(LS_CLOUD_HEXA, JSON.stringify(m));
  }
  function hexaForData(d) { if (!d) return null; var e = hexaMap()[hexaKey(d)]; return e && e.v > 0 ? e.v : null; }
  function hexaErrForData(d) { if (!d) return 0; var e = hexaMap()[hexaKey(d)]; return (e && e.err) || 0; }
  // true when the cached figure is the plain converted stat (no HEXA analysis), not a HEXA one.
  function hexaPlainForData(d) { if (!d) return false; var e = hexaMap()[hexaKey(d)]; return !!(e && e.v > 0 && e.plain); }
  function hexaErrText(code) {
    return code === -1 ? 'calculation limit hit' : code === -2 ? 'ignore defense error' : code === -3 ? 'HEXA combat analysis missing' :
      code === -4 ? 'input error' : code === -5 ? 'impossible setup, check Main Stat %' : code === -6 ? 'crit rate below 100%' : code === -7 ? 'force too low' : 'error ' + code;
  }
  function fmtNum(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function fmtK(n) { n = Math.round(n); return n >= 10000 ? Math.round(n / 1000) + 'k' : n >= 1000 ? (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : String(n); }
  function slotMeta(sd) {
    var st = (sd && sd.stat) || {}; var lv = Number(st.level);
    return { classKo: st.myClass || '', classEn: classEn(st.myClass || ''), level: isFinite(lv) && lv > 0 ? lv : 0, hexa: hexaForData(sd), hexaPlain: hexaPlainForData(sd), hexaErr: hexaErrForData(sd), warn: statWarnings(sd) };
  }
  function docMeta(doc) {
    var m = doc && doc.meta; var p = doc && doc.preset && doc.preset.data;
    var r;
    if (p && p.stat) r = slotMeta(p);
    else { var lv = m ? Number(m.level) : 0; r = { classKo: (m && m.class) || '', classEn: classEn((m && m.class) || ''), level: isFinite(lv) && lv > 0 ? lv : 0, hexa: null, hexaPlain: false, hexaErr: 0, warn: [] }; }
    var hc = m ? Number(m.hexaConverted) : NaN;
    if (r.hexa == null && isFinite(hc) && hc > 0) r.hexa = Math.round(hc);
    return r;
  }
  function metaLine(m) { if (!m.classKo && !m.level) return 'No class or level yet'; return (m.classEn || '?') + ' Lv ' + m.level + ', ' + (m.hexa ? fmtK(m.hexa) + (m.hexaPlain ? ' stat (no HEXA analysis)' : ' HEXA') : m.hexaErr ? 'HEXA: ' + hexaErrText(m.hexaErr) : 'HEXA: press Result') + (m.warn && m.warn.length ? ', check inputs' : ''); }
  function relTime(iso) {
    if (!iso) return 'never';
    var t = new Date(iso).getTime(); if (isNaN(t)) return '';
    var seconds = Math.floor(Math.max(0, Date.now() - t) / 1000);
    if (!seconds) return 'just now';
    var units = [[31536000, 'year'], [2592000, 'month'], [86400, 'day'], [3600, 'hour'], [60, 'minute'], [1, 'second']];
    for (var i = 0; i < units.length; i++) {
      var n = Math.floor(seconds / units[i][0]);
      if (n) return n + ' ' + units[i][1] + (n === 1 ? '' : 's') + ' ago';
    }
  }
  function dayDate(iso) { if (!iso) return ''; var t = new Date(iso); return isNaN(t.getTime()) ? '' : t.toLocaleDateString(); }
  function slotName(key, slot) {
    var b = cloud.bindings[key];
    if (b && b.ign) return b.ign + (slot && slot.label && !eqi(slot.label, b.ign) ? ' (' + slot.label + ')' : '');
    return (slot && slot.label) || (slot && presetDataOk(slot.data) ? autoPresetLabel(slot.data) : '') || ('Character ' + key);
  }
  function svgIcon(name, extra) {
    var P = {
      'cloud': '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>',
      'cloud-off': '<path d="m2 2 20 20"/><path d="M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193"/><path d="M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07"/>',
      'cloud-check': '<path d="m17 15-5.5 5.5L9 18"/><path d="M5 17.743A7 7 0 1 1 15.71 10h1.79a4.5 4.5 0 0 1 1.5 8.742"/>',
      'cloud-alert': '<path d="M12 12v4"/><path d="M12 20h.01"/><path d="M17 18h.5a1 1 0 0 0 0-9h-1.79A7 7 0 1 0 5 17.5"/>',
      'cloud-upload': '<path d="M12 13v8"/><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="m8 17 4-4 4 4"/>',
      'cloud-download': '<path d="M12 13v8l-4-4"/><path d="m12 21 4-4"/><path d="M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284"/>',
      'chevrons-up-down': '<path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>',
      'plus': '<path d="M5 12h14"/><path d="M12 5v14"/>',
      'check': '<path d="M20 6 9 17l-5-5"/>',
      'ellipsis': '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
      'file-up': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M12 12v6"/><path d="m15 15-3-3-3 3"/>',
      'download': '<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>',
      'save': '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
      'history': '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
      'pencil': '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
      'trash': '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
      'loader': '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',
      'user': '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>'
    };
    return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-' + name + ' size-4' + (extra ? ' ' + extra : '') + '">' + (P[name] || '') + '</svg>';
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  /* -- network (all failures are soft: the icon goes "offline", nothing else breaks) ----- */
  function setOffline(flag, reason) {
    reason = flag ? (reason || 'network') : '';
    if (cloud.offline === flag && cloud.offlineReason === reason) return;
    cloud.offline = flag;
    cloud.offlineReason = reason;
    if (flag) toastErr(reason === 'blocked' ? 'Cloud access was blocked. Your local saves still work.' : 'Cloud unavailable. Your local saves still work.');
    updateIcon(); renderDropdown();
  }
  function cloudFetch(method, path, opts) {
    opts = opts || {};
    return new Promise(function (resolve, reject) {
      if (!cloudEnabled()) { reject({ disabled: true }); return; }
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, FETCH_TIMEOUT_MS);
      var headers = {}; if (opts.body) headers['Content-Type'] = 'application/json';
      if (opts.headers) for (var k in opts.headers) headers[k] = opts.headers[k];
      var init = { method: method, headers: headers, mode: 'cors', cache: 'no-store' };
      if (opts.body) init.body = JSON.stringify(opts.body);
      if (ctrl) init.signal = ctrl.signal;
      var failed = function (status, reason) {
        clearTimeout(timer);
        // An avatar failure is independent of character sync, including CORS and timeouts.
        if (opts.soft) { resolve({ status: status || 0, ok: false, json: null, etag: '', retryAfter: 0 }); return; }
        setOffline(true, reason);
        reject({ offline: true, status: status || 0, reason: reason || 'network' });
      };
      var done = function (res, json) {
        clearTimeout(timer); // cleared here, not at headers time, so the abort timer also covers a stalled body read
        if (!opts.soft) setOffline(false);
        var etag = (res.headers.get('ETag') || '').replace(/^W\//, '').replace(/"/g, '');
        var retryAfter = parseInt(res.headers.get('Retry-After') || '', 10);
        resolve({ status: res.status, ok: res.ok, json: json, etag: etag, retryAfter: retryAfter > 0 ? retryAfter : 0 });
      };
      fetch(cloudUrl() + path, init).then(function (res) {
        // A firewall response is not a successful sync check, even when it has CORS headers.
        if (res.status === 401 || res.status === 403) { failed(res.status, 'blocked'); return; }
        if (res.status >= 500) { failed(res.status); return; }
        if (method === 'HEAD') {
          if (res.ok && !res.headers.get('ETag')) { failed(res.status, 'response'); return; }
          done(res, null); return;
        }
        if (res.status === 204) { done(res, null); return; }
        res.text().then(function (t) {
          var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) {}
          if (res.ok && (!j || typeof j !== 'object')) { failed(res.status, 'response'); return; }
          done(res, j);
        }, function () { failed(res.status); });
      }, function () { failed(0); });
    });
  }
  function busy(delta) { cloud.busy = Math.max(0, cloud.busy + delta); updateIcon(); }
  function cloudPath(ign) { return '/v1/characters/' + encodeURIComponent(String(ign)); } // the server lowercases the key

  // Freshness belongs to this browser session, not the persisted sync baseline. A reload
  // must check the server before showing green. Binding objects survive slot renumbering.
  var remoteChecks = new WeakMap();
  function remoteCheck(b) { return b ? remoteChecks.get(b) : null; }
  function noteRemote(b, response) {
    remoteChecks.set(b, { at: Date.now(), response: response, pending: false });
  }
  function refreshCloudUi() { updateIcon(); refreshPickerRows(); }
  function checkRemote(key, cb, maxAge) {
    var b = cloud.bindings[key];
    if (!b || !b.ign || !cloudEnabled()) { if (cb) cb(null); return; }
    var old = remoteCheck(b), now = Date.now();
    if (old && old.pending) { if (cb) old.callbacks.push(cb); return; }
    // Reopening the list, focus + visibility events, and a form remount share one check.
    // Failed checks also cool down; an explicit Retry click still goes straight through.
    if (old && maxAge && now - old.at < Math.max(maxAge, old.retryMs || 0)) { if (cb) cb(old.response); return; }
    var check = { at: now, pending: true, callbacks: cb ? [cb] : [] };
    var baseline = b.cloudUpdatedAt, observed = b.remoteUpdatedAt;
    remoteChecks.set(b, check); refreshCloudUi();
    function finish(r) {
      // A pull or upload completed while this HEAD was in flight. It is newer evidence,
      // including when an old 404 arrives after the first successful upload.
      if (remoteCheck(b) === check) {
        if (b.cloudUpdatedAt === baseline && b.remoteUpdatedAt === observed) {
          if (r && r.status === 404) { b.remoteUpdatedAt = null; b.cloudUpdatedAt = null; }
          else if (r && r.ok && r.etag && (!b.cloudUpdatedAt || r.etag >= b.cloudUpdatedAt)) b.remoteUpdatedAt = r.etag;
        }
        check.at = Date.now(); check.pending = false; check.response = r;
        check.retryMs = r && r.retryAfter ? r.retryAfter * 1000 : 0;
        saveBindings();
      }
      refreshCloudUi();
      check.callbacks.forEach(function (fn) { fn(r); });
    }
    cloudFetch('HEAD', cloudPath(b.ign)).then(finish, function () { finish(null); });
  }
  function refreshPickerCloud() {
    if (!picker.open || document.hidden || !isInputRoute()) return;
    var keys = picker.items.filter(function (it) { return it.type === 'local'; }).map(function (it) { return it.key; });
    var next = 0, stopped = false;
    function run() {
      if (stopped || !picker.open || document.hidden || !isInputRoute() || next >= keys.length) return;
      checkRemote(keys[next++], function (r) {
        if (!r || (!r.ok && r.status !== 404)) { stopped = true; return; }
        setTimeout(run, 0);
      }, FOCUS_CHECK_GAP_MS);
    }
    run(); run(); // two small HEAD requests at a time, only for characters saved here
  }
  function fetchDoc(ign, cb) {
    busy(1);
    cloudFetch('GET', cloudPath(ign)).then(function (r) {
      busy(-1);
      if (r.status === 404) { cb(null, null); return; }
      if (!r.ok || !r.json) { cb({ status: r.status, json: r.json, retryAfter: r.retryAfter }, null); return; }
      cb(null, r.json);
    }, function (e) { busy(-1); cb(e, null); });
  }
  // Plain English for a failed read or delete. A 429 gets the same wording as a rate limited upload.
  function httpErrText(r, what) {
    if (r && r.offline) return 'Cloud unavailable';
    if (r && r.status === 429) return 'The cloud is rate limiting requests. Try again in ' + (r.retryAfter ? r.retryAfter + ' seconds.' : 'a minute.');
    return what;
  }
  /* -- character look: GET /v1/avatar/:ign (the backend proxies the Nexon rankings) --------
     Cached in localStorage 'msfix:cloud:avatars' as { [ignLower]: { image, level, job, worldId,
     at, miss } }. A hit is reused for 7 days, a miss for 1 day. Traffic budget: a lookup runs
     only (a) when the dropdown opens, for rows without a fresh entry, at most AVATAR_OPEN_MAX
     per open, (b) in the add dialog once the typed IGN has sat unchanged for 600 ms, (c) after
     a rename or Set IGN. Never from polling, focus, autosave, page load or a re-render. -- */
  var LS_CLOUD_AVATARS = 'msfix:cloud:avatars';
  var AVATAR_HIT_MS = 7 * 86400000, AVATAR_MISS_MS = 86400000, AVATAR_OPEN_MAX = 8, AVATAR_DEBOUNCE_MS = 600, AVATAR_MAX = 300, AVATAR_RETRY_MS = 600000;
  var avatarInflight = {};   // ignLower -> [cb]: one request per IGN at a time
  var avatarRetryAt = {};    // ignLower -> time: an error that is not a miss (429, 500) waits before the next try
  var avatarBroken = {};     // image URL -> true: the browser could not load it (404, blocked host); not requested again this session
  function avatarMap() { var m = lsJson(LS_CLOUD_AVATARS, {}); return m && typeof m === 'object' ? m : {}; }
  function avatarFresh(e) {
    if (!e || !e.at) return false;
    var t = new Date(e.at).getTime(); if (isNaN(t)) return false;
    return Date.now() - t < (e.miss ? AVATAR_MISS_MS : AVATAR_HIT_MS);
  }
  // The fresh entry for an IGN, else null. A miss is an entry too ({ miss: true }): callers check `.image`.
  function avatarCached(ign) { var e = avatarMap()[String(ign || '').toLowerCase()]; return avatarFresh(e) ? e : null; }
  function avatarStore(lower, entry) {
    var m = avatarMap(); m[lower] = entry;
    var ks = Object.keys(m);
    if (ks.length > AVATAR_MAX) {
      ks.sort(function (a, b) { return String(m[a].at || '') < String(m[b].at || '') ? -1 : 1; });
      for (var i = 0; i < ks.length - AVATAR_MAX; i++) delete m[ks[i]];
    }
    lsSet(LS_CLOUD_AVATARS, JSON.stringify(m));
  }
  // cb(entry) once: the fresh cached entry right away (no request), else after one GET. A miss
  // arrives as { miss: true }; offline or any other failure arrives as null and caches nothing.
  function avatarFor(ign, cb) {
    cb = cb || function () {};
    ign = String(ign || '').trim();
    var lower = ign.toLowerCase();
    if (!IGN_RE.test(ign)) { cb(null); return; }
    var hit = avatarCached(lower);
    if (hit) { cb(hit); return; }
    if (avatarInflight[lower]) { avatarInflight[lower].push(cb); return; }
    if (cloud.offline || !cloudEnabled() || (avatarRetryAt[lower] && Date.now() < avatarRetryAt[lower])) { cb(null); return; }
    avatarInflight[lower] = [cb];
    var settle = function (entry) {
      var cbs = avatarInflight[lower] || []; delete avatarInflight[lower];
      for (var i = 0; i < cbs.length; i++) try { cbs[i](entry); } catch (e) {}
      if (entry && entry.image) paintAvatars(lower, entry);
    };
    var p;
    try { p = cloudFetch('GET', '/v1/avatar/' + encodeURIComponent(ign), { soft: true }); } catch (e) { settle(null); return; }
    p.then(function (r) {
      var j = r.json;
      if (r.ok && j && j.image) {
        var e = { image: String(j.image), level: Number(j.level) || 0, job: String(j.job || ''), worldId: Number(j.worldId) || 0, at: nowIso() };
        avatarStore(lower, e); settle(e); return;
      }
      if (r.status === 404) { var miss = { at: nowIso(), miss: true }; avatarStore(lower, miss); settle(miss); return; }
      avatarRetryAt[lower] = Date.now() + Math.max(AVATAR_RETRY_MS, (r.retryAfter || 0) * 1000);
      settle(null);
    }, function (err) {
      // A network failure backs off per IGN too, so a reopened dropdown does not re-ask for the same names.
      if (!(err && err.disabled)) avatarRetryAt[lower] = Date.now() + AVATAR_RETRY_MS;
      settle(null);
    });
  }
  // A box that shows the cached look of `ign` (or the silhouette). data-msfix-avatar carries the
  // IGN so a lookup that lands later can repaint it in place.
  function avatarBox(ign, extraCls) {
    var box = el('span', 'msfix-avatar' + (extraCls ? ' ' + extraCls : ''));
    box.setAttribute('data-msfix-avatar', String(ign || '').toLowerCase());
    box.setAttribute('aria-hidden', 'true');
    var e = ign ? avatarCached(ign) : null;
    paintAvatarBox(box, e && e.image ? e : null);
    return box;
  }
  function paintAvatarBox(box, entry) {
    var broken = !!(entry && entry.image && avatarBroken[entry.image]);
    if (entry && entry.image && !broken) {
      var img = box.querySelector('img');
      if (!img) {
        img = el('img'); img.alt = ''; img.draggable = false;
        img.setAttribute('loading', 'lazy'); img.setAttribute('referrerpolicy', 'no-referrer'); img.setAttribute('draggable', 'false');
        img.addEventListener('error', function () {
          avatarBroken[img.getAttribute('src') || ''] = true;   // remembered for the session: no repaint requests it again
          if (img.parentNode === box) { box.innerHTML = svgIcon('user'); box.setAttribute('data-msfix-avatar-state', 'error'); }
          if (picker.el && !picker.open) renderTrigger();   // the closed trigger hides a look that cannot load
        });
        box.innerHTML = ''; box.appendChild(img);
      }
      if (img.getAttribute('src') !== entry.image) img.src = entry.image;
      box.setAttribute('data-msfix-avatar-state', 'ok');
    } else if (!box.querySelector('svg')) {
      box.innerHTML = svgIcon('user'); box.setAttribute('data-msfix-avatar-state', broken ? 'error' : 'none');
    } else if (broken) {
      box.setAttribute('data-msfix-avatar-state', 'error');
    }
  }
  // A lookup landed: update every box on the page that shows this IGN, without re-rendering the
  // list (the active row and the keyboard focus stay where they are).
  function paintAvatars(lower, entry) {
    if (!/^[a-z0-9]{1,16}$/.test(lower)) return;
    var nodes = document.querySelectorAll('.msfix-avatar[data-msfix-avatar="' + lower + '"]');
    for (var i = 0; i < nodes.length; i++) paintAvatarBox(nodes[i], entry);
    if (picker.el && !picker.open) renderTrigger();   // the closed trigger shows the selected character's look
  }
  // Dropdown just opened: look up the listed characters that have no fresh entry, at most
  // AVATAR_OPEN_MAX of them. Re-renders (typing, sync state) never call this.
  function avatarWarm() {
    if (!picker.open) return;
    var n = 0, seen = {};
    for (var i = 0; i < picker.items.length && n < AVATAR_OPEN_MAX; i++) {
      var it = picker.items[i]; if (it.type !== 'local') continue;
      var b = cloud.bindings[it.key]; if (!b || !b.ign || !IGN_RE.test(b.ign)) continue;
      var lower = b.ign.toLowerCase(); if (seen[lower]) continue; seen[lower] = 1;
      if (avatarCached(lower) || avatarInflight[lower]) continue;
      n++; avatarFor(b.ign);
    }
  }
  // `report` (optional) collects the fields conformTo had to reset. Only the explicit "load
  // the cloud copy" path (applyCloudDoc) shows it: compare and preview callers stay quiet.
  function docPresetData(doc, report) {
    var d = doc && doc.preset && doc.preset.data;
    if (!d || !d.stat) return null;
    var tmpl = currentUserStatTemplate() || siteRefs.defaultUserStat;
    return tmpl ? conformTo(tmpl, d, report) : d;
  }

  /* -- polling: HEAD the selected character every 5 min (backing off to 15) and on focus, at most once a minute -- */
  function stopPolling() { if (cloud.pollTimer) { clearTimeout(cloud.pollTimer); cloud.pollTimer = null; } }
  function startPolling() { if (cloud.pollTimer) return; cloud.pollTimer = setTimeout(pollTick, cloud.pollDelay); }
  function pollTick(immediate) {
    if (document.hidden && !immediate) { stopPolling(); return; }   // no passive traffic from background tabs
    stopPolling();
    var key = selectedKey();
    if (!isInputRoute() || !cloudEnabled() || !key || !cloud.bindings[key] || !cloud.bindings[key].ign) { cloud.pollDelay = POLL_MS; return; }
    if (document.hidden && !immediate) { cloud.pollTimer = setTimeout(pollTick, cloud.pollDelay); return; }
    checkRemote(key, function (r) {
      var ok = !!r && (r.ok || r.status === 404);   // any other status (5xx, 429) backs off like a failed request
      cloud.pollDelay = ok ? POLL_MS : Math.min(POLL_MAX_MS, cloud.pollDelay * 2);
      if (isInputRoute() && !document.hidden) startPolling();
    }, FOCUS_CHECK_GAP_MS);
  }

  /* -- sync state ------------------------------------------------------------------------ */
  function syncInfo() {
    var key = selectedKey();
    if (!key) return { state: 'none' };
    var b = cloud.bindings[key];
    if (!b || !b.ign) return { state: 'unlinked', key: key };
    if (!cloudEnabled()) return { state: 'off', key: key, b: b };
    var d = currentDraft(), h = d ? hashData(d) : null;
    var localChanged = !b.syncedHash || (!!h && h !== b.syncedHash);
    // A binding that was never uploaded can still know about a cloud copy (a HEAD 200 from the poll
    // or a 404 that cleared cloudUpdatedAt). Route it to the compare dialog, never to a blind upload.
    if (cloud.offline) return { state: 'offline', key: key, b: b };
    var check = remoteCheck(b);
    if ((check && check.pending) || (!check && b.cloudUpdatedAt)) return { state: 'checking', key: key, b: b };
    if (check && (!check.response || (!check.response.ok && check.response.status !== 404))) return { state: 'offline', key: key, b: b };
    if (!b.cloudUpdatedAt) return b.remoteUpdatedAt ? { state: 'cloud-ahead', key: key, b: b } : { state: 'not-uploaded', key: key, b: b };
    var cloudChanged = !!(b.remoteUpdatedAt && b.remoteUpdatedAt !== b.cloudUpdatedAt);
    if (!localChanged && !cloudChanged) return { state: 'synced', key: key, b: b };
    if (localChanged && !cloudChanged) return { state: 'local-ahead', key: key, b: b };
    if (!localChanged && cloudChanged) return { state: 'cloud-ahead', key: key, b: b };
    return { state: 'conflict', key: key, b: b };
  }
  var ICON_STATES = {
    'none':         { icon: 'cloud',          color: 'text-text-gray-low', title: 'No character selected. Inputs are not saved to a character.' },
    'unlinked':     { icon: 'cloud-off',      color: 'text-text-gray-low', title: 'Saved in this browser only. Click to link it to an IGN.' },
    'off':          { icon: 'cloud-off',      color: 'text-text-gray-low', title: 'Cloud sync is off.' },
    'not-uploaded': { icon: 'cloud-upload',   color: 'text-text-gray-low', title: 'Not in the cloud yet. Click to upload.' },
    'offline':      { icon: 'cloud-off',      color: 'text-red-500',       title: 'Cloud unavailable. Click to retry.' },
    'checking':     { icon: 'loader',         color: 'text-text-gray-low', title: 'Checking cloud...' },
    'synced':       { icon: 'cloud-check',    color: 'text-green-600',     title: 'Synced with the cloud.' },
    'local-ahead':  { icon: 'cloud-alert',    color: 'text-amber-500',     title: 'Edited since the last upload. Click to upload.' },
    'cloud-ahead':  { icon: 'cloud-download', color: 'text-amber-500',     title: 'The cloud copy is newer. Click to choose.' },
    'conflict':     { icon: 'cloud-alert',    color: 'text-amber-500',     title: 'Changed here and in the cloud. Click to choose.' }
  };
  /* -- site-styled hover tooltip for the sync icon (the native title is slow and unstyled) -- */
  var TIP_CLS = 'bg-popover text-popover-foreground z-[2147483647] w-fit rounded-md px-3 py-1.5 text-xs text-balance shadow-md msfix-tip';
  var TIP_ARROW_CLS = 'bg-popover fill-popover z-[2147483647] size-2.5 rotate-45 msfix-tip-arrow';
  function attachTooltip(btn) {
    if (btn.__msfixTip) return;
    var tip = null, arrow = null;
    function text() { return btn.getAttribute('data-msfix-tip') || btn.getAttribute('aria-label') || ''; }
    function place() {
      if (!tip) return;
      // The button can leave the DOM while hovered or focused (panel remount, route change).
      // Browsers fire no mouseleave/blur for that, so drop the tip instead of parking it at 8,8.
      if (!btn.isConnected) { hide(); return; }
      var r = btn.getBoundingClientRect();
      tip.style.left = '0px'; tip.style.top = '0px';
      var w = tip.offsetWidth, h = tip.offsetHeight;
      var left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2));
      var top = r.bottom + 8, above = false;
      if (top + h > window.innerHeight - 8) { top = r.top - h - 8; above = true; }
      tip.style.left = left + 'px'; tip.style.top = top + 'px';
      arrow.style.left = (r.left + r.width / 2 - 5) + 'px';
      arrow.style.top = (above ? top + h - 5 : top - 5) + 'px';
    }
    function show() {
      var t = text(); if (!t) return;
      if (!tip) {
        tip = el('div', TIP_CLS); tip.setAttribute('role', 'tooltip'); tip.setAttribute('data-msfix-ui', '');
        tip.id = 'msfix-tip-' + Math.random().toString(36).slice(2, 8);
        tip.style.cssText = 'position:fixed;max-width:280px;pointer-events:none;white-space:normal';
        arrow = el('div', TIP_ARROW_CLS); arrow.setAttribute('data-msfix-ui', '');
        arrow.style.cssText = 'position:fixed;pointer-events:none';
        document.body.appendChild(tip); document.body.appendChild(arrow);
        btn.setAttribute('aria-describedby', tip.id);
      }
      tip.textContent = t; place();
    }
    function hide() { if (tip) { tip.remove(); arrow.remove(); tip = arrow = null; btn.removeAttribute('aria-describedby'); } }
    btn.addEventListener('mouseenter', show); btn.addEventListener('focus', show);
    btn.addEventListener('mouseleave', hide); btn.addEventListener('blur', hide); btn.addEventListener('click', hide);
    window.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); }, true);
    window.addEventListener('scroll', place, true); window.addEventListener('resize', place);
    btn.__msfixTip = { refresh: function () { if (tip) show(); }, hide: hide };
  }
  function updateIcon() {
    if (!picker.icon) return;
    var info = syncInfo(), st = ICON_STATES[info.state] || ICON_STATES.none;
    var title = st.title;
    if (info.state === 'offline' && cloud.offlineReason === 'blocked') title = 'Cloud access blocked. Local saves remain available. Click to retry.';
    var busyNow = cloud.busy > 0;
    picker.icon.className = SOFT_BASE + ' msfix-sync ' + (busyNow ? 'text-text-gray-low' : st.color);
    picker.icon.innerHTML = busyNow ? svgIcon('loader', 'animate-spin') : svgIcon(st.icon, info.state === 'checking' ? 'animate-spin' : '');
    var tipText = busyNow ? 'Working...' : title;
    picker.icon.setAttribute('data-msfix-tip', tipText); picker.icon.removeAttribute('title');
    picker.icon.setAttribute('aria-label', tipText);
    if (picker.icon.__msfixTip) picker.icon.__msfixTip.refresh();
    picker.icon.setAttribute('data-msfix-sync', busyNow ? 'busy' : info.state);
    if (picker.live && picker.live.textContent !== title) picker.live.textContent = title;
  }

  /* -- selection / loading --------------------------------------------------------------- */
  function regionForPreset(d) {
    // Region is part of the preset. Require a complete, unambiguous set of flags before switching.
    var flags = { isGMS: 'gms', isTMS: 'tms', isJMS: 'jms', isMSEA: 'msea' }, region = 'kms', count = 0;
    for (var k in flags) {
      if (!d || typeof d[k] !== 'boolean') return null;
      if (d[k]) { region = flags[k]; count++; }
    }
    return count <= 1 ? region : null;
  }
  function loadIntoForm(key) {
    var s = cloudStores(), slot = presetMap()[key];
    if (!s || !slot || !slot.data) return false;
    var d = clone(slot.data);
    var region = regionForPreset(d);
    if (region) {
      var rs = siteRefs.regionStore && siteRefs.regionStore.getState();
      var current = rs ? rs.region : (readSiteRegion() || {}).region;
      if (current !== region) {
        if (!rs || typeof rs.setRegion !== 'function') { toastErr('Choose ' + region.toUpperCase() + ' in the header, then load the character again.'); return false; }
        // loadDraft remounts the site's form. Its mount effect copies the header's region into
        // the draft, so update the real store first or a fresh KMS browser rewrites a GMS preset.
        rs.setRegion(region);
        backupRegion();
      }
    }
    cloud.lastLoaded = d;
    try { s.ms.getState().loadDraft(d); } catch (e) { toastErr('Could not load the character'); return false; }
    return true;
  }
  function setSelected(key, load, quiet) {
    var map = presetMap(), slot = map[key];
    if (!slot) return false;
    // A pending autosave still belongs to the old character: write it before the form changes.
    if (cloud.saveTimer && cloud.selected && cloud.selected.key !== key) flushAutosave();
    var b = cloud.bindings[key];
    cloud.selected = { key: key, ign: b ? b.ign : null, label: slot.label || '', savedAt: slot.savedAt || null };
    if (!slot.label && !slot.savedAt) cloud.selected.hash = hashData(slot.data);   // see slotMatchesSel
    saveBindings();
    if (load && !loadIntoForm(key)) return false;
    renderTrigger(); updateIcon();
    if (!quiet) toastOk((load ? 'Loaded ' : 'Selected ') + slotName(key, slot));
    if (b && b.ign) { cloud.pollDelay = POLL_MS; checkRemote(key, null, FOCUS_CHECK_GAP_MS); startPolling(); }
    return true;
  }
  function deselect(reason) {
    if (!cloud.selected) return;
    if (cloud.saveTimer) flushAutosave();
    cloud.selected = null; saveBindings();
    renderTrigger(); updateIcon();
    if (reason) toastOk(reason);
  }
  // After a structural draft change we did not cause (native Load, Reset, a seeded search
  // result, Undo) find out which slot — if any — the form now shows.
  function resolveSelectionFromDraft(draft, strict) {
    if (!draft) return;
    // The form already shows the new draft, so a pending autosave must not land in the old slot.
    if (cloud.saveTimer) { clearTimeout(cloud.saveTimer); cloud.saveTimer = null; }
    var h = hashData(draft), map = presetMap(), keys = slotKeys(map), cur = selectedKey();
    if (cur && map[cur] && hashData(map[cur].data) === h) return;
    for (var i = 0; i < keys.length; i++) {
      if (keys[i] === cur || !map[keys[i]] || !presetDataOk(map[keys[i]].data)) continue;
      if (hashData(map[keys[i]].data) === h) { setSelected(keys[i], false, true); return; }
    }
    if (strict && cur) deselect('Inputs no longer match ' + slotName(cur, map[cur]) + '. Pick a character to resume saving.');
  }

  /* -- auto-save: the draft goes into the selected slot 500 ms after the last change ------ */
  // Stamp the binding and the selection for `key` with the label/savedAt about to be written,
  // BEFORE the store write: the site notifies its subscribers synchronously, so the reconciler
  // (label/savedAt matching) runs during setPresetMap and would drop an unlabelled slot whose
  // only match is the savedAt we are replacing. Returns a function that restores the old values.
  function stampSlotRefs(key, label, savedAt) {
    var b = cloud.bindings[key], sel = cloud.selected && cloud.selected.key === key ? cloud.selected : null;
    var bOld = b ? { label: b.label, savedAt: b.savedAt } : null, sOld = sel ? { label: sel.label, savedAt: sel.savedAt } : null;
    if (b) { b.label = label; b.savedAt = savedAt; }
    if (sel) { sel.label = label; sel.savedAt = savedAt; }
    return function () {
      if (b && bOld) { b.label = bOld.label; b.savedAt = bOld.savedAt; }
      if (sel && sOld) { sel.label = sOld.label; sel.savedAt = sOld.savedAt; }
    };
  }
  function writeDraftToSlot(key, draft) {
    var map = clone(presetMap()), slot = map[key];
    if (!slot) return false;
    var now = nowIso();
    map[key] = { data: clone(draft), label: slot.label || '', savedAt: now };
    var undo = stampSlotRefs(key, map[key].label, now);
    if (!setPresetMap(map)) { undo(); return false; }
    saveBindings();
    return true;
  }
  function flushAutosave() {
    if (cloud.saveTimer) { clearTimeout(cloud.saveTimer); cloud.saveTimer = null; }
    autosaveTick(true);
  }
  function autosaveTick(noUpload) {
    cloud.saveTimer = null;
    var key = selectedKey(); if (!key) return;
    var d = currentDraft(); if (!d || !presetDataOk(d)) return;
    var slot = presetMap()[key]; if (!slot) return;
    if (hashData(slot.data) === hashData(d)) return;
    if (!writeDraftToSlot(key, d)) return;
    pushHistory(key, 'edit', d);
    updateIcon(); if (picker.open) renderDropdown();
    var b = cloud.bindings[key];
    if (!noUpload && autoUploadOn() && cloudEnabled() && b && b.ign) scheduleAutoUpload(key);
  }
  function scheduleAutoUpload(key) {
    if (cloud.uploadTimer) clearTimeout(cloud.uploadTimer);
    cloud.uploadTimer = setTimeout(function () {
      cloud.uploadTimer = null;
      var info = syncInfo();
      if (info.key !== key || (info.state !== 'local-ahead' && info.state !== 'not-uploaded')) return;
      uploadSlot(key, { quiet: true, onConflict: function () {
        // never pop a modal mid-edit: the icon shows the conflict, one toast per character
        if (cloud.conflictToastKey !== key) { cloud.conflictToastKey = key; toastErr(cloud.bindings[key].ign + ' changed in the cloud. Click the sync icon to choose.'); }
      } });
    }, AUTOUPLOAD_MS);
  }
  function onDraftChange(s, prev) {
    if (s && prev && s.result !== prev.result) noteResult(s.result);
    if (!s || !prev || s.draftStat === prev.draftStat) return;
    var structural = s.draftVersion !== prev.draftVersion;
    if (structural) { setTimeout(ensureCharPicker, 0); setTimeout(ensureCharPicker, 250); setTimeout(ensureCharPicker, 900); }
    if (s.draftStat === cloud.lastLoaded) { updateIcon(); return; }   // our own load echoing back
    if (structural) { resolveSelectionFromDraft(s.draftStat, true); updateIcon(); return; }
    if (cloud.saveTimer) clearTimeout(cloud.saveTimer);
    cloud.saveTimer = setTimeout(autosaveTick, AUTOSAVE_MS);
    updateIcon();
  }
  function onPresetChange() {
    reconcileBindings(); checkPendingImport();
    renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
  }
  function ensureSubscriptions() {
    if (cloud.subscribed) return true;
    var s = cloudStores(); if (!s) return false;
    cloud.subscribed = true;
    reconcileBindings();
    resolveSelectionFromDraft(currentDraft(), false);
    try { noteResult(s.ms.getState().result); } catch (e) {}
    try { s.ms.subscribe(onDraftChange); } catch (e) {}
    try { s.ps.subscribe(onPresetChange); } catch (e) {}
    return true;
  }
  // A native import of a file that carries "ign" (our export enrichment) is bound once the
  // site has added its slot.
  function checkPendingImport() {
    var p = cloud.pendingImport; if (!p) return;
    if (Date.now() - p.at > 15000) { cloud.pendingImport = null; return; }
    if (bindingByIgn(p.ign)) { cloud.pendingImport = null; return; }
    var map = presetMap(), keys = slotKeys(map);
    for (var i = keys.length - 1; i >= 0; i--) {
      var s = map[keys[i]];
      if (cloud.bindings[keys[i]] || !s || !presetDataOk(s.data)) continue;
      if (eqi(s.label, p.label) || eqi(s.label, p.ign)) { bindSlot(keys[i], p.ign, null); cloud.pendingImport = null; return; }
    }
  }
  function bindSlot(key, ign, doc) {
    var slot = presetMap()[key]; if (!slot) return;
    var prev = cloud.bindings[key] || {}, oldHk = histKey(key);
    if (prev.ign && eqi(prev.ign, ign)) ign = prev.ign;   // keep the case the user typed
    cloud.bindings[key] = {
      ign: ign, label: slot.label || '', savedAt: slot.savedAt || null,
      cloudUpdatedAt: doc ? doc.updatedAt : (prev.ign && eqi(prev.ign, ign) ? prev.cloudUpdatedAt : null),
      remoteUpdatedAt: doc ? doc.updatedAt : null,
      syncedHash: doc ? hashData(slot.data) : (prev.ign && eqi(prev.ign, ign) ? prev.syncedHash : null),
      syncedAt: doc ? nowIso() : null
    };
    if (cloud.selected && cloud.selected.key === key) cloud.selected.ign = ign;
    if (doc) noteRemote(cloud.bindings[key], { ok: true, status: 200, etag: doc.updatedAt });
    saveBindings();
    moveHistory(oldHk, histKey(key));   // the slot's saves follow it under its IGN
  }

  /* -- slot writes ----------------------------------------------------------------------- */
  function allocSlotKey(map) {
    var keys = slotKeys(map);
    for (var i = 0; i < keys.length; i++) {   // reuse an untouched slot before appending
      var s = map[keys[i]];
      if (s && !presetDataOk(s.data) && !(s.label || '').trim() && !cloud.bindings[keys[i]]) return keys[i];
    }
    var max = 0; keys.forEach(function (k) { if (+k > max) max = +k; });
    return String(max + 1);
  }
  // Write `data` under `label` into `key` (or a fresh slot) and return the key.
  function writeSlot(key, data, label) {
    var map = clone(presetMap()), now = nowIso(), undo = null, oldHk = key ? histKey(key) : null;
    if (!key) key = allocSlotKey(map);
    else if (map[key]) undo = stampSlotRefs(key, label || '', now);
    map[key] = { data: clone(data), label: label || '', savedAt: now };
    if (setPresetMap(map)) { moveHistory(oldHk, histKey(key)); return key; }
    if (undo) undo();
    return null;
  }
  // Pull the cloud document into a slot (writing it, re-binding, and reloading the form if
  // that slot is the selected one).
  function applyCloudDoc(key, doc) {
    var report = [], dataIn = docPresetData(doc, report);
    if (!dataIn || !presetDataOk(dataIn)) { toastErr('The cloud copy of ' + doc.ign + ' is not a valid character file'); return null; }
    var cur = presetMap()[key];
    if (cur && presetDataOk(cur.data)) pushHistory(key, 'keep', cur.data);
    key = writeSlot(key, dataIn, (cur && cur.label) || doc.ign);
    if (!key) return null;
    conformToast(report, 'the cloud copy');
    bindSlot(key, doc.ign || cloud.bindings[key].ign, doc);
    pushHistory(key, 'pull', dataIn);
    if (selectedKey() === key) { loadIntoForm(key); renderTrigger(); updateIcon(); }
    return key;
  }
  function uploadSlot(key, opts, cb) {
    opts = opts || {};
    if (key === selectedKey()) flushAutosave();
    var slot = presetMap()[key], b = cloud.bindings[key];
    if (!slot || !b || !b.ign) { if (cb) cb(false); return; }
    if (!presetDataOk(slot.data)) { toastErr('Enter a class and level before uploading'); if (cb) cb(false); return; }
    var warns = statWarnings(slot.data);
    if (warns.length && !opts.warned) {
      if (opts.quiet) {
        // never pop a modal mid-edit: one toast per character, the icon stays out of sync
        if (cloud.warnToastKey !== key) { cloud.warnToastKey = key; toastErr('Not uploaded. ' + warns[0] + ' Click the sync icon to upload anyway.'); }
        if (cb) cb(false); return;
      }
      confirmDialog('Check the inputs for ' + b.ign, warns.join(' '), 'Upload anyway', function () {
        var o = {}; for (var k in opts) o[k] = opts[k]; o.warned = true;
        uploadSlot(key, o, cb);
      });
      return;
    }
    if (!warns.length) cloud.warnToastKey = null;
    var m = slotMeta(slot.data);
    // The server derives class, level and hexaStat from preset.data and caps labels at 64 chars.
    // Only hexaConverted is sent as meta, so a stray value cannot turn a valid preset into a 400.
    var lbl = String(slot.label || b.ign).slice(0, 64);
    var body = {
      preset: { type: 'maplescouter-manual-preset', v: 1, savedAt: slot.savedAt || nowIso(), label: lbl, data: slot.data },
      label: lbl,
      meta: { hexaConverted: m.hexa && !m.hexaPlain ? m.hexa : null }
    };
    var headers = {};
    if (b.cloudUpdatedAt && opts.ifMatch !== false) headers['If-Match'] = '"' + b.cloudUpdatedAt + '"';
    busy(1);
    cloudFetch('PUT', cloudPath(b.ign), { body: body, headers: headers }).then(function (r) {
      busy(-1);
      if (r.ok) {
        var up = (r.json && r.json.updatedAt) || r.etag || nowIso();
        b.cloudUpdatedAt = up; b.remoteUpdatedAt = up; b.syncedHash = hashData(slot.data); b.syncedAt = nowIso();
        noteRemote(b, { ok: true, status: 200, etag: up });
        pushHistory(key, 'upload', slot.data);
        cloud.conflictToastKey = null; saveBindings(); refreshCloudUi();
        if (!opts.quiet) toastOk('Uploaded to the cloud');
        if (cb) cb(true);
      } else if (r.status === 409) {
        var remote = r.json ? r.json.updatedAt : undefined;
        if (remote === null) { b.cloudUpdatedAt = null; b.remoteUpdatedAt = null; } else if (remote) b.remoteUpdatedAt = remote;
        saveBindings(); updateIcon();
        if (opts.onConflict) opts.onConflict(); else toastErr(b.ign + ' changed in the cloud. Click the sync icon to choose.');
        if (cb) cb(false);
      } else {
        toastErr(r.status === 429 ? 'The cloud is rate limiting uploads. Try again in ' + (r.retryAfter ? r.retryAfter + ' seconds.' : 'a minute.')
          : 'Cloud upload failed (' + r.status + (r.json && (r.json.detail || r.json.error) ? ' ' + (r.json.detail || r.json.error) : '') + ')');
        if (cb) cb(false);
      }
    }, function (e) { busy(-1); if (!e.disabled) toastErr('Cloud unavailable. Upload skipped.'); updateIcon(); if (cb) cb(false); });
  }

  /* -- dialogs --------------------------------------------------------------------------- */
  function confirmDialog(title, subtitle, goLabel, onGo, extraBuild) {
    msDialog({ title: title, subtitle: subtitle, build: function (body, close) {
      if (extraBuild) extraBuild(body);
      msActions(body, 'Cancel', function () { close(); }, goLabel, function () { close(); onGo(); });
    } });
  }
  function leafDiff(a, b, path, out) {
    if (out.length > 300) return;
    if (a && b && typeof a === 'object' && typeof b === 'object') {
      var keys = {}; Object.keys(a).forEach(function (k) { keys[k] = 1; }); Object.keys(b).forEach(function (k) { keys[k] = 1; });
      Object.keys(keys).sort().forEach(function (k) { leafDiff(a[k], b[k], path ? path + '.' + k : k, out); });
      return;
    }
    if (a !== b && !(a == null && b == null)) out.push({ path: path, a: a, b: b });
  }
  function fmtVal(v) {
    if (v === '' || v == null) return 'empty';
    if (typeof v === 'string' && HANGUL.test(v)) v = classEn(v);
    var s = typeof v === 'string' ? v : JSON.stringify(v);
    return s.length > 22 ? s.slice(0, 21) + '...' : s;
  }
  // Readable name for a diff row: 'stat.myClass' becomes 'Class', 'hexa.skillCore1' becomes 'Skill Core 1'.
  var DIFF_LABELS = { myClass: 'Class', level: 'Level', hexaStat: 'HEXA Stat', mainStatBase: 'Main stat', mainStatPer: 'Main stat %', mainStatAbs: 'Main stat (flat)', subStatBase: 'Sub stat', subStatPer: 'Sub stat %', subStatAbs: 'Sub stat (flat)', atkBase: 'Attack', atkPercent: 'Attack %', dmg: 'Damage %', bossDmg: 'Boss damage %', normalDmg: 'Normal damage %', ignoreDef: 'IED %', critical: 'Crit rate %', criticalDmg: 'Crit damage %', buffDuration: 'Buff duration %', coolTimeReducePercent: 'Cooldown reduction %', coolTimeReduce: 'Cooldown reduction (s)', arcaneForce: 'Arcane Force', authenticForce: 'Sacred Force' };
  function diffLabel(path) {
    var leaf = String(path || '').replace(/^(?:stat|hexa)\./, '');
    if (DIFF_LABELS[leaf]) return DIFF_LABELS[leaf];
    var core = /^(skill|mastery|rein|general)Core(\d+)$/.exec(leaf);
    if (core) return { skill: 'Skill Core ', mastery: 'Mastery Core ', rein: 'Enhancement Core ', general: 'Common Core ' }[core[1]] + core[2];
    return leaf;
  }
  // The look cached by the avatar lookup (localStorage 'msfix:cloud:avatars'). Read only: a
  // dialog never starts a lookup of its own, it shows the picture when one is already known.
  function cloudDialogAvatar(ign) {
    var e = avatarCached(ign);
    return e && e.image && !e.miss ? e : null;
  }
  // One short question about a local/cloud disagreement: [Cancel] [mid] [go]. The subtitle
  // carries the cloud copy's meta; the field-by-field diff stays behind "Show differences".
  //   o.title, o.doc, o.question, o.midLabel/o.onMid, o.goLabel/o.onGo
  //   o.ign        show the character's cached look under the title
  //   o.yours      one extra line under the subtitle ("Yours: ...")
  //   o.localData  enables the "Show differences" toggle (local vs the cloud copy)
  function compareDialog(o) {
    closePicker();
    var cm = docMeta(o.doc), cloudData = docPresetData(o.doc);
    var diffs = []; if (o.localData && cloudData) leafDiff(o.localData, cloudData, '', diffs);
    msDialog({
      title: o.title,
      subtitle: metaLine(cm) + ', Cloud: ' + relTime(o.doc.updatedAt),
      build: function (body, close) {
        var av = o.ign ? cloudDialogAvatar(o.ign) : null;
        if (av) {
          var wrap = el('div', 'flex w-full justify-center');
          wrap.appendChild(avatarBox(o.ign, 'msfix-avatar-lg'));
          body.insertBefore(wrap, body.children[1] || null);   // between the title and the subtitle
        }
        if (o.yours) body.appendChild(el('span', CLS.hint, o.yours));
        if (o.localData) {
          var link = el('span', 'text-text-gray-low text-xs underline cursor-pointer self-center', 'Show differences');
          link.setAttribute('role', 'button'); link.tabIndex = 0;
          var box = el('div', 'flex flex-col gap-0.5 text-left'); box.style.display = 'none';
          if (!diffs.length) box.appendChild(el('span', CLS.hintLeft, cloudData ? 'Same inputs on both sides.' : 'The cloud copy has no inputs to compare.'));
          else box.appendChild(el('span', 'text-xs font-semibold', diffs.length + (diffs.length === 1 ? ' field is different' : ' fields are different')));
          diffs.slice(0, 8).forEach(function (d) {
            var row = el('span', 'text-text-gray-low text-xs truncate', diffLabel(d.path) + ': yours ' + fmtVal(d.a) + ', cloud ' + fmtVal(d.b));
            row.title = d.path + ': yours ' + fmtVal(d.a) + ', cloud ' + fmtVal(d.b);
            box.appendChild(row);
          });
          if (diffs.length > 8) box.appendChild(el('span', 'text-text-gray-low text-xs', 'and ' + (diffs.length - 8) + ' more'));
          var toggle = function () { var show = box.style.display === 'none'; box.style.display = show ? '' : 'none'; link.textContent = show ? 'Hide differences' : 'Show differences'; };
          link.addEventListener('click', toggle);
          link.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
          body.appendChild(link); body.appendChild(box);
        }
        body.appendChild(el('span', 'text-center text-sm', o.question));
        var row = el('div', 'flex w-full gap-2');
        var mk = function (label, cls, fn) { var x = el('button', cls, label); x.type = 'button'; x.addEventListener('click', function () { close(); if (fn) fn(); }); row.appendChild(x); return x; };
        mk('Cancel', CLS.ghost, null);
        mk(o.midLabel, CLS.ghost, o.onMid);
        mk(o.goLabel, CLS.primary, o.onGo);
        body.appendChild(row);
      }
    });
  }
  // An upload came back 409: the cloud copy moved since this browser last saw it. One question.
  function openUploadConflict(key) {
    var b = cloud.bindings[key], slot = presetMap()[key];
    if (!b || !slot) return;
    flushAutosave();
    fetchDoc(b.ign, function (err, doc) {
      if (err) { toastErr(httpErrText(err, 'Could not read ' + b.ign + ' from the cloud')); return; }
      if (!doc) { b.cloudUpdatedAt = null; b.remoteUpdatedAt = null; saveBindings(); updateIcon(); toastErr(b.ign + ' is no longer in the cloud. Click the icon to upload it again.'); return; }
      slot = presetMap()[key];
      compareDialog({
        title: 'The cloud copy changed', doc: doc, localData: slot.data,
        question: 'Replace it with your inputs?',
        midLabel: 'Load cloud copy', onMid: function () { if (applyCloudDoc(key, doc)) toastOk('Loaded the cloud copy'); },
        goLabel: 'Replace', onGo: function () { uploadSlot(key, { ifMatch: false }); }
      });
    });
  }
  // The sync icon's click: one action per state.
  function onSyncClick() {
    closePicker();
    var info = syncInfo(), key = info.key, b = info.b, map = presetMap();
    switch (info.state) {
      case 'none': picker.input.focus(); openPicker(); return;
      case 'off': picker.input.focus(); openPicker(); toastOk('Cloud sync is off.'); return;
      case 'unlinked': openAddDialog(map[key] && IGN_RE.test(map[key].label || '') ? map[key].label : '', { linkKey: key }); return;
      case 'offline': cloud.pollDelay = POLL_MS; checkRemote(key, function (r) { if (r && (r.ok || r.status === 404)) toastOk('Cloud is back'); else toastErr('Still offline'); }); return;
      case 'checking': return;
      case 'synced': checkRemote(key, function (r) { if (r && r.ok && syncInfo().state === 'synced') toastOk(b.ign + ' is up to date'); }); return;
      case 'not-uploaded':
        // Look first: the IGN may have been created elsewhere since the last check.
        fetchDoc(b.ign, function (err, doc) {
          if (err) { toastErr(httpErrText(err, 'Could not read ' + b.ign + ' from the cloud')); return; }
          if (doc) { b.remoteUpdatedAt = doc.updatedAt; saveBindings(); updateIcon(); openCompareForSlot(key); return; }
          confirmDialog('Upload to the cloud?', '', 'Upload', function () { uploadSlot(key, { ifMatch: false }); });
        });
        return;
      case 'local-ahead':
        msDialog({ title: 'Upload changes to the cloud?', subtitle: 'Discard replaces your inputs with the cloud copy. The current inputs stay in History.', build: function (body, close) {
          var row = el('div', 'flex w-full gap-2');
          var mk = function (label, cls, fn) { var x = el('button', cls, label); x.type = 'button'; x.addEventListener('click', function () { close(); if (fn) fn(); }); row.appendChild(x); return x; };
          mk('Cancel', CLS.ghost, null);
          var discardBtn = mk('Discard my changes', CLS.ghost + ' text-red-500', function () { discardToCloud(key); });
          discardBtn.title = 'Replace my inputs with the cloud copy';
          discardBtn.setAttribute('aria-label', 'Replace my inputs with the cloud copy');
          mk('Upload', CLS.primary, function () { uploadSlot(key, { onConflict: function () { openUploadConflict(key); } }); });
          body.appendChild(row);
        } });
        return;
      default: openCompareForSlot(key); return;
    }
  }
  // Throw away local edits: the cloud copy replaces the slot and the form.
  function discardToCloud(key) {
    var b = cloud.bindings[key]; if (!b || !b.ign) return;
    flushAutosave();
    fetchDoc(b.ign, function (err, doc) {
      if (err) { toastErr(httpErrText(err, 'Could not read ' + b.ign + ' from the cloud')); return; }
      if (!doc) { b.cloudUpdatedAt = null; b.remoteUpdatedAt = null; saveBindings(); updateIcon(); toastErr(b.ign + ' is no longer in the cloud. Nothing to restore.'); return; }
      if (applyCloudDoc(key, doc)) toastOk('Restored from the cloud');
    });
  }
  function openCompareForSlot(key) {
    var b = cloud.bindings[key], slot = presetMap()[key];
    if (!b || !slot) return;
    flushAutosave();
    fetchDoc(b.ign, function (err, doc) {
      if (err) { toastErr(httpErrText(err, 'Could not read ' + b.ign + ' from the cloud')); return; }
      if (!doc) { b.cloudUpdatedAt = null; b.remoteUpdatedAt = null; saveBindings(); updateIcon(); toastErr(b.ign + ' is no longer in the cloud. Click the icon to upload it again.'); return; }
      slot = presetMap()[key];
      // Timestamps alone flag the cloud as newer, but a repeat upload of the same inputs (a second
      // device, the same file again) changes nothing. Adopt the cloud stamp and stay synced.
      var cd = docPresetData(doc);
      if (cd && hashData(cd) === hashData(slot.data)) {
        b.cloudUpdatedAt = doc.updatedAt; b.remoteUpdatedAt = doc.updatedAt; b.syncedHash = hashData(slot.data); b.syncedAt = b.syncedAt || nowIso();
        cloud.conflictToastKey = null; saveBindings(); updateIcon();
        toastOk(b.ign + ' matches the cloud copy. Nothing to do.');
        return;
      }
      // "Changed here and in the cloud" only when the local inputs moved too; otherwise the
      // cloud copy is simply newer (a never-uploaded character counts as nothing changed here).
      var st = key === selectedKey() ? syncInfo().state : (b.syncedHash && hashData(slot.data) !== b.syncedHash ? 'conflict' : 'cloud-ahead');
      compareDialog({
        title: st === 'conflict' || st === 'local-ahead' ? 'Changed here and in the cloud' : 'The cloud copy is newer',
        doc: doc, localData: slot.data,
        yours: metaLine(slotMeta(slot.data)) + ', Local: ' + relTime(slot.savedAt),
        question: 'Load the cloud copy, or upload yours?',
        midLabel: 'Load cloud copy', onMid: function () { if (applyCloudDoc(key, doc)) toastOk('Loaded the cloud copy'); },
        goLabel: 'Upload mine', onGo: function () { b.cloudUpdatedAt = doc.updatedAt; saveBindings(); uploadSlot(key, { onConflict: function () { openUploadConflict(key); } }); }
      });
    });
  }
  // "+ Add character": IGN → look it up → save the current inputs, or ask one question when
  // the IGN is already saved here or already in the cloud.
  function openAddDialog(prefill, opts) {
    opts = opts || {};
    closePicker();
    var map = presetMap(), sel = selectedKey();
    // With an unlinked preset selected, adding links THAT preset (the form shows its inputs)
    // instead of duplicating it into a new slot.
    var linkKey = opts.linkKey || (sel && map[sel] && !(cloud.bindings[sel] && cloud.bindings[sel].ign) ? sel : null);
    var draft = currentDraft();
    var localData = (linkKey && linkKey !== sel) ? map[linkKey].data : draft;
    if (!presetDataOk(localData)) { toastErr('Enter a class and level first'); return; }
    msDialog({
      title: linkKey ? 'Link ' + slotName(linkKey, map[linkKey]) + ' to an IGN' : 'Add character',
      subtitle: linkKey ? 'The character is renamed to the IGN.' : 'Starts a new character from the current inputs. Upload it later from the sync icon.',
      build: function (body, close) {
        var input = el('input', CLS.input); input.setAttribute('maxlength', '16'); input.placeholder = 'IGN'; input.value = prefill || '';
        input.setAttribute('autocapitalize', 'off'); input.setAttribute('spellcheck', 'false');
        body.appendChild(input);
        var err = el('span', 'text-red-500 text-xs text-center'); err.hidden = true; body.appendChild(err);
        // The character's look, once the typed IGN has sat unchanged for 600 ms: one line plus the image.
        var prev = el('div', 'msfix-avatar-preview flex w-full items-center justify-center gap-2 text-xs'); prev.hidden = true;
        var prevBox = avatarBox('', ''), prevText = el('span', 'text-text-gray-low text-xs');
        prev.appendChild(prevBox); prev.appendChild(prevText); body.appendChild(prev);
        var lookTimer = null;
        var stopLook = function () { if (lookTimer) { clearTimeout(lookTimer); lookTimer = null; } };
        var showLook = function (ign, e) {
          if (input.value.trim() !== ign) return;   // typed on since
          if (!e) { prev.hidden = true; return; }    // offline or unknown: say nothing
          prevBox.setAttribute('data-msfix-avatar', ign.toLowerCase());
          paintAvatarBox(prevBox, e.image ? e : null);
          prevText.textContent = e.image ? ((e.job ? e.job + ' ' : '') + 'Lv ' + (e.level || '?')) : 'Not found in the GMS rankings';
          prev.hidden = false;
        };
        var scheduleLook = function () {
          stopLook();
          var ign = input.value.trim();
          if (!IGN_RE.test(ign)) { prev.hidden = true; return; }
          var hit = avatarCached(ign);
          if (hit) { showLook(ign, hit); return; }   // already known: no request, no wait
          prev.hidden = true;
          lookTimer = setTimeout(function () {
            lookTimer = null;
            if (!document.contains(input) || input.value.trim() !== ign) return;   // dialog closed or text changed
            avatarFor(ign, function (e) { showLook(ign, e); });
          }, AVATAR_DEBOUNCE_MS);
        };
        input.addEventListener('input', scheduleLook);
        body.appendChild(el('span', CLS.hint, metaLine(slotMeta(localData))));
        var go = function () {
          var ign = input.value.trim();
          if (!IGN_RE.test(ign)) { err.textContent = '1 to 16 letters or digits'; err.hidden = false; input.focus(); return; }
          stopLook();
          var existing = bindingByIgn(ign);
          if (existing && existing.key !== linkKey) { close(); openExistsLocally(ign, existing.key, localData); return; }
          close(); addCharacter(ign, linkKey, localData);
        };
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
        msActions(body, 'Cancel', function () { stopLook(); close(); }, 'Add', go);
        if (input.value.trim()) scheduleLook();
        setTimeout(function () { input.focus(); input.select(); }, 30);
      }
    });
  }
  // The IGN is already one of the saved characters: overwrite it with these inputs (nothing is
  // uploaded, the sync icon does that later), or switch to it.
  function openExistsLocally(ign, key, localData) {
    var map = presetMap(), slot = map[key]; if (!slot) return;
    var b = cloud.bindings[key];
    msDialog({ title: 'Already saved here', subtitle: metaLine(slotMeta(slot.data)) + ', Local: ' + relTime(slot.savedAt), build: function (body, close) {
      var row = el('div', 'flex w-full gap-2');
      var mk = function (label, cls, fn) { var x = el('button', cls, label); x.type = 'button'; x.addEventListener('click', function () { close(); if (fn) fn(); }); row.appendChild(x); return x; };
      mk('Cancel', CLS.ghost, null);
      mk('Overwrite it', CLS.ghost, function () {
        // Save pending edits into the character that is selected now, before the selection moves.
        flushAutosave();
        var cur = presetMap()[key];
        if (cur && presetDataOk(cur.data)) pushHistory(key, 'keep', cur.data);
        if (!writeDraftToSlot(key, localData)) return;
        pushHistory(key, 'edit', localData);
        // localData may be another preset (row menu Set IGN), so load it unless the form already shows it.
        var d0 = currentDraft();
        if (!setSelected(key, !d0 || hashData(d0) !== hashData(localData), true)) return;
        toastOk('Overwritten' + (b && b.ign ? '. Click the sync icon to upload.' : '')); updateIcon();
      });
      mk('Switch to it', CLS.primary, function () { setSelected(key, true); });
      body.appendChild(row);
    } });
  }
  function addCharacter(ign, linkKey, localData) {
    var sel = selectedKey();
    var bindLocal = function (doc) {
      var key = writeSlot(linkKey, localData, ign);
      if (!key) return null;
      bindSlot(key, ign, doc);
      setSelected(key, !!linkKey && linkKey !== sel, true);   // the form already shows these inputs
      avatarFor(ign);   // usually a cache hit: the add dialog looked it up while the IGN was typed
      return key;
    };
    if (!cloudEnabled()) {
      confirmDialog('Add this character?', 'Saved in this browser only.', 'Add', function () { if (bindLocal(null)) toastOk('Saved ' + ign); });
      return;
    }
    fetchDoc(ign, function (err, doc) {
      if (err) {
        confirmDialog('Cloud unavailable', 'Save ' + ign + ' locally and upload it later from the sync icon?', 'Save locally', function () { if (bindLocal(null)) toastOk('Saved ' + ign + '. Not uploaded yet.'); });
        return;
      }
      if (!doc) {
        confirmDialog('Add this character?', 'Starts it from the current inputs. Upload it later from the sync icon.', 'Add', function () {
          if (bindLocal(null)) toastOk('Added. Click the sync icon to upload.');
        });
        return;
      }
      // Same inputs already in the cloud: link to it, nothing to upload or load.
      var cd = docPresetData(doc);
      if (cd && hashData(cd) === hashData(localData)) {
        if (bindLocal(doc)) toastOk('Linked ' + ign + '. The cloud copy has the same inputs.');
        return;
      }
      compareDialog({
        title: 'Already in the cloud', ign: ign, doc: doc,
        question: 'Load the cloud copy, or keep the inputs on the page?',
        // Keep my inputs: saved and linked, not uploaded. The binding has seen this cloud version
        // (so the next upload sends If-Match) but no synced hash, which reads as local-ahead.
        midLabel: 'Keep my inputs', onMid: function () {
          var key = bindLocal(doc); if (!key) return;
          var nb = cloud.bindings[key]; nb.syncedHash = null; nb.syncedAt = null;
          cloud.conflictToastKey = null; saveBindings(); updateIcon();
          toastOk('Saved here. Click the sync icon to upload.');
        },
        goLabel: 'Load from cloud', onGo: function () { var key = bindLocal(doc); if (!key) return; if (applyCloudDoc(key, doc)) toastOk('Loaded from the cloud'); }
      });
    });
  }
  function selectCloudOnly(ign) {
    closePicker();
    var existing = bindingByIgn(ign);
    if (existing) { setSelected(existing.key, true); return; }
    fetchDoc(ign, function (err, doc) {
      if (err || !doc) { toastErr(err && err.offline ? 'Cloud unavailable' : 'Could not load ' + ign + ' from the cloud'); return; }
      var d = docPresetData(doc);
      if (!d || !presetDataOk(d)) { toastErr('The cloud copy of ' + ign + ' is not a valid character file'); return; }
      var key = writeSlot(null, d, doc.ign || ign); if (!key) return;
      bindSlot(key, doc.ign || ign, doc);
      setSelected(key, true, true);
      toastOk('Loaded ' + (doc.ign || ign) + ' from the cloud');
    });
  }

  /* -- history: the last 10 saves of each character, restorable locally -------------------- */
  var LS_CLOUD_HISTORY = 'msfix:cloud:history', HISTORY_MAX = 10, HISTORY_EDIT_GAP_MS = 120000;
  var WHY = { upload: 'Uploaded', edit: 'Saved', pull: 'Cloud copy', keep: 'Before a change', restore: 'Restored', import: 'Imported' };
  var histCache = null;
  function histMap() { if (!histCache) histCache = lsJson(LS_CLOUD_HISTORY, {}); return histCache; }
  // Keyed by IGN, else by label. Slot numbers shift when a preset is deleted, so a preset with
  // neither has no stable key and keeps no history (null).
  function histKey(key) { var b = cloud.bindings[key]; if (b && b.ign) return b.ign.toLowerCase(); var s = presetMap()[key]; return s && s.label ? 'slot:' + s.label : null; }
  function saveHist() {
    var m = histMap();
    for (var tries = 0; tries < 8; tries++) {
      // localStorage directly, not lsSet: lsSet swallows the quota error this loop retries on
      try { localStorage.setItem(LS_CLOUD_HISTORY, JSON.stringify(m)); return; }
      catch (e) {   // storage quota: drop the oldest snapshot anywhere and retry
        var ok = null, oi = -1, oat = null;
        for (var k in m) for (var i = 0; i < m[k].length; i++) if (!oat || m[k][i].at < oat) { oat = m[k][i].at; ok = k; oi = i; }
        if (ok === null) return;
        m[ok].splice(oi, 1); if (!m[ok].length) delete m[ok];
      }
    }
  }
  // Rapid edits collapse into the latest "Saved" entry (one per two minutes); every other kind
  // of save gets its own entry. Identical content never creates a duplicate.
  function pushHistory(key, why, data) {
    if (!data || !presetDataOk(data)) return;
    var hk = histKey(key); if (!hk) return;
    var m = histMap(), list = m[hk] || (m[hk] = []), h = hashData(data);
    if (list.length && list[0].hash === h) { if (why !== 'edit') list[0].why = why; list[0].at = nowIso(); saveHist(); return; }
    if (why === 'edit' && list.length && list[0].why === 'edit' && Date.now() - new Date(list[0].at).getTime() < HISTORY_EDIT_GAP_MS) {
      list[0] = { at: nowIso(), why: 'edit', hash: h, data: clone(data) }; saveHist(); return;
    }
    list.unshift({ at: nowIso(), why: why, hash: h, data: clone(data) });
    while (list.length > HISTORY_MAX) list.pop();
    saveHist();
  }
  function historyFor(key) { var hk = histKey(key); return (hk && histMap()[hk]) || []; }
  // Re-key a character's saves (label change, linking to an IGN). Merges when both keys have saves.
  function moveHistory(fromKey, toKey) {
    if (!fromKey || !toKey || fromKey === toKey) return;
    var m = histMap(); if (!m[fromKey]) return;
    m[toKey] = m[fromKey].concat(m[toKey] || []).sort(function (a, b) { return a.at < b.at ? 1 : (a.at > b.at ? -1 : 0); }).slice(0, HISTORY_MAX);
    delete m[fromKey]; saveHist();
  }
  function openHistory(key) {
    closePicker();
    var slot = presetMap()[key]; if (!slot) return;
    var list = historyFor(key), cur = hashData(slot.data);
    msDialog({ title: 'History', subtitle: list.length ? 'Pick a save to load it into the form. Nothing is uploaded.' : (histKey(key) ? 'No saves yet.' : 'Set an IGN for this character to keep its saves.'), build: function (body, close) {
      var box = el('div', CLS.list);
      list.forEach(function (h, i) {
        var same = h.hash === cur;
        box.appendChild(msRow((WHY[h.why] || 'Saved') + ' ' + relTime(h.at) + (i === 0 ? ' (latest)' : ''), metaLine(slotMeta(h.data)) + (same ? ', same as now' : ''), function () { close(); restoreHistory(key, h); }));
      });
      body.appendChild(box);
      var cancel = el('button', CLS.ghost, 'Cancel'); cancel.type = 'button'; cancel.addEventListener('click', function () { close(); }); body.appendChild(cancel);
    } });
  }
  function restoreHistory(key, h) {
    var slot = presetMap()[key]; if (!slot) return;
    if (hashData(slot.data) === h.hash) { toastOk('That is the current version'); return; }
    if (selectedKey() === key) flushAutosave();
    pushHistory(key, 'keep', presetMap()[key].data);
    if (!writeSlot(key, h.data, slot.label)) return;
    if (selectedKey() === key) loadIntoForm(key); else setSelected(key, true, true);
    pushHistory(key, 'restore', h.data);
    renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
    toastOk('Loaded the save from ' + relTime(h.at) + '. Upload it from the sync icon if you want it in the cloud.');
  }

  /* -- row actions: overwrite / rename / delete local / delete cloud ---------------------- */
  function overwriteFromDraft(key) {
    var slot = presetMap()[key]; if (!slot) return;
    var d = currentDraft(); if (!d || !presetDataOk(d)) { toastErr('Enter a class and level first'); return; }
    var name = slotName(key, slot), b = cloud.bindings[key];
    confirmDialog('Overwrite this character?', 'The current inputs replace the saved character' + (b && b.ign && b.cloudUpdatedAt ? ' and its cloud copy.' : '.'), 'Overwrite', function () {
      if (cloud.selected && cloud.selected.key === key) flushAutosave();
      pushHistory(key, 'keep', slot.data);
      if (!writeDraftToSlot(key, d)) return;
      pushHistory(key, 'edit', d);
      setSelected(key, false, true);
      // Only a character that is already in the cloud uploads here. A linked but never-uploaded one stays local, as the dialog says.
      if (b && b.ign && b.cloudUpdatedAt) uploadSlot(key, { onConflict: function () { openUploadConflict(key); } });
      else { toastOk('Overwritten' + (b && b.ign ? '. Click the sync icon to upload.' : '')); updateIcon(); }
    });
  }
  function renameSlot(key) {
    var slot = presetMap()[key]; if (!slot) return;
    var b = cloud.bindings[key], cur = b && b.ign ? b.ign : (IGN_RE.test(slot.label || '') ? slot.label : '');
    msDialog({ title: 'Rename', subtitle: b && b.ign && b.cloudUpdatedAt ? 'The cloud copy keeps the old name until you upload under the new one.' : '', build: function (body, close) {
      var input = el('input', CLS.input); input.setAttribute('maxlength', '16'); input.placeholder = 'IGN'; input.value = cur;
      input.setAttribute('autocapitalize', 'off'); input.setAttribute('spellcheck', 'false'); body.appendChild(input);
      var err = el('span', 'text-red-500 text-xs text-center'); err.hidden = true; body.appendChild(err);
      var go = function () {
        var ign = input.value.trim();
        if (!IGN_RE.test(ign)) { err.textContent = '1 to 16 letters or digits'; err.hidden = false; input.focus(); return; }
        var other = bindingByIgn(ign); if (other && other.key !== key) { err.textContent = ign + ' is already another character'; err.hidden = false; return; }
        close();
        var same = !!(b && b.ign && eqi(b.ign, ign));
        var wasSelected = !!(cloud.selected && cloud.selected.key === key);
        var oldHist = histKey(key);
        // Keep the binding and the selection in step with the new label BEFORE the store changes,
        // so the reconciler (label/savedAt matching) does not drop them on the way through.
        if (b) b.label = ign; if (wasSelected) cloud.selected.label = ign; saveBindings();
        var m2 = clone(presetMap()); if (!m2[key]) return; m2[key].label = ign; if (!setPresetMap(m2)) return;
        bindSlot(key, ign, null);
        // bindSlot keeps the old spelling of a case-only rename (so the cloud state survives);
        // the binding still has to carry the spelling the user just typed.
        if (cloud.bindings[key]) { cloud.bindings[key].ign = ign; saveBindings(); }
        moveHistory(oldHist, histKey(key));
        if (wasSelected) setSelected(key, false, true);
        renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
        avatarFor(ign);
        toastOk('Renamed to ' + ign + (same || !cloudEnabled() ? '' : '. Click the sync icon to upload it.'));
      };
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      msActions(body, 'Cancel', function () { close(); }, 'Rename', go);
      setTimeout(function () { input.focus(); input.select(); }, 30);
    } });
  }
  function deleteLocalSlot(key, okMsg) {
    var slot = presetMap()[key]; if (!slot) return;
    var name = slotName(key, slot), b = cloud.bindings[key];
    (function () {
      var s = cloudStores(); if (!s) return;
      // The store's subscriber runs reconcileBindings synchronously inside deletePreset, so the
      // selection, history and binding must go first. Snapshot them and put them back on failure.
      var savedSel = cloud.selected, hm = histMap(), hk = histKey(key), savedHist = hk ? hm[hk] : null;
      if (cloud.selected && cloud.selected.key === key) { if (cloud.saveTimer) { clearTimeout(cloud.saveTimer); cloud.saveTimer = null; } cloud.selected = null; }
      if (hk && hm[hk]) { delete hm[hk]; saveHist(); }
      delete cloud.bindings[key]; saveBindings();
      try { s.ps.getState().deletePreset(key); } catch (e) {
        if (hk && savedHist) { hm[hk] = savedHist; saveHist(); }
        if (b) cloud.bindings[key] = b;
        cloud.selected = savedSel; saveBindings();
        renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
        toastErr('Could not delete the character'); return;
      }
      reconcileBindings(); renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
      toastOk(okMsg || 'Deleted from this browser');
    })();
  }
  // Remove the cloud copy. `done(ok)` runs after the request settles when given; without it the
  // result is announced with a toast (the plain "Delete cloud" path).
  function deleteCloud(key, done) {
    var b = cloud.bindings[key]; if (!b || !b.ign) { if (done) done(false); return; }
    var ign = b.ign;
    (function () {
      busy(1);
      cloudFetch('DELETE', cloudPath(ign), { headers: { 'X-Confirm': ign } }).then(function (r) {
        busy(-1);
        if (r.ok || r.status === 404) {
          b.cloudUpdatedAt = null; b.remoteUpdatedAt = null; b.syncedHash = null; b.syncedAt = null; saveBindings(); updateIcon(); if (picker.open) renderDropdown();
          if (done) done(true); else toastOk('Deleted from the cloud');
        } else { toastErr(httpErrText(r, 'Could not delete ' + ign + ' from the cloud (' + r.status + ')')); if (done) done(false); }
      }, function (e) { busy(-1); if (!e.disabled) toastErr('Cloud unavailable'); updateIcon(); if (done) done(false); });
    })();
  }
  // Cloud first, then the copy in this browser. A failed cloud delete keeps the local copy (the
  // error toast comes from deleteCloud), so nothing is lost without the other half going too.
  // Slot keys are renumbered whenever a preset is deleted, and nothing blocks the picker while
  // the DELETE is in flight, so the slot is found again by IGN once the request settles.
  function deleteBoth(key) {
    var b = cloud.bindings[key], ign = b && b.ign;
    deleteCloud(key, function (ok) {
      if (!ok) return;
      var hit = bindingByIgn(ign);
      if (!hit || !presetMap()[hit.key]) { toastOk('Deleted from the cloud'); return; }
      deleteLocalSlot(hit.key, 'Deleted here and from the cloud');
    });
  }
  // One Delete entry with four choices (two when there is no cloud copy).
  function deleteDialog(key) {
    var slot = presetMap()[key]; if (!slot) return;
    var b = cloud.bindings[key], inCloud = !!(b && b.ign && b.cloudUpdatedAt);
    msDialog({ title: 'Delete this character?', subtitle: metaLine(slotMeta(slot.data)), build: function (body, close) {
      var grid = el('div', inCloud ? 'grid w-full grid-cols-2 gap-2' : 'flex w-full gap-2');
      var mk = function (label, danger, fn) {
        var x = el('button', CLS.ghost + (danger ? ' text-red-500' : ''), label); x.type = 'button';
        x.addEventListener('click', function () { close(); if (fn) fn(); });
        grid.appendChild(x);
      };
      mk('Cancel', false, null);
      if (inCloud) {
        mk('Delete local', true, function () { deleteLocalSlot(key); });
        mk('Delete cloud', true, function () { deleteCloud(key); });
        mk('Delete both', true, function () { deleteBoth(key); });
      } else mk('Delete', true, function () { deleteLocalSlot(key); });
      body.appendChild(grid);
    } });
  }
  // Download a saved character as a native preset file (with "ign" so importing re-links it).
  function downloadSlotJson(key) {
    var slot = presetMap()[key]; if (!slot || !presetDataOk(slot.data)) { toastErr('Nothing to download'); return; }
    var b = cloud.bindings[key], ign = b && b.ign ? b.ign : null, name = ign || slot.label || autoPresetLabel(slot.data) || ('preset-' + key);
    var file = { type: 'maplescouter-manual-preset', v: 1, savedAt: slot.savedAt || nowIso(), label: slot.label || name, data: slot.data };
    if (ign) file.ign = ign;
    // Carry the HEXA figure like the cloud document does, so another browser can show it on import.
    var m = slotMeta(slot.data);
    if (m.hexa && !m.hexaPlain) file.meta = { hexaConverted: m.hexa };
    var blob = new Blob([JSON.stringify(file)], { type: 'application/json' });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = 'scouter-character-' + String(name).replace(/[\/\\:*?"<>|\s]+/g, '_') + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { try { URL.revokeObjectURL(a.href); } catch (e) {} }, 60000);
    toastOk('Downloaded ' + a.download);
  }
  function openRowMenu(key) {
    closePicker();
    var slot = presetMap()[key]; if (!slot) return;
    var b = cloud.bindings[key], name = slotName(key, slot), inCloud = !!(b && b.ign && b.cloudUpdatedAt);
    msDialog({ title: name, subtitle: metaLine(slotMeta(slot.data)), build: function (body, close) {
      // Compact: icon + one word each, two per row; destructive ones in red.
      var grid = el('div', 'grid w-full grid-cols-2 gap-2');
      var act = function (icon, label, extra, fn) {
        var x = el('button', CLS.ghost + (extra ? ' ' + extra : '')); x.type = 'button';
        x.innerHTML = svgIcon(icon); x.appendChild(el('span', '', label));
        x.addEventListener('click', function () { close(); fn(); });
        grid.appendChild(x);
      };
      act('save', 'Overwrite', '', function () { overwriteFromDraft(key); });
      act('pencil', b && b.ign ? 'Rename' : 'Set IGN', '', function () { if (b && b.ign) renameSlot(key); else openAddDialog(IGN_RE.test(slot.label || '') ? slot.label : '', { linkKey: key }); });
      act('download', 'Download', '', function () { downloadSlotJson(key); });
      act('history', 'History', '', function () { openHistory(key); });
      act('trash', 'Delete', 'text-red-500', function () { deleteDialog(key); });
      body.appendChild(grid);
      var cancel = el('button', CLS.ghost, 'Cancel'); cancel.type = 'button'; cancel.addEventListener('click', function () { close(); }); body.appendChild(cancel);
    } });
  }
  // "Import JSON…": a native or legacy preset file becomes a character (or overwrites one).
  function importJsonFlow() {
    closePicker();
    pickJsonFile(function (txt) {
      var parsed = parsePresetFile(txt);
      var usable = parsed ? parsed.presets.filter(function (p) { return presetDataOk(p.data); }) : [];
      if (!usable.length) { toastErr('This is not a MapleScouter character file'); return; }
      pickPreset(usable, function (p) {
        var report = [], data = conformTo(currentUserStatTemplate(), p.data, report);
        conformToast(report, 'this file');
        var warns = statWarnings(data); if (warns.length) toastErr('Check the inputs in this file. ' + warns[0]);
        seedHexa(data, p.meta);
        // Only our own exports carry `ign`. A label that merely looks like an IGN is never bound
        // here: that would silently point the slot at someone else's public cloud key.
        var ign = p.ign || null;
        var existing = ign ? bindingByIgn(ign) : null;
        var finish = function (key, what) { if (ign) bindSlot(key, ign, null); setSelected(key, true, true); toastOk(what + ' ' + (ign || p.label || 'character')); };
        if (!existing) { var k = writeSlot(null, data, ign || p.label || autoPresetLabel(data)); if (k) finish(k, 'Imported'); return; }
        msDialog({ title: ign + ' already exists', subtitle: 'The file contains ' + metaLine(slotMeta(data)) + '.', build: function (body, close) {
          var list = el('div', CLS.list);
          list.appendChild(msRow('Replace it', 'The file replaces the saved character', function () { close(); var old = presetMap()[existing.key]; if (old) pushHistory(existing.key, 'keep', old.data); var k2 = writeSlot(existing.key, data, ign); if (k2) { pushHistory(k2, 'import', data); finish(k2, 'Replaced'); } }));
          list.appendChild(msRow('Import as a new character', 'Keeps both', function () { close(); var k3 = writeSlot(null, data, ign + ' (file)'); if (k3) { setSelected(k3, true, true); toastOk('Imported ' + ign + ' as a new character'); } }));
          body.appendChild(list);
          var cancel = el('button', CLS.ghost, 'Cancel'); cancel.type = 'button'; cancel.addEventListener('click', function () { close(); }); body.appendChild(cancel);
        } });
      });
    });
  }

  /* -- the picker (combobox + sync icon) ------------------------------------------------- */
  var SOFT_BASE = CLS.soft.replace(' text-text-gray-high', '');
  var picker = { el: null, input: null, dd: null, icon: null, live: null, av: null, open: false, filter: '', active: -1, items: [], mountPoll: null, quietFocus: false };
  var C_INPUT = 'outline-outline-gray-med bg-surface-gray-surface-0 flex h-8 min-w-0 rounded-[4px] px-3 py-1 text-sm outline transition-[color,box-shadow] md:text-sm focus:outline-outline-gray-high focus:shadow-[0px_0px_0px_3px_rgba(0,0,0,0.20)] w-[216px] pr-8';
  var C_DD = 'msfix-dd bg-surface-gray-surface-0 text-text-gray-high absolute right-0 z-[2147483647] mt-1 w-[340px] max-h-[60vh] overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md text-left';
  var C_SECTION = 'text-text-gray-low px-2 py-1 text-[11px] font-semibold tracking-wide';
  var C_OPT = 'msfix-opt relative flex w-full cursor-pointer items-center gap-2 rounded-sm py-1.5 pr-2 pl-2 text-sm select-none text-left';
  var C_OPT_HOVER = ' hover:bg-surface-gray-surface-1', C_OPT_SELECTED = ' bg-surface-gray-surface-1 hover:bg-surface-gray-surface-2', C_OPT_ACTIVE = 'bg-surface-gray-surface-2';
  var C_BADGE = 'ml-auto shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold ';
  var C_DIVIDER = 'border-outline-gray-med my-1 border-t';
  var C_FOOT_BTN = 'flex w-full cursor-pointer items-center justify-between rounded-sm px-2 py-1 text-xs hover:bg-surface-gray-surface-1 text-left';

  function buildPicker() {
    var wrap = el('div', 'msfix-charpicker flex items-center gap-2'); wrap.setAttribute('data-msfix-ui', '');
    var rel = el('div', 'relative');
    var input = el('input', C_INPUT);
    input.type = 'text'; input.placeholder = 'Choose a character...';
    input.setAttribute('role', 'combobox'); input.setAttribute('aria-expanded', 'false'); input.setAttribute('aria-autocomplete', 'list');
    input.setAttribute('aria-controls', 'msfix-charlist'); input.setAttribute('aria-haspopup', 'listbox'); input.setAttribute('aria-label', 'Character');
    input.setAttribute('autocomplete', 'off'); input.setAttribute('spellcheck', 'false'); input.setAttribute('autocapitalize', 'off');
    var chev = el('span', 'pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-text-gray-low'); chev.innerHTML = svgIcon('chevrons-up-down');
    var av = avatarBox('', 'msfix-avatar-sm msfix-avatar-trigger'); av.hidden = true;   // the selected character's look, closed state only
    var dd = el('div', C_DD); dd.id = 'msfix-charlist'; dd.setAttribute('role', 'listbox'); dd.hidden = true;
    rel.appendChild(input); rel.appendChild(av); rel.appendChild(chev); rel.appendChild(dd);
    var icon = el('button', SOFT_BASE + ' msfix-sync text-text-gray-low'); icon.type = 'button';
    attachTooltip(icon);
    var live = el('span', 'sr-only'); live.setAttribute('aria-live', 'polite');
    wrap.appendChild(rel); wrap.appendChild(icon); wrap.appendChild(live);

    input.addEventListener('focus', function () { if (picker.quietFocus) return; openPicker(); });
    input.addEventListener('click', function () { if (!picker.open) openPicker(); });
    input.addEventListener('input', function () { picker.filter = input.value; picker.active = -1; if (!picker.open) openPicker(); else renderDropdown(); });
    input.addEventListener('keydown', onPickerKey);
    dd.addEventListener('mousedown', function (e) { e.preventDefault(); });   // keep focus in the input
    dd.addEventListener('click', function (e) {
      var act = e.target && e.target.closest ? e.target.closest('[data-msfix-act]') : null;
      if (act && dd.contains(act)) { e.preventDefault(); e.stopPropagation(); if (act.getAttribute('data-msfix-act') === 'menu') openRowMenu(act.getAttribute('data-msfix-key')); return; }
      var t = e.target && e.target.closest ? e.target.closest('[data-msfix-idx]') : null;
      if (!t || !dd.contains(t)) return;
      e.preventDefault(); e.stopPropagation();
      activateItem(+t.getAttribute('data-msfix-idx'));
    });
    icon.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); onSyncClick(); });
    picker.el = wrap; picker.input = input; picker.dd = dd; picker.icon = icon; picker.live = live; picker.av = av;
  }
  function renderTrigger() {
    if (!picker.input) return;
    var key = selectedKey(), map = presetMap();
    var name = key && map[key] ? slotName(key, map[key]) : '';
    picker.input.setAttribute('data-msfix-selected', key || '');
    // The look sits at the left of the text while the picker is closed (cache only, no lookup here).
    var b = key ? cloud.bindings[key] : null, ign = b && b.ign ? b.ign : '';
    var av = ign && !picker.open ? avatarCached(ign) : null, show = !!(av && av.image && !avatarBroken[av.image]);
    if (picker.av) {
      picker.av.setAttribute('data-msfix-avatar', ign.toLowerCase());
      if (show) paintAvatarBox(picker.av, av);
      picker.av.hidden = !show;
    }
    if (show) picker.input.classList.add('msfix-has-avatar'); else picker.input.classList.remove('msfix-has-avatar');
    if (picker.open) { picker.input.placeholder = name || 'Search or add a character...'; return; }
    picker.input.value = name; picker.input.placeholder = 'Choose a character...';
    picker.input.title = name;
  }
  function openPicker() {
    if (!picker.dd || picker.open) return;
    picker.open = true; picker.filter = ''; picker.active = -1;
    picker.input.value = ''; picker.input.setAttribute('aria-expanded', 'true');
    renderTrigger(); picker.dd.hidden = false; renderDropdown();
    refreshPickerCloud();
    picker.timeTimer = setInterval(function () { if (!document.hidden) refreshPickerRows(); }, 1000);
    avatarWarm();   // the one place the list asks for looks it does not have yet
  }
  function closePicker() {
    if (!picker.dd || !picker.open) return;
    if (picker.timeTimer) { clearInterval(picker.timeTimer); picker.timeTimer = null; }
    picker.open = false; picker.filter = ''; picker.active = -1;
    picker.dd.hidden = true; picker.input.setAttribute('aria-expanded', 'false'); picker.input.removeAttribute('aria-activedescendant');
    renderTrigger();
  }
  function onPickerKey(e) {
    if (dlgStack.length) return;   // a dialog is on top: its keys are not ours
    var n = picker.items.length;
    if (e.key === 'Escape') { if (picker.open) { e.preventDefault(); e.stopPropagation(); closePicker(); picker.input.blur(); } return; }
    if (e.key === 'Tab') { closePicker(); return; }
    if (!picker.open) { if (e.key === 'ArrowDown' || e.key === 'Enter') { e.preventDefault(); openPicker(); } return; }
    if (e.key === 'ArrowRight' && picker.active >= 0 && picker.items[picker.active] && picker.items[picker.active].type === 'local') { e.preventDefault(); openRowMenu(picker.items[picker.active].key); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(n ? (picker.active + 1) % n : -1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(n ? (picker.active - 1 + n) % n : -1); }
    else if (e.key === 'Home') { e.preventDefault(); setActive(n ? 0 : -1); }
    else if (e.key === 'End') { e.preventDefault(); setActive(n ? n - 1 : -1); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      if (picker.active >= 0) { activateItem(picker.active); return; }
      // No row is highlighted: pick the saved character the typed text names, if there is exactly one.
      var q = picker.filter.trim(), hit = enterTarget(q);
      if (hit >= 0) activateItem(hit);
      else if (q && IGN_RE.test(q)) openAddDialog(q);
    }
  }
  // The saved rows the typed text points at: an exact IGN or name match wins, else the only listed row.
  function enterTarget(q) {
    var map = presetMap(), locals = [], exact = [];
    for (var i = 0; i < picker.items.length; i++) {
      var it = picker.items[i]; if (it.type !== 'local') continue;
      locals.push(i);
      var b = cloud.bindings[it.key], s = map[it.key];
      if (q && ((b && b.ign && eqi(b.ign, q)) || (s && s.label && eqi(s.label, q)) || eqi(slotName(it.key, s), q))) exact.push(i);
    }
    if (exact.length === 1) return exact[0];
    if (q && locals.length === 1) return locals[0];
    return -1;
  }
  function setActive(i) {
    picker.active = i;
    for (var k = 0; k < picker.items.length; k++) {
      var it = picker.items[k]; if (!it.el) continue;
      if (k === i) { it.el.classList.add('msfix-active'); it.el.classList.add(C_OPT_ACTIVE); picker.input.setAttribute('aria-activedescendant', it.el.id); if (it.el.scrollIntoView) try { it.el.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
      else { it.el.classList.remove('msfix-active'); it.el.classList.remove(C_OPT_ACTIVE); }
    }
    if (i < 0) picker.input.removeAttribute('aria-activedescendant');
  }
  function activateItem(i) {
    var it = picker.items[i]; if (!it) return;
    if (it.type === 'local') { closePicker(); picker.input.blur(); setSelected(it.key, true); }
    else if (it.type === 'cloud-lookup') { picker.input.blur(); selectCloudOnly(it.ign); }
    else if (it.type === 'add') { picker.input.blur(); openAddDialog(IGN_RE.test(picker.filter.trim()) ? picker.filter.trim() : ''); }
    else if (it.type === 'import') { picker.input.blur(); importJsonFlow(); }
    else if (it.type === 'download') { closePicker(); picker.input.blur(); downloadSlotJson(it.key); }
  }
  function badge(kind) {
    return el('span', 'shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold ' + (kind === 'cloud' ? 'bg-green-600 text-white' : 'bg-surface-gray-surface-2 text-text-gray-low'), kind);
  }
  // A row: name + chips (+ a menu button for saved characters), then one or two wrapping lines.
  // The selected row is marked by the accent bar + background (CSS on aria-selected), nothing else.
  // `ign` (optional, may be '') adds the 28px look box on the left; the box shows the cached
  // look or the silhouette, and a lookup that lands later repaints it in place (paintAvatars).
  function optionEl(idx, main, sub1, sub2, badges, selected, menuKey, ign) {
    var d = el('div', C_OPT + (selected ? ' msfix-selected' + C_OPT_SELECTED : C_OPT_HOVER)); d.setAttribute('role', 'option'); d.id = 'msfix-opt-' + idx; d.setAttribute('data-msfix-idx', String(idx));
    d.setAttribute('aria-selected', selected ? 'true' : 'false');
    if (ign !== undefined && ign !== null) d.appendChild(avatarBox(ign, ''));
    var col = el('div', 'flex min-w-0 flex-1 flex-col items-start gap-0.5'); d.appendChild(col);
    var top = el('div', 'flex w-full items-center gap-2');
    var m = el('span', 'min-w-0 flex-1 truncate ' + (selected ? 'font-semibold' : 'font-medium'), main); m.title = main; top.appendChild(m);
    var chips = el('span', 'msfix-location-badges flex shrink-0 gap-1');
    (badges || []).forEach(function (k) { chips.appendChild(badge(k)); });
    top.appendChild(chips);
    if (menuKey) {
      var kb = el('button', 'msfix-row-menu shrink-0 rounded-sm p-0.5 text-text-gray-low hover:bg-surface-gray-surface-2 hover:text-text-gray-high'); kb.type = 'button';
      kb.setAttribute('data-msfix-act', 'menu'); kb.setAttribute('data-msfix-key', menuKey); kb.setAttribute('aria-label', 'Actions for ' + main); kb.title = 'More actions';
      kb.innerHTML = svgIcon('ellipsis'); top.appendChild(kb);
    }
    col.appendChild(top);
    if (sub1) col.appendChild(el('span', 'text-text-gray-low w-full text-xs break-words', sub1));
    if (sub2) col.appendChild(el('span', 'msfix-save-times text-text-gray-low w-full text-xs break-words', sub2));
    return d;
  }
  function saveTimes(slot, b) {
    var text = 'Local: ' + (slot.savedAt ? relTime(slot.savedAt) : 'unknown');
    if (!b || !b.ign) return text;
    var check = remoteCheck(b), remote = b.remoteUpdatedAt || b.cloudUpdatedAt;
    if ((check && check.pending) || (!check && remote)) return text + ', Cloud: checking...';
    if (cloud.offline || (check && (!check.response || (!check.response.ok && check.response.status !== 404)))) return text + ', Cloud: unavailable';
    return text + ', Cloud: ' + (remote ? relTime(remote) : 'not uploaded');
  }
  function refreshPickerRows() {
    if (!picker.open) return;
    var map = presetMap();
    picker.items.forEach(function (it) {
      if (it.type !== 'local' || !it.el || !map[it.key]) return;
      var b = cloud.bindings[it.key], text = saveTimes(map[it.key], b);
      var stamp = it.el.querySelector('.msfix-save-times');
      if (stamp && stamp.textContent !== text) stamp.textContent = text;
      var chips = it.el.querySelector('.msfix-location-badges');
      if (chips) {
        var inCloud = !!(b && (b.remoteUpdatedAt || b.cloudUpdatedAt));
        if (chips.children.length !== (inCloud ? 2 : 1)) {
          chips.replaceChildren(badge('local'));
          if (inCloud) chips.appendChild(badge('cloud'));
        }
      }
    });
  }
  function placePickerDropdown() {
    if (!picker.open || !picker.dd || picker.dd.hidden) return;
    var anchor = picker.dd.parentElement.getBoundingClientRect();
    var viewport = document.documentElement.clientWidth || window.innerWidth;
    // clientWidth excludes a non-overlay scrollbar, unlike CSS 100vw.
    picker.dd.style.maxWidth = Math.max(0, viewport - 16) + 'px';
    var width = picker.dd.getBoundingClientRect().width;
    // Keep the desktop right alignment, but shift inward at either viewport edge.
    var left = Math.max(8, Math.min(anchor.right - width, viewport - width - 8));
    picker.dd.style.left = (left - anchor.left) + 'px';
    picker.dd.style.right = 'auto';
  }
  function renderDropdown() {
    if (!picker.dd || !picker.open) return;
    var dd = picker.dd; dd.innerHTML = ''; picker.items = [];
    var q = picker.filter.trim(), ql = q.toLowerCase();
    var map = presetMap(), keys = slotKeys(map), sel = selectedKey();
    var match = function (parts) { if (!ql) return true; for (var i = 0; i < parts.length; i++) if (parts[i] && String(parts[i]).toLowerCase().indexOf(ql) !== -1) return true; return false; };
    var addItem = function (item, node) { item.el = node; picker.items.push(item); return node; };
    var divider = function () { dd.appendChild(el('div', C_DIVIDER)); };

    // One list: every saved character, with chips for where it lives. The cloud is never
    // listed wholesale — a character is fetched only when its IGN is typed.
    dd.appendChild(el('div', C_SECTION, 'Characters'));
    var rows = 0, typedIsLocal = false;
    keys.forEach(function (k) {
      var s = map[k]; if (!s || !presetDataOk(s.data)) return;
      var b = cloud.bindings[k], m = slotMeta(s.data), name = slotName(k, s);
      if (b && b.ign && ql && b.ign.toLowerCase() === ql) typedIsLocal = true;
      if (!match([name, s.label, b && b.ign, m.classEn, m.classKo])) return;
      var inCloud = !!(b && b.ign && (b.remoteUpdatedAt || b.cloudUpdatedAt));
      var when = saveTimes(s, b);
      dd.appendChild(addItem({ type: 'local', key: k }, optionEl(picker.items.length, name, metaLine(m), when, inCloud ? ['local', 'cloud'] : ['local'], k === sel, k, b && b.ign ? b.ign : '')));
      rows++;
    });
    if (!rows) dd.appendChild(el('div', 'text-text-gray-low px-2 py-1 text-xs', ql ? 'No saved character matches' : 'No saved characters yet'));
    divider();
    if (ql && IGN_RE.test(q) && !typedIsLocal) {
      dd.appendChild(addItem({ type: 'cloud-lookup', ign: q }, optionEl(picker.items.length, 'Load ' + q + ' from the cloud', 'Loads that character by IGN', '', ['cloud'], false, null, q)));
    }
    dd.appendChild(addItem({ type: 'add' }, optionEl(picker.items.length, '+ Add character', ql && IGN_RE.test(q) ? 'Start ' + q + ' from the current inputs' : 'Start a new character from the current inputs', '', [], false, null, '')));
    divider();
    var foot = el('div', 'flex flex-col gap-0.5 px-1 pb-1');
    var imp = el('button', C_FOOT_BTN); imp.type = 'button'; imp.id = 'msfix-opt-' + picker.items.length; imp.setAttribute('data-msfix-idx', String(picker.items.length));
    imp.appendChild(el('span', '', 'Import JSON...')); var ic = el('span', 'text-text-gray-low'); ic.innerHTML = svgIcon('file-up'); imp.appendChild(ic);
    foot.appendChild(addItem({ type: 'import' }, imp));
    if (sel && map[sel]) {
      var dl = el('button', C_FOOT_BTN); dl.type = 'button'; dl.id = 'msfix-opt-' + picker.items.length; dl.setAttribute('data-msfix-idx', String(picker.items.length));
      dl.appendChild(el('span', '', 'Download JSON...')); var dic = el('span', 'text-text-gray-low'); dic.innerHTML = svgIcon('download'); dl.appendChild(dic);
      foot.appendChild(addItem({ type: 'download', key: sel }, dl));
    }
    dd.appendChild(foot);
    setActive(picker.active >= 0 && picker.active < picker.items.length ? picker.active : -1);
    placePickerDropdown();
  }

  function unmountPicker() {
    closePicker(); stopPolling();
    if (picker.icon && picker.icon.__msfixTip) picker.icon.__msfixTip.hide();
    if (picker.el && picker.el.parentNode) picker.el.parentNode.removeChild(picker.el);
  }
  // Idempotent: mounts once the native row exists and both stores are known; re-run after
  // every panel remount (loadDraft & co.), from the housekeeping interval and on navigation.
  function ensureCharPicker() {
    applyRouteGate();
    if (!isInputRoute()) { cloud.inputActive = false; if (picker.el && picker.el.parentNode) unmountPicker(); return false; }
    var row = nativePresetRow(); if (!row) return false;
    var header = row.parentElement; if (!header) return false;
    if (!ensureSubscriptions()) return false;
    if (picker.el && header.contains(picker.el)) return true;
    if (!picker.el) buildPicker();
    else {
      if (picker.icon && picker.icon.__msfixTip) picker.icon.__msfixTip.hide();
      if (picker.el.parentNode) picker.el.parentNode.removeChild(picker.el);
    }
    header.appendChild(picker.el);
    reconcileBindings(); renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
    if (!cloud.inputActive) { cloud.inputActive = true; pollTick(true); }
    else startPolling();
    return true;
  }
  function schedulePickerMount() {
    if (picker.mountPoll) clearInterval(picker.mountPoll);
    var tries = 0;
    picker.mountPoll = setInterval(function () {
      if (++tries > 200 || !isInputRoute() || ensureCharPicker()) { clearInterval(picker.mountPoll); picker.mountPoll = null; }
    }, 150);
  }

  /* -- export enrichment: the site's Save-as-JSON file gets "ign" for a linked slot -------- */
  // The site builds the file synchronously (Blob → object URL → detached <a>.click() → revoke).
  // Shadow click on <a> only, keep the Blob while its URL is alive, read it asynchronously,
  // add "ign" from the slot in the filename, and click the original with a fresh URL. The
  // site's importer ignores unknown top-level keys, so the file stays importable there too.
  function installExportEnricher() {
    if (window.__msfixExportHook) return; window.__msfixExportHook = true;
    var blobs = {}, order = [];
    var oCreate = URL.createObjectURL, oRevoke = URL.revokeObjectURL;
    if (typeof oCreate !== 'function' || typeof oRevoke !== 'function' || typeof HTMLAnchorElement === 'undefined') return;
    URL.createObjectURL = function (o) {
      var u = oCreate.apply(URL, arguments);
      try { if (o instanceof Blob) { blobs[u] = o; order.push(u); while (order.length > 20) delete blobs[order.shift()]; } } catch (e) {}
      return u;
    };
    URL.revokeObjectURL = function (u) { try { delete blobs[u]; } catch (e) {} return oRevoke.apply(URL, arguments); };
    var oClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      var a = this, args = arguments;
      var m = /^scouter-preset-(\d+)/.exec(a.getAttribute('download') || '');
      var blob = m ? blobs[a.href] : null;             // must be read now — revoked right after we return
      var ign = m ? ignForSlot(m[1]) : null;
      if (!blob || !ign) return oClick.apply(a, args);
      blob.text().then(function (txt) {
        var o = null; try { o = JSON.parse(txt); } catch (e) {}
        if (!o || o.type !== 'maplescouter-manual-preset') return oClick.apply(a, args);
        o.ign = ign;
        var nu = oCreate.call(URL, new Blob([JSON.stringify(o)], { type: 'application/json' }));
        a.href = nu; oClick.apply(a, args);
        setTimeout(function () { try { oRevoke.call(URL, nu); } catch (e) {} }, 60000);
      }, function () { oClick.apply(a, args); });
    };
  }

  function cloudOnReady() {
    injectCloudCss();
    applyRouteGate();
    schedulePickerMount();
    var onFocus = function () {
      if (document.hidden) { stopPolling(); return; }
      var now = Date.now();
      if (now - (cloud.lastFocusCheck || 0) < FOCUS_CHECK_GAP_MS) { startPolling(); return; }
      cloud.lastFocusCheck = now; if (picker.open) refreshPickerCloud(); if (!cloud.offline) cloud.pollDelay = POLL_MS; pollTick(true);   // while offline, one probe now but keep the backed-off delay
    };
    window.addEventListener('focus', onFocus);
    window.addEventListener('resize', placePickerDropdown);
    document.addEventListener('visibilitychange', onFocus);
    if (DEBUG_REFS) { siteRefs.pollNow = function () { pollTick(true); }; siteRefs.avatarFor = avatarFor; siteRefs.avatarCached = avatarCached; }   // test hooks
    window.addEventListener('storage', function (e) {
      if (!e || (e.key !== LS_CLOUD_SLOTS && e.key !== LS_CLOUD_SELECTED && e.key !== LS_CLOUD_ENABLED && e.key !== LS_CLOUD_AUTO)) return;
      loadBindings(); if (cloud.subscribed) reconcileBindings(true); renderTrigger(); updateIcon(); if (picker.open) renderDropdown();
    });
    document.addEventListener('mousedown', function (e) {
      if (picker.open && picker.el && !picker.el.contains(e.target)) closePicker();
    }, true);
  }

  /* ---------------- 5. UI polish CSS ---------------------------------------------------- */

  function injectCss() {
    var css = data().css;
    if (!css) return;
    var style = document.createElement('style');
    style.id = 'msfix-style';
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }

  /* ---------------- boot ---------------------------------------------------------------- */

  if (restoreLocale()) return; // redirecting; nothing else to do on this load
  document.addEventListener('click', rememberLanguageChoice, true);
  restoreRegion();
  hookWebpack();
  loadBindings();            // cloud character bindings (needed by the export hook below)
  installExportEnricher();   // Save-as-JSON files of linked presets carry "ign"
  applyRouteGate();          // hide native Load/Save + IGN search on /input only

  // Track SPA navigations for locale saving + fresh sweeps.
  var lastNavigationPath = location.pathname;
  var origPush = history.pushState;
  history.pushState = function () {
    var r = origPush.apply(this, arguments);
    onNavigate();
    return r;
  };
  var origReplace = history.replaceState;
  history.replaceState = function () {
    var r = origReplace.apply(this, arguments);
    onNavigate();
    return r;
  };
  window.addEventListener('popstate', onNavigate);
  window.addEventListener('resize', revealManualTab);

  function onNavigate() {
    var saved = null;
    try { saved = localStorage.getItem(LS_LOCALE); } catch (e) {}
    var wanted = navigationLocale(lastNavigationPath, location.pathname, saved);
    lastNavigationPath = location.pathname;
    if (wanted && wanted !== pathLocale()) {
      location.replace('/' + wanted + location.pathname.replace(/^\/(ko|en|ja|ch)(?=\/|$)/, '') + location.search + location.hash);
      return;
    }
    saveLocale();
    backupRegion();
    applyRouteGate();
    if (!isInputRoute()) { cloud.inputActive = false; unmountPicker(); }
    schedulePickerMount();
    setTimeout(revealManualTab, 100);
    if (document.body && pathLocale() === 'en') {
      setTimeout(function () { sweepTree(document.body); }, 50);
    }
  }

  function onReady() {
    // React replaces <html> attributes during hydration. Restore the layout scope
    // immediately, rather than leaving overflowing controls until the next poll.
    // Wait for the root to exist when installed as a document-start content script.
    applyRouteGate();
    new MutationObserver(applyRouteGate).observe(document.documentElement, {
      attributes: true, attributeFilter: ['data-msfix-route']
    });
    injectCss();
    startCheckboxHelp();
    installPresetImportBridge(); // let the site's native import accept our old export files
    cloudOnReady();              // character picker + cloud sync (Manual Input page)
    // The Save window mounts on click, so look for it right after one rather than waiting
    // for the housekeeping interval below.
    document.addEventListener('click', function () {
      setTimeout(ensureSaveImportIcons, 60);
      scheduleGmsLinks();
      setTimeout(ensureSaveImportIcons, 260);
    }, true);
    // Delay the DOM layer slightly so React hydration finishes first.
    setTimeout(startDomLayer, 250);
    setTimeout(function () { translateTitle(); fixLogo(); killAdPopups(); hideKoreanChangelog(); hideFavoritesBar(); compactCheckboxRows(); revealManualTab(); }, 400);
    setInterval(function () { backupRegion(); translateTitle(); fixLogo(); killAdPopups(); hideKoreanChangelog(); hideFavoritesBar(); compactCheckboxRows(); revealManualTab(); ensureSaveImportIcons(); refreshFloatRects(); ensureCharPicker(); ensureGmsLinks(); refreshCheckboxHelp(); }, 2000);
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') onReady();
  else window.addEventListener('DOMContentLoaded', onReady);
})();
